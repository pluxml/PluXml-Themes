<?php include('header.php'); # On insere le header ?><div id="main">
	<div id="content">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
		<div class="post">
				<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
				<div class="con"><?php $plxShow->artChapo(); ?></div>
				<p align="center" class="comment_nb"><?php $plxShow->artNbCom('link'); ?></p><br />
				<p class="post-info">Post&eacute; le 
			    <?php $plxShow->artDate(); ?> dans 
			    <?php $plxShow->artCat(); ?>.				</p>
				
				
	  </div>
		<div align="center">
		  <?php endwhile; # Fin de la boucle sur les articles ?>
		  <?php # On affiche la pagination ?>
	  </div>
		<p id="pagination"><?php $plxShow->pagination(); ?></p><br /><br />
	</div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
</div>
<?php include('footer.php'); # On insere le footer ?>
