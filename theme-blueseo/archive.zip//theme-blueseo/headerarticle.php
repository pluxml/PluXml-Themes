<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">
 	 <title><?php $plxShow->artTitle(''); ?> - <?php $plxShow->catName(); ?> - <?php $plxShow->mainTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>
	<!-- à modifier -->
	<meta name="robots" content="noindex, nofollow, all" />
	<meta name="googlebot" content="noindex, nofollow, all" />
	<link rel="author" href="https://plus.google.com/101180000000000000000"/>
<link href="https://plus.google.com/101180000000000000000" rel="publisher" />
<!-- -->
	<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/blueseomini.css" media="screen"/>
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/fonts.css" media="screen"/>
	<?php $plxShow->templateCss() ?>
	<?php $plxShow->pluginsCss() ?>
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
</head>

<body id="top">
<script src="<?php $plxShow->template(); ?>/js/cookiechoices.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function(event) {
    cookieChoices.showCookieConsentBar('Pour bien poursuivre votre navigation, acceptez l’utilisation de cookies nécessaires au bon fonctionnement du site',
      'OK accepter', '(Infos)', 'index.php?article4/cookies');
  });
</script>
<div class="container">

	<header class="header sml-text-center med-text-center">
		<h1 class="bigtitle"><?php $plxShow->mainTitle('link'); ?></h1>

	</header>

<?php eval($plxShow->callHook('filAriane', ' - ')); ?>