<?php if(!defined('PLX_ROOT')) exit; ?>

	<aside class="aside col sml-12 med-4" >
<?php eval($plxShow->callHook('MySearchForm')) ?>
		<h3 class="marque">
			<?php $plxShow->lang('CATEGORIES'); ?>
		</h3>

		<ul class="cat-list unstyled-list">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>

		<h3 class="marque">
			<?php $plxShow->lang('LATEST_ARTICLES'); ?>
		</h3>

		<ul class="lastart-list unstyled-list">
						<?php $plxShow->lastArtList('<li ><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>', 20); ?>
		</ul>

        <h3 class="marque">sur les réseaux sociaux:</h3>
		<!-- à personnaliser ! -->
				<p><a href="https://plus.google.com/+bernardrefok/posts" rel="nofollow" onclick="window.open(this.href);return false;" title="Google+"><img src="<?php $plxShow->template(); ?>/img/google-plus-black.png" alt="Google+" width="25" height="25" /></a>
			<a href="http://www.facebook.com/unesourisetmoi.info" rel="nofollow" onclick="window.open(this.href);return false;" title="facebook"><img src="<?php $plxShow->template(); ?>/img/facebook-black.png" alt="facebook" width="25" height="25" /></a>
			<a href="https://twitter.com/unesourisetmoi" rel="nofollow" onclick="window.open(this.href);return false;" title="twitter"><img src="<?php $plxShow->template(); ?>/img/twitter-black.png" alt="twitter" width="25" height="25"  /></a>
			<a href="https://www.youtube.com/c/unesourisetmoi" rel="nofollow" onclick="window.open(this.href);return false;" title="youtube"><img src="<?php $plxShow->template(); ?>/img/youtube-black.png" alt="youtube" width="25" height="25" /></a>
			<a href="http://pinterest.com/unesourisetmoi/" onclick="window.open(this.href);return false;" title="pinterest"><img src="<?php $plxShow->template(); ?>/img/pinterest-black.png" alt="pinterest" width="25" height="25" /></a>
			<a href="http://www.scoop.it/t/fonds-d-ecran-gratuits" onclick="window.open(this.href);return false;" title="scoopit"><img src="<?php $plxShow->template(); ?>/img/scoopit-black.png" alt="scoopit" width="25" height="25" /></a>
			<a href="http://unesourisetmoi.tumblr.com/" onclick="window.open(this.href);return false;" title="tumblr"><img src="<?php $plxShow->template(); ?>/img/tumblr-black.png" alt="tumblr" width="25" height="25" /></a>
		
</p>

    	<h3 class="marque">
		<?php eval($plxShow->callHook('showBlogrollHead')); ?>
		</h3>
		<ul>
		<?php eval($plxShow->callHook('showBlogroll', array('', 'article'))); ?>
		</ul>

		<h3>
			RSS
		</h3>
			<ul class="rss-list unstyled-list">
				<li class="rssli"><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
				<li class="rssli"><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
			</ul>

	</aside>
