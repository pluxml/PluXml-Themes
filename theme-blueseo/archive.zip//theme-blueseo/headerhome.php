<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">
	<title><?php $plxShow->pageTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>
	<!-- à modifier -->
	<meta name="robots" content="noindex, nofollow, all" />
	<meta name="googlebot" content="noindex, nofollow, all" />
	<link rel="author" href="https://plus.google.com/101180000000000000000"/>
<link href="https://plus.google.com/101180000000000000000" rel="publisher" />
<!-- -->
	<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/blueseomini.css" media="screen"/>
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/fonts.css" media="screen"/>
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/home.css" media="screen"/>
	<?php $plxShow->templateCss() ?>
	<?php $plxShow->pluginsCss() ?>
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
</head>

<body id="top">
<script src="<?php $plxShow->template(); ?>/js/cookiechoices.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function(event) {
    cookieChoices.showCookieConsentBar('Pour bien poursuivre votre navigation, acceptez l’utilisation de cookies nécessaires au bon fonctionnement du site',
      'OK accepter', '(Infos)', 'index.php?article4/cookies');
  });
</script>
<div class="container">
	<header class="header sml-text-center med-text-center">

				<h1 class="bigtitlehome"><?php $plxShow->mainTitle('link'); ?></h1>
<?php eval($plxShow->callHook("ResponsiveSlidesJs")) ?>		
		<h2 class="h5 no-margin"><?php $plxShow->subTitle(); ?></h2>
		<h3 class="h5 no-margin">Un Thème 100% optimisé SEO et Responsive Web Design pour un référencement optimal.</h3>
		<!--<?php eval($plxShow->callHook("MyCoinSlider")) ?>-->
	</header>


	<nav class="nav">
		<div class="responsive-menu">
			<label for="menu"><?php $plxShow->lang('MENU'); ?></label>
			<input type="checkbox" id="menu">
			<ul class="menu expanded">
				<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
				<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
			</ul>
		</div>
	</nav>