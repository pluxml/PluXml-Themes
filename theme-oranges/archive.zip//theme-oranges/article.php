<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
	<div id="content"><div id="breadcrumbs">		
<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> Blog <span class="sep">&#9658;</span> <?php $plxShow->artCat(); ?>  <span class="sep">&#9658;</span> 	<?php $plxShow->artTitle(''); ?>				
                        </div> <!-- end #breadcrumbs -->

		<h2 class="title"><?php $plxShow->artTitle(''); ?></h2>
		<p class="info_top"><?php $plxShow->lang('WRITTEN_BY') ?> <?php $plxShow->artAuthor() ?> | <?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat(); ?></p>
			<p class="date"><?php $plxShow->artDate('<span>#num_day</span> | #num_month | #num_year(2)'); ?></p>
		<div class="post"><?php $plxShow->artContent(); ?>

</div>
		<p class="info_bottom"><?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?></p>
		Partager cette page :
<a title="Identi.ca" href="http://identi.ca//index.php?action=bookmarklet&status_textarea=<?php $plxShow->artTitle(); ?> <?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/identi_ca.png" style="border:0;" alt="Identi.ca" /></a>
<a title="Twitter" href="http://twitter.com/home?status=<?php $plxShow->artTitle(); ?> <?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/twitter.png" style="border:0;" alt="Twitter" /></a> 
<a title="Digg" href="http://digg.com/submit?url=<?php $plxShow->artUrl('absolu'); ?>&title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/digg.png" style="border:0;" alt="Digg" /></a> 
<a title="StumbleUpon" href="http://www.stumbleupon.com/submit?url=<?php $plxShow->artUrl('absolu'); ?>&title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/stumble.png" style="border:0;" alt="Stumble" /></a> 
<a title="Delicious" href="http://del.icio.us/post?url=<?php $plxShow->artUrl('absolu'); ?>&title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/delicious.png" style="border:0;" alt="Delicious" /></a> 
<a title="Technorati" href="http://technorati.com/faves?add=<?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/technorati.png" style="border:0;" alt="Technorati" /></a> 
<a title="Facebook" href="http://www.facebook.com/sharer.php?u=<?php $plxShow->artUrl('absolu'); ?>&t=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/facebook.png" style="border:0;" alt="Facebook" /></a><?php $plxShow->artAuthorInfos('<div class="infos">#art_authorinfos</div>'); ?>
		<?php include(dirname(__FILE__).'/commentaires.php'); # On insere les commentaires ?>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>