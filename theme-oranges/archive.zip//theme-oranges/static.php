<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
	<div id="content">		<div id="breadcrumbs">		
					<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> page <span class="sep">&#9658;</span> <?php $plxShow->staticTitle(); ?>					
            </div> <!-- end #breadcrumbs -->
		<h2 class="title static"><?php $plxShow->staticTitle(); ?></h2>
		<div class="post"><?php $plxShow->staticContent(); ?></div>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>