<?php if(!defined('PLX_ROOT')) exit; ?>

	<div id="footer">

		<p>&copy; <?php $plxShow->mainTitle('link'); ?> / NEWS - <a class="admin" rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a> -
			<?php $plxShow->lang('POWERED_BY') ?> <a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
			<?php $plxShow->lang('IN') ?> <?php $plxShow->chrono(); ?> - Th&egrave;me : DCNEWS 
			<?php $plxShow->httpEncoding() ?>
			<span><a class="top" href="<?php echo $plxShow->urlRewrite('#top') ?>" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a> <img src="themes/theme-dcnews/img/fleche.jpg" alt="" /></span>
		</p>

	</div>

</body>
</html>
