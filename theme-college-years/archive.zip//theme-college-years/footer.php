	</div></div>
</div><div id="footer">
<div class="footerlinks"> 
		<div class="alignleft">
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | Theme by <a href="http://www.wpthemescreator.com/">wpthemescreator</a>
		</div>
		<div class="alignright">		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
		  </div>
	</div>
</div>
<div class="bgbottom"></div>
</div>
</div>

</div>
</body>
</html>