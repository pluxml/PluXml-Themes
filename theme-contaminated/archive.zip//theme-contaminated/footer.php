<div class="footer">
		
	<div class="left">G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?>  | 
		<a href="core/admin/">Administration</a>
		
	</div>
		
	<div class="right"><a href="http://templates.arcsin.se/">Website template</a> by <a href="http://arcsin.se/">Arcsin</a></div>

	<div class="clearer"><span></span></div>
</div>

	</div>

</div>

</body>

</html>