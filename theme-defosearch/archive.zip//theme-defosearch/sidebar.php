<?php if(!defined('PLX_ROOT')) exit; ?>

	<aside class="aside col sml-12 med-4" role="complementary">

		<?php	
		$placeholder = '';
		# récupération d'une instance de plxMotor
		$plxMotor = plxMotor::getInstance();
		$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
		$searchword = '';
		if(!empty($_POST['searchfield'])) {
			$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
		}
		if($plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang)!='') {
			$placeholder=' placeholder="'.$plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang).'"';
		}
		?>
		<div class="searchform">
			<form action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>" method="post">
				<?php if($title) : ?>
				<p class="searchtitle">
					<?php
						if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)=='')
							$plxPlugin->lang('L_FORM_SEARCHFIELD');
						else
							$plxPlugin->lang('L_FORM_SEARCHFIELD_2');
					?>&nbsp;:
				</p>
				<?php endif; ?>
				<div class="searchfields">
					<?php
					if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)!='') {
						if($chk = explode(';', $plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang))) {
							echo '<ul>';
							foreach($chk as $k => $v) {
								$c = plxUtils::title2url(trim($v));
								$sel = "";
								if(isset($_POST['searchcheckboxes'])) {
									foreach($_POST['searchcheckboxes'] as $s) {
										if($s==$c) {
											$sel = ' checked="checked"';
										}
									}
								}
								echo '<li><input'.$sel.' class="searchcheckboxes" type="checkbox" name="searchcheckboxes[]" id="id_searchcheckboxes[]" value="'.$c.'" />&nbsp;'.plxUtils::strCheck($v).'</li>';
							}
							echo '</ul>';
						}
					}
					?>
					<input type="text" <?php echo $placeholder ?> class="searchfield" name="searchfield" value="<?php echo $searchword ?>" />
					<input type="submit" class="searchbutton" name="searchbutton" value="<?php echo $plxPlugin->getParam('frmLibButton_'.$plxPlugin->default_lang) ?>" />

				</div>
			</form>
		</div>
			
	
	
		<h3>
			<?php $plxShow->lang('CATEGORIES'); ?>
		</h3>

		<ul class="cat-list unstyled-list">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>

		<h3>
			<?php $plxShow->lang('LATEST_ARTICLES'); ?>
		</h3>

		<ul class="lastart-list unstyled-list">
			<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>',4,'',$sort='random'); ?>
		</ul>

		<h3>
			<?php $plxShow->lang('TAGS'); ?>
		</h3>

		<ul class="tag-list">
			<?php $plxShow->tagList('<li class="tag #tag_size"><a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a></li>'); ?>
		</ul>

		<h3>
			<?php $plxShow->lang('LATEST_COMMENTS'); ?>
		</h3>

		<ul class="lastcom-list unstyled-list">
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
		</ul>

		<h3>
			<?php $plxShow->lang('ARCHIVES'); ?>
		</h3>

		<ul class="arch-list unstyled-list">
			<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
		</ul>

		<h3>
			RSS
		</h3>
			<ul class="rss-list unstyled-list">
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
			</ul>

	</aside>
