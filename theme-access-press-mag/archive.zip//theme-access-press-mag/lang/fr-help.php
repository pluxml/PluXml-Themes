<?php if (!defined('PLX_ROOT')) exit; ?>
<p>Assistance au thème</p>