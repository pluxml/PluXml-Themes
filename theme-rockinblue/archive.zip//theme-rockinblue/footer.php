<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	(Creative Commons BY-SA) 2010 <strong><?php $plxShow->mainTitle('link'); ?></strong>. Propuls&eacute; par <a href="http://pluxml.org/">Pluxml </a>en <?php $plxShow->chrono(); ?>. Design RockinBlue par <a href="http://www.corymiller.com">Cory Miller</a>.<br />
	<a href="#top">Haut de page</a> | <a href="core/admin/">Admin</a>.
</div>
</body>
</html>

