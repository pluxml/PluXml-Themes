<div id="footer">
  </div>
 
 </div><!-- #contents end -->
</div><!-- #wrapper end -->

<div id="return_top">
 <a href="<?php $plxShow->urlRewrite('#wrapper') ?>">&nbsp;</a>
</div>
</body>
</html>