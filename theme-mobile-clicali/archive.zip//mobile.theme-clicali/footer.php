<?php if(!defined('PLX_ROOT')) exit; ?>
<a class="white button" href="#top">Haut de page</a>
<div id="footer">

	<p>
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> | Th&egrave;me par <a href="http://www.clicali.fr" title="Conception et Gestion de projet Internet">Clicali</a><br />
		
	</p>
</div>
</body>
</html>