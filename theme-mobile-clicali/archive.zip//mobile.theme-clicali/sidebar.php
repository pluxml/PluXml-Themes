<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div id="categories">
        <h2>Navigation</h2>
		<ul>
			<?php $plxShow->staticList('Accueil'); ?>
			<?php $plxShow->catList('','#cat_name'); ?>
		</ul>
         <h2>Derniers articles</h2>
		<ul>
			<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
		</ul>      
                
                  </div>
        <div class="navigation">
		<h2>Derniers commentaires</h2>
	<div id="chat">
            <div class="bubble left">
            <?php $plxShow->lastComList('<a href="#com_url">#com_author a dit :</a> <p class="lime">#com_content(70)</p>'); ?>
            </div>
        </div>
			
		
	
        </div>
</div>
<div class="clearer"></div>