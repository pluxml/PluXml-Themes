<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
		<div id="main">
			<h2 class="title-post"><?php $plxShow->staticTitle(); ?></h2>
			<div class="post"><?php $plxShow->staticContent(); ?></div>
		</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
