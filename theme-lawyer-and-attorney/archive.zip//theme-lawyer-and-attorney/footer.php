			<div id="footer">
				<p>&copy; <?php $plxShow->mainTitle('link'); ?> - <?php $plxShow->lang('POWERED_BY') ?> <a href="http://pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a></p>
				<p>Copyright &copy; 2010 &minus; Lawyer&amp;Attorney &middot; Design: Luka Cvrk, <a href="http://www.solucija.com" title="Free CSS Templates">Solucija</a> &not; <a href="http://www.lawyermarketinggroup.com/">Law Firm Marketing</a> - Adapté pour <a href="http://pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">Pluxml</a> par <a href="http://www.blogoflip.fr" title="BlogoFlip">Philippe MALADJIAN</a></p>
			</div>
		</div>
	</body>
</html>
