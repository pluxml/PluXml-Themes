<?php
/***********************************************************************
* Global variables used throughout this website. Please change them
* with extreme caution. Do not do so unless you know what you are
* doing.
***********************************************************************/

// This is the email all the contact forms will send you
$global_email		=	"email@example.com";
$GLOBALS['geg'] = $global_email;


// The SMPT type, change this depending on your host
// (leave the way it is if you don't know. Recommnended
// that you find out by contacting your hosting company)
$GLOBALS['smtp']		=	"smtpout.secureserver.net";

?>