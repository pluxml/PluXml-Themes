<?php include(dirname(__FILE__).'/header.php'); ?>

<body><div class="page-wrapper">
        <div class="slug-pattern slider-expand"><div class="overlay"><div class="slug-cut"></div></div></div>
        <div class="header">
			<?php include(dirname(__FILE__).'/navigation.php'); ?>
            
             <div class="shadow"></div>
            <div class="container">
                <div class="page-title">
                    <div class="rg"></div>
                    <h1>Gabarit Enzyme</h1>
                </div>
            </div>
        </div>
        
        <div class="body">
            <div class="body-round"></div>
            <div class="body-wrapper">
                <div class="side-shadows"></div>
                <div class="content">
                    <div class="nivoWrapper">
                        <div class="nivo-crop"></div>
                        <div class="preload">
                            <center><img src="<?php $plxShow->template(); ?>/images/design/preloader.gif" /></center>
                        </div>
                        <div class="nivo hide">

			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
						<img role="article" id="post-<?php echo $plxShow->artId(); ?>" src="img.php?src=<?php eval($plxShow->callHook("showVignette", "true")); ?>&w=960&h=430&crop-to-fit" class="scale-with-grid" title="<b><?php $plxShow->artTitle(''); ?></b>
                                <p><?php $plxShow->artChapo(''); ?></p>" />


			<?php endwhile; ?>




								</div>
                        <div class="nivo-crop-bottom"></div>
                    </div>
                    <div class="container callout">
                        
                        <div class="twelve columns">
                            <h4>Voici le gabarit <span>Enzyme</span>
						</div>
                        
                        <div class="four columns button-wrap">
                            <div class="wrapper"><a href="#" class="medium-button"><span>Bouton!</span></a></div>
                        </div>
                    </div>
                    <div class="callout-hr"></div>                        
						<div class="container">
                    
                        <div class="sixteen circles columns">
                            <ul>                                

								<?php 
								$arrayIcones = array('iphone','buoy','client','trophy');
								while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
									<li class="columns"  role="article" id="post-<?php echo $plxShow->artId(); ?>">
										<a href="<?php $plxShow->artUrl(); ?>">
											<div class="icon iphone">
												<div class="content">
													<div class="symbol"></div>
													<h5><?php $plxShow->artTitle('link'); ?></h5>
													<span class="hr"></span>
													<p><?php $plxShow->artChapo(''); ?></p>
												</div>
											</div>
										</a>
									</li>
								<?php endwhile; ?>
                                <div class="clear"></div>
                            </ul>
                        </div>    

                        <div class="sixteen columns">         
                            <!-- carousel starts -->
                            <div class="slidewrap">
                            	<div class="title-wrapper">
                                    <div class="section-title">
                                        <h4 class="title">Les derniers articles</h4>
                                    </div>
                                    <ul class="slidecontrols">
                                        <li><a href="#sliderName" class="next">Next</a></li>
                                        <li><a href="#sliderName" class="prev carousel-disabled">Prev</a></li>
                                    </ul>
                                    <span class="divider"></span>
                                    <div class="clear"></div>
                                </div>
                                <ul class="slider carousel" id="sliderName">
									<?php $compteur = 1;
									$bordure = array(1,4,7); 
									while($plxShow->plxMotor->plxRecord_arts->loop()): 
										if (in_array($compteur,$bordure)){ //première colonne
											echo '<li class="slide">
												<div class="one-third column alpha portfolio-item">
													<div class="content">
														<div class="border">
															<img class="scale-with-grid" src="img.php?src=';
															eval($plxShow->callHook("showVignette","true"));
															echo '&w=408&h=184&crop-to-fit" />
															<a href="images/untouched/woman-executives.jpg"  class="zoom prettyPhoto"></a>
															<a class="link" href="portfolio-standard-3.html"></a>
														</div>
														<h5>';
															$plxShow->artTitle('link');
														echo '</h5>
														<p>';
															$plxShow->artChapo('');
														echo '</p>
													</div>
													<div class="shadow"></div>
												</div>';
										} elseif (in_array($compteur+1,$bordure)){ //dernière colonne
												echo '<div class="one-third column omega portfolio-item">
													<div class="content">
														<div class="border">
															<img class="scale-with-grid" src="img.php?src=';
															eval($plxShow->callHook("showVignette","true"));
															echo '&w=408&h=184&crop-to-fit" />
															<a href="images/untouched/woman-executives.jpg" class="zoom prettyPhoto"></a>
															<a class="link" href="portfolio-standard-3.html"></a>
														</div>
														<h5>';
															$plxShow->artTitle('link');
														echo '</h5>
														<p>';
															$plxShow->artChapo('');
														echo '</p>
													</div>
													<div class="shadow"></div>
												</div>
											</li>';
										} else { //colonne "centrale"
											echo '<div class="one-third column portfolio-item">
												<div class="content">
													<div class="border">
															<img class="scale-with-grid" src="img.php?src=';
															eval($plxShow->callHook("showVignette","true"));
															echo '&w=408&h=184&crop-to-fit" />
														<a href="images/untouched/woman-executives.jpg" class="zoom prettyPhoto"></a>
														<a class="link" href="portfolio-standard-3.html"></a>
													</div>
														<h5>';
															$plxShow->artTitle('link');
														echo '</h5>
														<p>';
															$plxShow->artChapo('');
														echo '</p>
												</div>
												<div class="shadow"></div>
											</div>';
										}	
										$compteur++;
									endwhile; ?>
                                </ul>
                            </div><!-- end of carousel -->
                            <span class="empty-hr"></span>
                            
							<div class="two-thirds column alpha">
                            	<div class="title-wrapper">
                                    <div class="section-title">
                                        <h4 class="title">Liste accordéon</h4>
                                    </div>
                                    <span class="divider"></span>
                                    <div class="clear"></div>
                                </div>
                                <ul class="accordion" id="1">
                                    <li>
                                        <div class="parent first">
                                            <h6><div class="accordion-caption"></div>Partie un</h6>
                                        </div>
                                        <div class="tcontent">
                                            Praesent lacus quam, tempus pharetra aliquet vitae, venenatis non risus.
                                        </div>
                                    </li>
                                    <li>
                                        <div class="parent">
                                            <h6><div class="accordion-caption"></div>Partie deux</h6>
                                        </div>
                                        <div class="tcontent">
                                            Sit amet sodales neque. Morbi quis erat eros. Sed nec ligula ligula, id euismod mauris. Vestibulum in turpis metus. In volutpat fermentum ligula, et blandit quam ullamcorper quis.
                                        </div>
                                    </li>
                                    <li>
                                        <div class="parent">
                                            <h6><div class="accordion-caption"></div>Partie trois</h6>
                                        </div>
                                        <div class="tcontent">
                                         Duis sed vehicula dolor. Nunc consequat pretium nisl, nec malesuada nisi rutrum vel. Curabitur quis ante egestas sem tempor tempus at non magna. Aenean ultrices luctus metus, ut bibendum enim tincidunt quis. Aenean posuere tristique mauris a semper.
                                        </div>
                                    </li>
                                </ul>
							</div>
                            <div class="one-third column omega">
                            	<div class="title-wrapper">
                                    <div class="section-title">
                                        <h4 class="title">Témoignages</h4>
                                    </div>
                                    <span class="divider"></span>
                                    <div class="clear"></div>
                                </div>
                                <ul style="height: 190px;" class="style-2 slide testimonials clr overlap">
                                    <li style="position: relative; display: none;">
                                        <div class="quote">
                                        	<p>
                                        		PluXml, comme c'est génial!
                                            </p>
                                        </div>
                                        <div class="source">
                                        	<img src="<?php $plxShow->template(); ?>/images/testimonial.jpg">
                                        	<strong>Nico Tigulis
                                            	<a href="#">Contact Me</a>
                                            </strong>
                                            <div class="clear"></div>
                                        </div>
                                    </li>
                                    <li style="position: relative; display: none;">
                                        <div class="quote">
                                        	<p>
                                        		Bravo à Empirical Themes pour ce magnifique gabarit! 
                                            </p>
                                        </div>
                                        <div class="source">
                                        	<img src="<?php $plxShow->template(); ?>/images/testimonial.jpg">
                                        	<strong>movilwebs
                                            	<a href="#">Contact Me</a>
                                            </strong>
                                            <div class="clear"></div>
                                        </div>
                                    </li>
                                    <li style="position: absolute; display: list-item;">
                                    	 <div class="quote">
                                        	<p>
                                        		Bonne intégration.  N'hésitez pas à consulter le forum de PluXml pour assistance.
                                            </p>
                                        </div>
                                        <div class="source">
                                        	<img src="<?php $plxShow->template(); ?>/images/testimonial.jpg">
                                        	<strong>Chris Fale
                                            	<a href="#">Contact Me</a>
                                            </strong>
                                            <div class="clear"></div>
                                        </div>
                                    </li>
                                <ul class="content-slide-nav content-bullets">
								<li class="nav-bullet children" id="1"></li>
								<li class="nav-bullet children" id="2"></li>
								<li class="nav-bullet children active" id="3"></li>
								</ul></ul>
                            </div>
                            <div class="clear"></div>
                            <span class="hr"></span>
                            
                            <div class="callout intext">
                        
                                <div class="alpha twelve columns">
                                	<div class="content">
                                        <h4>Joignez la revolution PluXml!</h4>
                                        <p class="subtitle">Le CMS poids plume qui nous redonne le goût.  Toute la force d'un logiciel moderne sans les maux de tête.</p>
                                    </div>
                                </div>
                                
                                <div class="omega four columns">
                                   <div class="intext-button">
                                   		<a href="pluxml.org" class="big-button"><span>Osez!</span></a>
                                   </div>
                                </div>
                                
                                <div class="clear"></div>
                            </div>
                            <div class="title-wrapper">
                                <div class="section-title">
                                    <h4 class="title">Nos <strong>clients</strong></h4>
                                </div>
                                <ul class="slidecontrols">
                                    <li><a href="#clientSlider" class="next">Next</a></li>
                                    <li><a href="#clientSlider" class="prev carousel-disabled">Prev</a></li>
                                </ul>
                                    <span class="divider"></span>
                            	<div class="clear"></div>
                            </div>
                        </div>
                        
                        <div role="application" style="overflow: hidden; width: 100%;" class="clients columns sixteen slidewrap2">
                            <ul aria-activedescendant="carousel-1-1-slide0" style="margin-left: 0px; float: left; width: 200%; transition: margin-left 0.3s ease 0s;" class="slider carousel" id="clientSlider">
                                <li aria-hidden="false" id="carousel-1-1-slide0" role="tabpanel document" style="float: left; width: 50%;" class="slide carousel-active-slide">
                                    <div class="client alpha">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo1.png"></a>
                                    </div>
                                    <div class="client beta">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo2.png"></a>
                                    </div>
                                    <div class="client delta">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo3.png"></a>
                                    </div>
                                    <div class="client omega">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo4.png"></a>
                                    </div>
                                </li>
                                
                                <li aria-hidden="true" id="carousel-1-1-slide1" role="tabpanel document" style="float: left; width: 50%;" class="slide">
                                    <div class="client alpha">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo2.png"></a>
                                    </div>
                                    <div class="client beta">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo3.png"></a>
                                    </div>
                                    <div class="client delta">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo4.png"></a>
                                    </div>
                                    <div class="client omega">
                                        <a href="#"><img id="transparent" src="<?php $plxShow->template(); ?>/images/logo1.png"></a>
                                    </div>
                                </li>
                            </ul>
                            
                        </div>  
                        <div class="clear"></div>
                        <div class="sixteen columns">
                       		<span class="hr remove-bottom"></span>
                            <blockquote class="standard bottom">
                                "La révolution informatique fait gagner un temps fou aux hommes, mais ils le passent avec leur ordinateur !" <br>- Petit Comique
                            </blockquote>
                        </div>
                    </div> 
                </div>
            </div>
			
			
    <script type="text/javascript">
    <!--
        $(window).load(function(){
            $(".nivo.hide").fadeIn(1000);
            // Setup Slider
            $('.nivo').nivoSlider({
                effect: 'random', // Specify sets like: 'fold,fade,sliceDown'
                slices: 15, // For slice animations
                boxCols: 8, // For box animations
                boxRows: 4, // For box animations
                animSpeed: 500, // Slide transition speed
                pauseTime: 6000, // How long each slide will show
                startSlide: 0, // Set starting Slide (0 index)
                directionNav: true, // Next & Prev navigation
                controlNav: false, // 1,2,3... navigation
                controlNavThumbs: false, // Use thumbnails for Control Nav
                pauseOnHover: true, // Stop animation while hovering
                manualAdvance: false, // Force manual transitions
                prevText: 'Prev', // Prev directionNav text
                nextText: 'Next', // Next directionNav text
                randomStart: false, // Start on a random slide
                beforeChange: function(){}, // Triggers before a slide transition
                afterChange: function(){}, // Triggers after a slide transition
                slideshowEnd: function(){}, // Triggers after all slides have been shown
                lastSlide: function(){}, // Triggers when last slide is shown
                afterLoad: function(){} // Triggers when slider has loaded
            });
            $("a[class^='prettyPhoto']").prettyPhoto({social_tools: '' });
        });
        $(document).ready(function() {
            $('.slidewrap, .slidewrap2').carousel({
                slider: '.slider',
                slide: '.slide',
                slideHed: '.slidehed',
                nextSlide : '.next',
                prevSlide : '.prev',
                addPagination: false,
                addNav : false
            });
			$('.slide.testimonials').contentSlide();
        });
    // -->
    </script>

			
<?php include(dirname(__FILE__).'/footer.php'); ?>
