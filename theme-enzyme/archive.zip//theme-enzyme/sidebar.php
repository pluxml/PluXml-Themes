<?php if(!defined('PLX_ROOT')) exit; ?>

                        <div class="four columns">
                            <div class="sidebar">
                                <div class="sideborder"></div>
                                <h5><?php $plxShow->lang('LATEST_ARTICLES'); ?></h5>
                                <ul class="blogs">
									<?php eval($plxShow->callHook("vignetteArtList",  array('
									<li>
										<div class="border">
                                            
                                            <a href="#art_url" title="#art_title"><img src="img.php?src=#art_vignette&w=128&h=128&crop-to-fit" /></a>
                                        </div>
                                        <p>
                                            <a href="#art_url">#art_title</a>
                                            #art_chapo
                                            <span>#art_date</span>
                                        </p>
                                        <div class="clear"></div>
									</li>',$max=3, $cat_id="1", $ending="...", $sort="rsort"))); ?>		
                                </ul>
								
                                
                                <h5>En images</h5>
                                <ul class="img-list">
									<?php eval($plxShow->callHook("vignetteArtList",  array('
                                    <li>
										<div class="border">
											<a href="#art_url">
												<img src="img.php?src=#art_vignette&w=128&h=128&crop-to-fit" />
											</a>
										</div>
									</li>',$max=9, $cat_id="", $ending="", $sort="random"))); ?>		
                                    <div class="clear"></div>
                                </ul>
                                <div class="clear"></div>
                                
                                <div class="tabbed-area">  
                                    <ul class="tabs">  
                                        <li><a href="#" title="content_1" class="tab active"><?php $plxShow->lang('CATEGORIES'); ?></a></li>  
                                        <li><a href="#" title="content_2" class="tab"><?php $plxShow->lang('LATEST_ARTICLES'); ?></a></li>
                                        <div class="clear"></div>
                                    </ul>  
                                    
                                    <div id="content_1" class="tcontent">  
                                        <ul class="blogs">
											<?php $plxShow->catList('','
											<li id="#cat_id">
                                                <div class="border">
													<a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)
                                                </div>
                                                <div class="clear"></div>
											</li>'); ?>
                                            
                                            <!--li>
                                                <div class="border">
                                                    <a href="#"><img src="images/sidebar-mountain.jpg" /></a>
                                                </div>
                                                <p>
                                                    <a href="#">Responsive and Professional Design</a>
                                                    <span>September 23, 2012</span>
                                                </p>
                                                <div class="clear"></div>
                                            </li-->
                                        </ul>
                                    </div>  
                                    <div id="content_2" class="tcontent">  
                                       <ul class="blogs">
											<?php eval($plxShow->callHook("vignetteArtList",  array('
											<li>
                                                <div class="border">
                                                    <a href="#art_url"><img src="img.php?src=#art_vignette&w=60&h=55&crop-to-fit" /></a>
                                                </div>
                                                <p>
                                                    <a href="#art_url" title="#art_title">#art_title</a>
                                                    <span>#art_date</span>
                                                </p>
                                                <div class="clear"></div>
											</li>',$max=3, $cat_id="1", $ending="...", $sort="rsort"))); ?>		
                                        </ul>
                                    </div>
                                </div>
                                <h5><?php $plxShow->lang('TAGS'); ?></h5>
                                <ul class="cloud">
									<?php $plxShow->tagList('
									<li>
										<a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a>
									</li>', 20); ?>
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>    
