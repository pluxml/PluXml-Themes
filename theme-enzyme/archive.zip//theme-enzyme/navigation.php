<?php if (!defined('PLX_ROOT')) exit; ?>

<div class="nav">
	<div class="container">
		<!-- Standard Nav (x >= 768px) -->
		<div class="standard">
			<div class="five column alpha">
				<div class="logo">
					<a href="index.html"><img src="<?php $plxShow->template(); ?>/images/logo.png"></a><!-- Large Logo -->
				</div>
			</div>
			<div class="eleven column omega tabwrapper">
				<div class="menu-wrapper">
					<ul class="tabs menu">
						<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
						<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
					</ul>
				</div>
			</div>
		</div>
		<!-- Standard Nav Ends, Start of Mini -->
		
		<div class="mini">
			<div class="twelve column alpha omega mini">
				<div class="logo">
					<a href="index.html"><img src="<?php $plxShow->template(); ?>/images/logoMINI.png"></a><!-- Small Logo -->
				</div>
			</div>
			
			<div class="twelve column alpha omega navagation-wrapper">
				<select class="navagation">
					<option value="" selected="selected">Menu</option>
					<?php $plxShow->staticList('<option value="#static_url">'.$plxShow->getLang('HOME').'</option>'); ?>
					<?php $plxShow->pageBlog('<option value="#page_url">#page_name</option>'); ?>
				</select>
			</div>
		</div>
		<!-- Start of Mini Ends -->
	</div> 
</div>
            
