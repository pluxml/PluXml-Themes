<?php include(dirname(__FILE__).'/header.php'); ?>


<body><div class="page-wrapper">
        <div class="slug-pattern"><div class="overlay"><div class="slug-cut"></div></div></div>
        <div class="header">
            <?php include(dirname(__FILE__).'/navigation.php'); ?>
            
            <div class="shadow"></div>
            <div class="container">
                <div class="page-title">
                    <div class="rg"></div>
                    <!--h1>Page statique</h1-->
                </div>
            </div>
        </div>
        
        <div class="body">
            <div class="body-round"></div>
            <div class="body-wrapper">
                <div class="side-shadows"></div>
                <div class="content" role="article" id="static-page-<?php echo $plxShow->staticId(); ?>">
                    <div class="container callout standard">
                        
                        <div class="twelve columns">
                            <h1><?php $plxShow->staticTitle(); ?></h1>
                            <p class="link-location">
								<a href="."><?php echo $plxShow->getLang('HOME');?></a> / <a href="#"><?php $plxShow->staticTitle(); ?></a>
							</p>
                        </div>
                        
                        <div class="four columns button-wrap">
                             <div class="wrapper search">
                                <form action="">
                                    <input type="text" class="search-box" name="" value="" placeholder='Search...' />
                                    <input type="image" src="<?php $plxShow->template(); ?>/images/design/search-icon.png" class="searchbox-submit" value=""/>
                                </form>
                            </div>	
                        </div>
                    </div>
                    <div class="callout-hr"></div>                        
                    <div class="container">
                    
                        <div class="twelve columns">
                        
                            <div class="blog post">
								<?php $plxShow->staticContent(); ?>
                            </div><!-- Blog Ends -->
                          
                        </div>
						
						<?php include(dirname(__FILE__).'/sidebar.php'); ?>                                
                        
						<div class="clear"></div>
                                            
                        <div class="sixteen columns">
                       		<span class="hr lip-quote"></span>
                            <blockquote class="standard bottom">
                                "Making the simple complicated is commonplace; making the complicated simple, awesomely simple, that's creativity" <br />- Charles Mingus
                            </blockquote>
                        </div>
        
                    </div>
                </div>
            </div>
			
			
<?php include(dirname(__FILE__).'/footer.php'); ?>
