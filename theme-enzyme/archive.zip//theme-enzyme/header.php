<?php if (!defined('PLX_ROOT')) exit; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]--><!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]--><!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]--><!--[if (gte IE 9)|!(IE)]><!--><!--<![endif]--><head>

<meta charset="utf-8">
<title><?php $plxShow->pageTitle(); ?></title>
<?php $plxShow->meta('description') ?>
<?php $plxShow->meta('keywords') ?>
<?php $plxShow->meta('author') ?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link media="screen" charset="utf-8" rel="stylesheet" href="<?php $plxShow->template(); ?>/css/base.css">
<link media="screen" charset="utf-8" rel="stylesheet" href="<?php $plxShow->template(); ?>/css/skeleton.css">
<link media="screen" charset="utf-8" rel="stylesheet" href="<?php $plxShow->template(); ?>/css/layout.css">
<link media="screen" charset="utf-8" rel="stylesheet" href="<?php $plxShow->template(); ?>/css/child.css">
<link href="<?php $plxShow->template(); ?>/css/nivo-slider.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8">
<!--[if (IE 6)|(IE 7)]>
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/ie.css" type="text/css" media="screen" />
<![endif]-->
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript" style="color: rgb(0, 0, 0);" language="javascript" src="<?php $plxShow->template(); ?>/js/jquery-1-8-2.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/default.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.nivo.slider.pack.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.carousel.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.color.animation.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.prettyPhoto.js" charset="utf-8"></script>

<!-- color pickers -->
<link rel="stylesheet" media="screen" type="text/css" href="<?php $plxShow->template(); ?>/css/colorpicker.css" />
<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/colorpicker.js"></script>
<!-- end of color pickers -->

</head>
