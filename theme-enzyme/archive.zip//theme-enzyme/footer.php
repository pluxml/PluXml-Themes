<?php if (!defined('PLX_ROOT')) exit; ?>

			<div class="footer style-2">
            	<div class="background"><div class="stitch"></div></div>
                <div class="foot-nav-bg"></div>
            	<div class="content">
                    <div class="patch"></div>
                    <div class="blur"></div>
                    <div class="pattern">
                        <div class="container">
                        	<div class="stitch"></div>
                            <div class="sixteen columns">
                                <div class="first column alpha">
                                
                                    <div class="left"><div style="opacity: 0;" class="logo-caption-overlay"></div>
                                        <div class="logo-caption"></div>
                                        <h5>Enzyme</h5>
                                        <p>
                                            Integer eu ante in arcu viverra vehicula donec tempus consequat faucibus. Donec ne thomp nibh egestas suscipit. Donec sed lacus at massa lorem
                     pharetra id eleifend leo.
                     					</p>
                                        <p class="extra">
                                            Pellentesque quis felis neque, id adipiscing nunc. Ipsum elit, vitae tempus tellus. Class aptent taciti sociosq desis torquent per conubia nostra, per inceptos himenae dolar eget lacinia sem.
                                        </p>
                                    </div>
                                </div>
                                <div class="column ct">
                                    <h5>Recent Tweets:</h5>
                                    <ul class="twitter" id="twitter_update_list"><li>Twitter is loading</li></ul>
                                </div>
                                <div class="last column omega">
                                    <h5>Join our Mailing List</h5>
                                    
                                    <div class="input-wrapper">
                                        <input style="font-style: italic;" placeholder="Email..." id="email" name="email" type="text">
                                    </div>
                                    <div class="right">
                                    	<a href="#" class="button color"><span>Join</span></a>
                                    </div>
                                    <div class="clear"></div>
                                    <span class="hr"></span>
                                    <h5>Stay in Touch</h5>
                                    <ul class="sm foot">
                                        <li class="facebook"><a href="#facebook"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-facebook-hover.png&quot;)"></div>Facebook</a></li>
                                        <li class="twitter"><a href="#twitter"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-twitter-hover.png&quot;)"></div>LinkedIn</a></li>
                                        <li class="linkedin"><a href="#linkedin"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-linkedin-hover.png&quot;)"></div>Pinterest</a></li>
                                        <li class="pinterest"><a href="#pinterest"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-pinterest-hover.png&quot;)"></div>Pinterest</a></li>
                                        <li class="dribbble"><a href="#dribbble"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-dribbble-hover.png&quot;)"></div>Pinterest</a></li>
                                        <li class="flickr"><a href="#flickr"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-flickr-hover.png&quot;)"></div>Pinterest</a></li>
                                        <li class="flavors"><a href="#flavors"><div class="overlay" style="background-image:url(&quot;http://ambiancemedia.ca/_DEV/pluxml/themes/_enzyme/images/icons/sm_icons/round/icon-flavors-hover.png&quot;)"></div>Pinterest</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="sixteen columns alpha omega">
                        	<div class="foot-nav-bg"></div>
                            <div class="foot-nav">
                                <div class="copy" style="color:fff;">
                                    &copy; 2015 <?php $plxShow->mainTitle(); ?> - 
									Gabarit par Empirical Themes - 
									<a style="color:fff;" rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>">
										<?php $plxShow->lang('ADMINISTRATION') ?>
									</a>
                                </div>
                                <div class="nav">
 				<?php $plxShow->staticList($plxShow->getLang('HOME'),'<a href="#static_url" id="#static_id" title="#static_name">#static_name</a>'); ?>
				<?php $plxShow->pageBlog('<a class="#page_status" href="#page_url" title="#page_name">#page_name</a>'); ?>
                               	</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>



    <script type="text/javascript">

    <!--
	
	
	
        $(window).load(function(){
            // Setup Slider
            $(".asyncslider.hide").fadeIn(600);
            $(".asyncslider").asyncSlider({
                keyboardNavigate: true,
                autoswitch: 4000,
                slidesNav: true,
                easing: 'easeInOutExpo',
                minTime: 700,
                maxTime: 1600, 
            });
            
            $("a[class^='prettyPhoto']").prettyPhoto({social_tools: '' });
        });
        $(document).ready(function() {
            $('.slidewrap, .slidewrap2').carousel({
                slider: '.slider',
                slide: '.slide',
                slideHed: '.slidehed',
                nextSlide : '.next',
                prevSlide : '.prev',
                addPagination: false,
                addNav : false
            });
			$('.slide.testimonials').contentSlide();
        });
    // -->
    </script>

    <script type="text/javascript">
	$(document).ready(function() {
            $('.slidewrap2').carousel({
                slider: '.slider',
                slide: '.slide',
                slideHed: '.slidehed',
                nextSlide : '.next',
                prevSlide : '.prev',
                addPagination: false,
                addNav : false
            });
        });
        $(window).load(function(){
             $("a[class^='prettyPhoto']").prettyPhoto({social_tools: '' });
             // cache container
            var $container = $('#isotope-container');
            // initialize isotope
            $container.isotope({
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                },
                layoutMode : 'fitRows'
            });
            // filter items when filter link is clicked
            $('#filters a').click(function(){
                $("#filters a.active").removeClass('active');
                $(this).addClass('active');
                var selector = $(this).attr('data-filter');
                $container.isotope({ filter: selector });
                return false;
            });
        });
    
    </script>
	
	<script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
    <script type="text/javascript" src="http://api.twitter.com/1/statuses/user_timeline/EmpiricalThemes.json?callback=twitterCallback2&amp;count=2"></script>
	</div>


</body></html>