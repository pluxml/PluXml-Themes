<?php include(dirname(__FILE__).'/header.php'); ?>
<body>
	<div class="page-wrapper">
        <div class="slug-pattern"><div class="overlay"><div class="slug-cut"></div></div></div>
        <div class="header">

			<?php include(dirname(__FILE__).'/navigation.php'); ?>
           
            <div class="shadow"></div>
            <!--div class="container">
                <div class="page-title">
                    <div class="rg"></div>
                    <h1>Our Blog</h1>
                </div>
            </div-->
        </div>
        
        <div class="body">
            <div class="body-round"></div>
            <div class="body-wrapper">
                <div class="side-shadows"></div>
                <div class="content">
                    <div class="container callout standard">
                        
                        <div class="twelve columns">
                            <h1><?php $plxShow->catName(); ?></h1>
                            <p class="link-location"><a href="."><?php echo $plxShow->getLang('HOME'); ?></a> / <a href="#"><?php $plxShow->catName(); ?></a></p>
                        </div>
                        
                        <div class="four columns button-wrap">
                             <div class="wrapper search">
                                <form action="">
                                    <input type="text" class="search-box" name="" value="" placeholder='Search...' />
                                    <input type="image" src="<?php $plxShow->template(); ?>/images/design/search-icon.png" class="searchbox-submit" value=""/>
                                </form>
                            </div>	
                        </div>
                    </div>
                    <div class="callout-hr"></div>                        
                    <div class="container">
                    
                        <div class="twelve columns">

							<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
								<div class="blog style-2">
									<div class="border">
										<img class="scale-with-grid" src="<?php $plxShow->template(); ?>/images/blog-arch.jpg" />
										<a class="link" href="blog-post.html"></a>
									</div>
									<div class="meta">
										<p><span><?php $plxShow->lang('WRITTEN_BY'); ?>:</span> <?php $plxShow->artAuthor() ?></p>
										<p><span>Date:</span> <?php $plxShow->artDate('#num_day #month'); ?></p>
										<p><span><?php $plxShow->lang('CLASSIFIED_IN') ?>:</span> <?php $plxShow->artCat() ?></p>
										<p><span><?php $plxShow->artNbCom(); ?></span></p>
									</div>
									<div class="description">
										<h2><?php $plxShow->artTitle('link'); ?></h2>
										<p><?php $plxShow->artChapo(); ?></p>
									</div>
									<div class="clear"></div>
									<div class="foot"></div>
								</div><!-- Blog Ends -->
							<?php endwhile; ?>

                            <div class="pagination">
                                <span><?php $plxShow->pagination(); ?></span>
                                <!--ul class="pages">
                                    <li class="active"><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <div class="clear"></div>
                                </ul-->
                            </div>
                        </div>
						
						<?php include(dirname(__FILE__).'/sidebar.php'); ?>                                
                                
                        <div class="clear"></div>
                                            
                        <!--div class="sixteen columns">
                       		<span class="hr lip-quote"></span>
                            <blockquote class="standard bottom">
                                "Making the simple complicated is commonplace; making the complicated simple, awesomely simple, that's creativity" <br />- Charles Mingus
                            </blockquote>
                        </div-->
        
                    </div>
                </div>
            </div>
			
			<?php include(dirname(__FILE__).'/footer.php'); ?>
