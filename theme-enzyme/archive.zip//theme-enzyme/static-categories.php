<?php include(dirname(__FILE__).'/header.php'); ?>
<body>
	<div class="page-wrapper">
        <div class="slug-pattern">
			<div class="overlay">
				<div class="slug-cut"></div>
			</div>
		</div>
        <div class="header">
			<?php include(dirname(__FILE__).'/navigation.php'); ?>
		
            <div class="shadow"></div>
            <div class="container">
                <div class="page-title">
                    <div class="rg"></div>
                    <h1><?php $plxShow->lang('CATEGORIES'); ?></h1>
                </div>
            </div>
        </div>
        
        <div class="body">
            <div class="body-round"></div>
            <div class="body-wrapper">
                <div class="side-shadows"></div>
                <div class="content">
                    <!--div class="container callout standard">
                        
                        <div class="twelve columns">
                            <h4>Company’s Latest News</h4>
                            <p class="link-location">You are here: <a href="index.html">Home</a> / <a href="#">Some Link</a> / <a href="#">Current Page</a></p>
                        </div>
                        
                        <div class="four columns button-wrap">
                             <div class="wrapper search">
                                <form action="">
                                    <input type="text" class="search-box" name="" value="" placeholder='Search...' />
                                    <input type="image" src="/images/design/search-icon.png" class="searchbox-submit" value=""/>
                                </form>
                            </div>	
                        </div>
                    </div-->
                    <div class="callout-hr"></div>                        
                    <div class="container">
                        <div class="sixteen columns">

							<?php $maListe = $plxShow->catListArray(); ?>

							<div class="filter">
                                <!--h5>Filter Display:</h5-->
                                <ul id="filters" class="options pagination">
                                    <li><a href="#" data-filter="*" class="active">Toutes</a></li>
									<?php 
									foreach ($maListe as $ligne){
										echo '<li><a href="#" data-filter="#'.$ligne['catCleanName'].'">'.$ligne['catName'].'</a></li>';
									}
									?>
                                </ul>
                                <div class="clear"></div>
                            </div>
                       
                            <!-- Isotope Begins -->
                            <div class="portfolio standard three">
                                <div id="isotope-container" class="portfolio-container">
									<?php foreach ($maListe as $ligne){
										eval($plxShow->callHook("vignetteArtList", array('
										<div class="item" id="'.$ligne['catCleanName'].'">
											<div class="border">
												<a href="#art_vignette" class="prettyPhoto">
													<img src="img.php?src=#art_vignette&w=290&h=190&crop-to-fit" class="scale-with-grid grey" />
												</a>
											</div>
											<h5><a href="#art_url">#art_title</a></h5>
											<p>#art_chapo</p>
											<div class="shadow"></div>
										</div>', 99, $ligne['catNum'],'', "sort"))); 	
									} ?>
                                </div>                            
                            </div>
                        </div>
                        <div class="clear"></div>
						<div class="sixteen columns">
                       		<span class="hr lip-quote"></span>
                            <blockquote class="standard bottom">
                                "Ne pas oublier de remplacer dans core/lib le fichier class.plx.show.php par celui du même nom inclus dans le répertoire de Documentation.  Ne vous en faites pas, il a été très peu modifié, une seule nouvelle fonction a été ajoutée au tout début." <br />- Votre humble programmeur
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.slidewrap2').carousel({
                slider: '.slider',
                slide: '.slide',
                slideHed: '.slidehed',
                nextSlide : '.next',
                prevSlide : '.prev',
                addPagination: false,
                addNav : false
            });
        });
        $(window).load(function(){
             $("a[class^='prettyPhoto']").prettyPhoto({social_tools: '' });
             // cache container
            var $container = $('#isotope-container');
            // initialize isotope
            $container.isotope({
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                },
                layoutMode : 'fitRows'
            });
            // filter items when filter link is clicked
            $('#filters a').click(function(){
                $("#filters a.active").removeClass('active');
                $(this).addClass('active');
                var selector = $(this).attr('data-filter');
                $container.isotope({ filter: selector });
                return false;
            });
        });
    
    </script>

<?php include(dirname(__FILE__).'/footer.php'); ?>
