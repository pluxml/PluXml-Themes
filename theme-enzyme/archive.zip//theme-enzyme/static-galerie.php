<?php include(dirname(__FILE__) . '/header.php'); ?>

<body><div class="page-wrapper">
        <div class="slug-pattern"><div class="overlay"><div class="slug-cut"></div></div></div>
        <div class="header">

			<?php include(dirname(__FILE__).'/navigation.php'); ?>
            
            <div class="shadow"></div>
            <div class="container">
                <div class="page-title">
                    <div class="rg"></div>
                    <h1>Galerie photo</h1>
                </div>
            </div>
        </div>
        
        <div class="body">
            <div class="body-round"></div>
            <div class="body-wrapper">
                <div class="side-shadows"></div>
                <div class="content">
                    <div class="container callout standard">
                        
                        <div class="twelve columns">
                            <h4>Company�s Latest News</h4>
                            <p class="link-location">You are here: <a href="index.html">Home</a> / <a href="#">Some Link</a> / <a href="#">Current Page</a></p>
                        </div>
                        
                        <div class="four columns button-wrap">
                             <div class="wrapper search">
                                <form action="">
                                    <input type="text" class="search-box" name="" value="" placeholder='Search...' />
                                    <input type="image" src="<?php $plxShow->template(); ?>/images/design/search-icon.png" class="searchbox-submit" value=""/>
                                </form>
                            </div>	
                        </div>
                    </div>
					
					
					
					
					
					
                    <div class="callout-hr"></div>                        
                    <div class="container">
                        <div class="sixteen columns">
                        
                            <div class="filter">
                            
                                <h5>Filter Display:</h5>
                                <ul id="filters" class="options pagination">
                                    <li><a href="#" data-filter="*" class="active">All</a></li>
                                    <li><a href="#" data-filter="#construction">Construction</a></li>
                                    <li><a href="#" data-filter="#revelation">Revelation</a></li>
                                </ul>
                                <div class="clear"></div>
                                
                            </div>
                       
                            <!-- Isotope Begins -->
                            <div class="portfolio standard three">
                                <div id="isotope-container" class="portfolio-container">
                                    <div class="item" id="construction">
                                        <div class="border">
                                            <a href="<?php $plxShow->template(); ?>/images/untouched/dancing-fashion.jpg" class="prettyPhoto">
											<img src="<?php $plxShow->template(); ?>/images/portfolio-dancing-fashion.jpg" class="scale-with-grid grey" />
											</a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Construction</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="construction">
                                        <div class="border"><a href="<?php $plxShow->template(); ?>/images/untouched/woman-streaming.jpg" class="prettyPhoto">
										<img src="<?php $plxShow->template(); ?>/images/portfolio-woman-streaming.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Construction</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="revelation">
                                        <div class="border">
										<a href="<?php $plxShow->template(); ?>/images/untouched/target.jpg" class="prettyPhoto">
										<img src="<?php $plxShow->template(); ?>/images/portfolio-target.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Revelation</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="clear"></div>
                                    <div class="item" id="revelation">
                                        <div class="border"><a href="<?php $plxShow->template(); ?>/images/untouched/business-model.jpg" class="prettyPhoto">
										<img src="<?php $plxShow->template(); ?>/images/portfolio-business-model.jpg" class="scale-with-grid grey" /></a></div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Revelation</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="construction">
                                        <div class="border"><a href="images/untouched/glam.jpg" class="prettyPhoto"><img src="images/portfolio-glam.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Construction</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="revelation">
                                        <div class="border"><a href="images/untouched/woman-laptop.jpg" class="prettyPhoto"><img src="images/portfolio-woman-laptop.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Revelation</p>
                                        <div class="shadow"></div>
                                    </div>
                                    
                                    <div class="item" id="revelation">
                                        <div class="border"><a href="images/untouched/woman-executives.jpg" class="prettyPhoto"><img src="images/portfolio-woman-executives.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Revelation</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="construction">
                                        <div class="border"><a href="images/untouched/businessman-colleages.jpg" class="prettyPhoto"><img src="images/portfolio-businessman-colleages.jpg" class="scale-with-grid grey" /></a>  
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Construction</p>
                                        <div class="shadow"></div>
                                    </div>
                                    <div class="item" id="revelation">
                                        <div class="border"><a href="images/untouched/dancing-fashion.jpg" class="prettyPhoto"><img src="images/portfolio-dancing-fashion.jpg" class="scale-with-grid grey" /></a>
                                        </div>
                                        <h5><a href="#">Portfolio Title Goes Here</a></h5>
                                        <p>Revelation</p>
                                        <div class="shadow"></div>
                                    </div>
                                </div>                            
                            </div>
    
    
                            
                            <!-- Isotope Ends -->  	
                        </div>
                        <div class="clear"></div><div class="sixteen columns">
                       		<span class="hr lip-quote"></span>
                            <blockquote class="standard bottom">
                                "Making the simple complicated is commonplace; making the complicated simple, awesomely simple, that's creativity" <br />- Charles Mingus
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
<?php include(dirname(__FILE__).'/footer.php'); ?>

