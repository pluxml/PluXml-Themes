<?php if(!defined('PLX_ROOT')) exit; ?>

	<aside class="aside col sml-12 med-4" >

		<h3 class="marque">
			<?php $plxShow->lang('CATEGORIES'); ?>
		</h3>

		<ul class="cat-list unstyled-list">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>

		<h3 class="marque">
			<?php $plxShow->lang('LATEST_ARTICLES'); ?>
		</h3>

		<ul class="lastart-list unstyled-list">
						<?php $plxShow->lastArtList('<li ><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>', 20); ?>
		</ul>

        

    	<h3 class="marque">
		<?php eval($plxShow->callHook('showBlogrollHead')); ?>
		</h3>
		<ul>
		<?php eval($plxShow->callHook('showBlogroll', array('', 'article'))); ?>
		</ul>

		<h3>
			RSS
		</h3>
			<ul class="rss-list unstyled-list">
				<li class="rssli"><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
				<li class="rssli"><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
			</ul>

	</aside>
