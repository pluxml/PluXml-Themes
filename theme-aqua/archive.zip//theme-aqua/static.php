<?php include('header.php'); # On insere le header ?>
<div id="page">
	<div id="content"><div class="post">
		<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
		<?php $plxShow->staticContent(); ?>
	</div></div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
</div></div>
<?php include('footer.php'); # On insere le footer ?>
