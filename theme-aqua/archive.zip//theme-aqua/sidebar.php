<div id="sidebar">
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('Accueil','#cat_name'); ?>
		</ul>
	</div>
	<div id="syndication">
		<h2>Syndication</h2>
		<ul>
			<p id="feed"><?php $plxShow->artFeed('atom'); ?></p>
			<p id="feed"><?php $plxShow->comFeed('atom'); ?></p>
		</ul>
	</div>
</div>
<div class="clearer"></div>