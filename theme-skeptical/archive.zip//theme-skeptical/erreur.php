<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="content" class="col-full">
	<div id="main" class="col-left">
		<div class="post page">
			<p class="center"><?php $plxShow->erreurMessage(); ?></p>
			<p class="center"><a href="./" title="Accueil du site">Retour page d'accueil</a></p>
		</div>
	</div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>