<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="content">
	<div id="page-full-width">
		<h2><?php $plxShow->staticTitle(); ?></h2>
		<?php $plxShow->staticContent(); ?>
	</div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
