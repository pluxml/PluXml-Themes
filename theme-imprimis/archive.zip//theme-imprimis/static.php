<?php include('header.php'); # On insere le header ?>
<div id="page">

<div id="content">
				<h1 id="welcome"><?php $plxShow->staticTitle(); ?></h1>
				<?php $plxShow->staticContent(); ?>
		
</div>


<?php include('sidebar.php'); # On insere la sidebar ?>
<div style="clear: both; height: 1px"></div>
</div>
<?php include('footer.php'); # On insere le footer ?>