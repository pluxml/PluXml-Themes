<?php include('header.php'); # On insere le header ?>
<div id="page">

<div id="content">

	<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
	
		<div id="welcome"><h1><?php $plxShow->artTitle('link'); ?></h1></div>
		
		<?php $plxShow->artChapo(); ?>
		
		<div id="post-info"><?php $plxShow->artDate(); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?> | <?php $plxShow->artNbCom('link'); ?>
        </div>
	
	<?php endwhile; # Fin de la boucle sur les articles ?>
	
		<?php $plxShow->pagination(); ?>
	
</div>

<?php include('sidebar.php'); # On insere la sidebar ?>
<div style="clear: both; height: 1px"></div>
</div>
<?php include('footer.php'); # On insere le footer ?>