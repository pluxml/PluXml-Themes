<div id="sidebar">
	
		<h2>Derniers articles</h2>
		<ul id="submenu">
			<?php $plxPlugin->lastArtList(); ?>
		</ul>

	
		<h2>Cat&eacute;gories</h2>
		<ul id="submenu">
			<?php $plxShow->catList('','#cat_name (#art_nb)'); ?>
		</ul>
		
		<div id="feed"><b><a href="./feed.php?atom" id="feed">Fil des articles</a></b></div>

</div>

