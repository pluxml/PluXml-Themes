<?php include('header.php'); # On insere le header ?>
<div id="page">

<div id="content">

		<div id="welcome"><h1><?php $plxShow->artTitle('link'); ?></h1></div>
		<?php $plxShow->artContent(); ?>
		<div id="post-info"><?php $plxShow->artDate(); ?> | Par <?php $plxShow->artAuthor(); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?>
		</div>
	<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
	<h1><?php $plxShow->artNbCom(); ?></h1>
	
		<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
		
			
			
				<div id="comment">Par <?php $plxShow->comAuthor('link'); ?> le <?php $plxShow->comDate(); ?></div>
				<?php $plxShow->comContent() ?>
			
	
		<?php endwhile; # Fin de la boucle sur les commentaires ?>
		<?php # On affiche le fil Atom de cet article ?><br/><br/>
		
		<p align="right"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></p>
		
	<?php endif; # Fin du if sur la prescence des commentaires ?>
	<?php # Si on autorise les commentaires ?>
	<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
	<h1>Laisser un message</h1>
		<form action="./?<?php $plxShow->get(); ?>#commentform" method="post" id="commentform">
			Votre commentaire
			<p><textarea name="content" id="comment"><?php $plxShow->comGet('content',''); ?></textarea></p>		
			<p><input type="text" name="name" id="author" class="text" value="<?php $plxShow->comGet('name',''); ?>" />
			<label for="author">Nom </label></p>
			<p><input type="text" name="mail" id="email" class="text" value="<?php $plxShow->comGet('mail',''); ?>" />
			<label for="email">Mail</label></p>
			<p><input type="text" name="site" id="url" class="text" value="<?php $plxShow->comGet('site','http://'); ?>" />
			<label for="url">Site (facultatif)</label></p>
			<?php # Affichage du capcha anti-spam
			if($plxShow->plxMotor->aConf['capcha']): ?>
				<label for="captcha"><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label>
				<p><?php $plxShow->capchaQ(); ?><br />
				<input name="rep" type="text" id="captcha" class="text" size="10" /></p>
				<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
			<?php endif; # Fin du if sur le capcha anti-spam ?>
			<p><input name="submit" type="submit" id="submit" value="Envoyer" /></p>
		</form>
	<?php endif; # Fin du if sur l'autorisation des commentaires ?>

	
</div>
<?php include('sidebar.php');?>
<div style="clear: both; height: 1px"></div>
</div>
<?php include('footer.php');?>