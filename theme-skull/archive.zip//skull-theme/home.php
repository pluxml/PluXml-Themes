<?php include('header.php'); # On insere le footer ?>
<div id="page"><div id="footer">
	<p>
		Bienvenue sur mon blog =D <a href="#top"></a>
	</p>
</div>
	<div id="content">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
			<div class="post">
				<h2 class="title"><img class="imgskull" src="<?php $plxShow->template(); ?>/img/info.gif" width="41" height="35" />
			    <?php $plxShow->artTitle('link'); ?></h2>
				<p class="post-info">Cat&eacute;gorie : <?php $plxShow->artCat(); ?> | le <?php $plxShow->artDate(); ?></p>
				<?php $plxShow->artChapo(); ?>
			  <p class="comment_nb"><img src="<?php $plxShow->template(); ?>/img/com_top.jpg" alt="commentaire" /><br />
<?php $plxShow->artNbCom('link'); ?>
<br />
<img src="<?php $plxShow->template(); ?>/img/com_bottom.jpg" alt="commentaire" /></p>
	  </div>
		<?php endwhile; # Fin de la boucle sur les articles ?>
		<?php # On affiche la pagination ?>
		<p id="pagination"><?php $plxShow->pagination(); ?></p>
	</div>
</div>
<?php include('footer.php'); # On insere le footer ?>
</body>
</html>