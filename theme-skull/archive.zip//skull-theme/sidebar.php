<div id="sbar">
  <table width="100%" height="250" border="0" cellpadding="0" cellspacing="10">
    <tr>
      <td width="39%" rowspan="2"><div id="div">
        <h2>Profil de l'auteur </h2>
        <p align="left"><img id="profil" src="<?php $plxShow->template(); ?>/img/profil.jpg" alt="" width="161" height="185" border="4" />Blablablablabla moi, moi-m&ecirc;me, moi je, moi personnellement, ma petite personne...Ma famille, ma femme, mon furet, ma flute, ma fille, mon fouet =) On m'aime on s'aime on vous aime on travail beaucoup beaucoup beacoup ! </p>
        <p>&nbsp;</p>
      </div></td>
      <td width="27%"><div id="categories">
    <h2>Cat&eacute;gories</h2>
	<ul>
      <div align="left">
        <?php $plxShow->catList('Accueil','#cat_name'); ?>
      </div>
	</ul>
  </div></td>
      <td width="34%"><h2 align="left">Divers</h2>
        <p align="left">Vous pouvez vous servir de cette colonne comme bon vous semble! Mauvais vous semble ! Muhahahaha =D </p></td>
    </tr>
    <tr>
      <td width="27%"><div id="syndication">
        <h2>Syndication</h2>
        <ul>
          <div align="left">
            <?php $plxShow->artFeed('atom'); ?>
            <br />
            <?php $plxShow->comFeed('atom'); ?>
          </div>
        </ul>
      </div></td>
      <td width="34%">&nbsp;</td>
    </tr>
  </table>
</div>