<?php include('header.php'); # On insere le header ?>
<div id="page"><div id="footer">
	<p>
		Bienvenue sur mon blog =D <a href="#top"></a>
	</p>
</div>
	<div id="content">
		<h2 class="title"><img class="imgskull" src="<?php $plxShow->template(); ?>/img/info.gif" width="41" height="35" /><?php $plxShow->staticTitle(); ?></h2>
		<?php $plxShow->staticContent(); ?>
	</div>
</div>
<?php include('footer.php'); # On insere le footer ?>
</body>
</html>
