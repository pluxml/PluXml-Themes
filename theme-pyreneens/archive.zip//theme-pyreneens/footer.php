<?php if(!defined('PLX_ROOT')) exit; ?>
</div>
<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | 
		Design de Rockmount |
		<a href="core/admin/">Administration</a> | 
		<a href="#header">Haut de page</a>
	</p>
</div>
</body>
</html>