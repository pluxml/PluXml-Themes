<?php if(!defined('PLX_ROOT')) exit; ?>
	</div>
	</div>
		<div id="footer">
			<p>&copy; <?php $plxShow->mainTitle('link'); ?> - 
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a> 
		en <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?> | 
				<a href="core/admin/">Administration</a> | 
				thème par <a href="http://blackandblue.fr">blackandblue</a>
			</p>
		</div>
</body>
</html>