<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">

	<div class="block">
		<h3>Cat&eacute;gories</h3>
		<ul>
			<?php $plxShow->catList(); ?>
		</ul>
	</div>
	
	<div class="block">
		<h3>Derniers articles</h3>
		<ul>
			<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
		</ul>
	</div>
	
	<div class="block">
		<h3>Derniers commentaires</h3>
		<ul>
			<?php $plxShow->lastComList('<a href="#com_url">#com_author a dit :</a><br/>#com_content(70)'); ?>
		</ul>
	</div>

</div>