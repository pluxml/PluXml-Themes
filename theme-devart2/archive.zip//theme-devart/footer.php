<?php if(!defined('PLX_ROOT')) exit; ?>
	</div>
	
	<div id="wrapper-bottom"></div>
	
	<div id="footer"><div id="footer-inner"><div id="footer-content">
		<p>
			G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> | 
			Th&eacute;me par <a href="http://deniart.ru">deniart</a></p>
		</p>
		<p><a href="core/admin/">Administration</a> | <a href="#top">Haut de page</a>.
	</div></div></div>
</div>

</body>
</html>