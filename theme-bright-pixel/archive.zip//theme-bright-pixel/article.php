<?php include('header.php'); # On insere le header ?>
<div class="content">
<br /><div class="item">
		<div class="post">
			<h1><?php $plxShow->artTitle(); ?></h1>
<div class="descr">Post&eacute; le <?php $plxShow->artDate(); ?></div>
				<div class="entry"><?php $plxShow->artContent(); ?></div>
								<br />
								<p class="info"><?php $plxShow->artCat(); ?></p>
								<div class="divider"></div><br />
		<?php # Si on a des commentaires ?>
		<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
			<div class="commentlist">
				<h1>Commentaires</h1>
				<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
					<li "<?php $plxShow->comId(); ?>" class="graybox">
						<div class="info_comment"><p>Par <?php $plxShow->comAuthor('link'); ?> <small class="commentmetadata">le <?php $plxShow->comDate(); ?></small></p></div>
						<blockquote><p><?php $plxShow->comContent() ?></p></blockquote>
					</li>
				<?php endwhile; # Fin de la boucle sur les commentaires ?>
				<?php # On affiche le fil Atom de cet article ?>
				<div class="feed_article"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>
			</div>
		<?php endif; # Fin du if sur la prescence des commentaires ?>
		<?php # Si on autorise les commentaires ?>
		<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
			<div >
				<br /><h1>Ecrire un commentaire</h1>
				<p class="message_com"><?php $plxShow->comMessage(); ?></p>
				<form action="./?<?php $plxShow->get(); ?>#form" method="post" id="commentform">
						<label>Nom&nbsp;:</label>
                        <br />
                        <input name="name" type="text" size="30" value="<?php $plxShow->comGet('name',''); ?>" maxlength="30" /><br />
						<label>Site (facultatif)&nbsp;:</label>
						<br />
						<input name="site" type="text" size="30" value="<?php $plxShow->comGet('site','http://'); ?>" /><br />
						<label>E-mail (facultatif)&nbsp;:</label>
						<br />
						<input name="mail" type="text" size="30" value="<?php $plxShow->comGet('mail',''); ?>" /><br />
						<label>Commentaire&nbsp;:</label>
						<br />
						<textarea name="content" cols="35" rows="8"><?php $plxShow->comGet('content',''); ?></textarea>
						<?php # Affichage du capcha anti-spam
						if($plxShow->plxMotor->aConf['capcha']): ?>
							<label><strong><br />
							<br />
							V&eacute;rification anti-spam</strong>&nbsp;:</label>
							<p><?php $plxShow->capchaQ(); ?>&nbsp;:&nbsp;<input name="rep" type="text" size="10" /></p>
							<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
						<?php endif; # Fin du if sur le capcha anti-spam ?>
						<p><input type="submit" value="Envoyer" />&nbsp;<input type="reset" value="Effacer" /></p>
				</form>
		  </div>
			<?php endif; # Fin du if sur l'autorisation des commentaires ?>
	</div>
</div>
<?php include('footer.php'); # On insere le footer ?>
