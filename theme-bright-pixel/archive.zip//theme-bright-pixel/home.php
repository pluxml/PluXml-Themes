<?php include('header.php'); # On insere le header ?><div class="content">
<br /><div class="item">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
			<div class="post">
				<h1><?php $plxShow->artTitle('link'); ?></h1>
<div class="descr">Post&eacute; le <?php $plxShow->artDate(); ?></div>
				<div class="entry"><?php $plxShow->artChapo(); ?></div>
								<br />
								<p class="info"><?php $plxShow->artCat(); ?> | <img src="<?php $plxShow->template(); ?>/img/comments.gif" alt="commentaire"> <?php $plxShow->artNbCom('link'); ?></p>
								<div class="divider"></div><br />
			
		<?php endwhile; # Fin de la boucle sur les articles ?></div></div>
		<?php # On affiche la pagination ?>
		<p id="pagination"><?php $plxShow->pagination(); ?></p>
	</div>
<?php include('footer.php'); # On insere le footer ?>
