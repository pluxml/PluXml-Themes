<?php include('header.php'); # On insere le header ?><div class="content">
<br /><div class="item">
			<div class="post">
		<h1><?php $plxShow->staticTitle(); ?></h1>
		<div class="entry"><?php $plxShow->staticContent(); ?></div>
	</div>
</div>
<?php include('footer.php'); # On insere le footer ?>
