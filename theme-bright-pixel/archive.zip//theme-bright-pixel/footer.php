        <div class="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | <a href="http://templates.arcsin.se/">Theme</a> by <a href="http://arcsin.se/">Arcsin</a> |
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
	</p>
</div></div></div>
</body>
</html>