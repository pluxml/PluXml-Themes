<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="fond-blanc">
<article id="article"> <!-- L'article proprement dit commence ici. On indique aux crawlers que c'est la partie intéressante à indexer... -->
		
	<header id="titre"><!-- Voici un nouveau header mais rapporté à l'article et non à la page -->
	<h1><?php $plxShow->staticTitle(); ?></h1>
    </header>
    <section><!-- contenus de la page statique -->
        <?php $plxShow->staticContent(); ?>
    </section>

</article>		
		
<nav id="sidebar"><!-- Début de la sidebar. Comme c'est un élément de navigation on le met aussi dans une balise <nav> -->
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</nav>
<div style="clear:both;"></div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>