<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html> <!-- Nouvelle forme de la déclaration du doctype -->
<html lang="fr"> <!-- Nouvelle forme de la déclaration de la langue -->
<head>
<meta charset="<?php $plxShow->charset(); ?>" />  <!-- Nouvelle déclaration du codage de la page -->
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/style.css" type="text/css" />
	<link rel="alternate" type="application/atom+xml" title="Atom articles" href="./feed.php?atom" />
	<link rel="alternate" type="application/rss+xml" title="Rss articles" href="./feed.php?rss" />
	<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="./feed.php?atom/commentaires" />
	<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="./feed.php?rss/commentaires" />
<title><?php $plxShow->pageTitle(); ?></title>  
<!-- TRES IMPORTANT : Les lignes ci-dessous permettent au navigateur MSIE de prendre en compte les nouvelles balises HTML -->
<!--[if IE]>
    <script type="text/javascript">
        document.createElement("header");
        document.createElement("footer");
        document.createElement("nav");
        document.createElement("article");
        document.createElement("section");
        document.createElement("hgroup");
        document.createElement("aside");
    </script>
<![endif]-->
</head>

<body>
<div id="conteneur"> <!-- nécessaire pour utiliser la technique de centrage par margin:auto -->
<header> <!-- on indique que les éléments compris dans cette balise est un header -->
	<nav id="pages"> <!-- comme vous pouvez le constater, on peut appliquer un style aux balises html5 (bien que ceci limite la compatibilité) -->
      <ul id="navlist">
		<?php $plxShow->staticList('Accueil','<li id="#static_id"><a href="#static_url" class="#static_status" title="#static_name">#static_name</a></li>'); ?>
	  </ul>
    </nav>
	<hgroup id="logo"> <!-- On regroupe le logo et sa baseline -->
        <h1><?php $plxShow->mainTitle('link'); ?></h1>
        <h2><?php $plxShow->subTitle(); ?></h2>

    </hgroup>
</header>