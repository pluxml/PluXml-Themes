 <?php if(!defined('PLX_ROOT')) exit; ?>
    <aside id="autres">

		<?php # Si on a des commentaires ?>

		<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>



				<h2>Commentaires</h2>

				<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>

					<div id="<?php $plxShow->comId(); ?>" class="comment">

						<div class="info_comment">

							<p>Par <?php $plxShow->comAuthor('link'); ?> 

							le <?php $plxShow->comDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?></p>

						</div>

						<blockquote><p><?php $plxShow->comContent() ?></p></blockquote>

					</div>



				<?php endwhile; # Fin de la boucle sur les commentaires ?>

				<?php # On affiche le fil Atom de cet article ?>

				<div class="feed_article"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>

				

		<?php endif; # Fin du if sur la prescence des commentaires ?>

	

		<?php # Si on autorise les commentaires ?>

		<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>				

<div id="formulaire">

				

<fieldset>

<legend><span>Laisser un Commentaire</span></legend>

<p><?php $plxShow->comMessage(); ?></p>



<form action="<?php $plxShow->artUrl(); ?>#form" method="post" id="contact">



<label for="name">Nom</label><a name="name"></a>

<input  tabindex="1" type="text" name="name" id="name" value="<?php $plxShow->comGet('name',''); ?>" required/>



<label for="mail">E-mail <span>(facultatif)</span></label><a name="add"></a>

<input  tabindex="2" type="email" name="mail" id="mail" value="<?php $plxShow->comGet('mail',''); ?>" />



<label for="site">Site</label>

<input  tabindex="3" type="website" name="site" id="site" value="<?php $plxShow->comGet('site','http://'); ?>" />



<?php # Affichage du capcha anti-spam

if($plxShow->plxMotor->aConf['capcha']): ?>

<label for="site">V&eacute;rification anti-spam <span><?php $plxShow->capchaQ(); ?></span></label>

<input  tabindex="4" type="capcha" name="rep" id="rep" value="" />

<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />

<?php endif; # Fin du if sur le capcha anti-spam ?>



<label for="message">Commentaire</label>

<textarea  tabindex="5" cols="30" rows="10" name="content" id="content"><?php $plxShow->comGet('content',''); ?></textarea>





<button  tabindex="6" type="submit" name="submit" id="send"/>Envoyer</button>



</form>



</fieldset>

</div>

		<?php endif; # Fin du if sur l'autorisation des commentaires ?>

   </aside>	