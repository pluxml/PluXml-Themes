<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="http://athena.smartcatdev.wpengine.com/wp-content/uploads/sites/3/2016/02/wild-geese-1149609_640.jpg">
                <header class="entry-header">
                    <h1 class="entry-title"><?php echo plxDate::formatDate($plxShow->plxMotor->cible, $plxShow->lang('ARCHIVES').' #month #num_year(4)') ?></h1>
                </header>
            </div>
            <div class="row">

                <div class="athena-blog-content col-sm-9">

                    <?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

                        <article id="post-1" class="athena-blog-post reveal fadeInUp post-1 post type-post status-publish format-standard has-post-thumbnail hentry category-smartcat category-wordpress-themes tag-responsive-themes tag-setup tag-wordpress">

                            <div id="athena-posts-image">

                                <a href="http://athena.smartcatdev.wpengine.com/2016/05/03/getting-started-your-athena-pro-licence/"> 
                <img width="300" height="200" src="http://athena.smartcatdev.wpengine.com/wp-content/uploads/sites/3/2016/02/foggy-sunday-1170158_640-300x200.jpg" class="attachment-medium size-medium wp-post-image" alt="foggy-sunday-1170158_640" srcset="<?php $plxShow->artThumbnail('#img_url'); ?>" />     
				</a>

                            </div>

                            <div class="post-panel-content">

                                <header class="entry-header">
                                    <h2 class="entry-title"><?php $plxShow->artTitle('link'); ?></h2>
                                    <div class="entry-meta">
                                        <div class="meta-detail">

                                            <div><span class="fa fa-calendar"></span> <span class="posted-on"><a href="http://athena.smartcatdev.wpengine.com/2016/05/03/getting-started-your-athena-pro-licence/" rel="bookmark"><time class="entry-date published" datetime="2016-05-03T17:46:59+00:00">May 3, 2016</time><time class="updated" datetime="2016-05-04T12:05:42+00:00">May 4, 2016</time></a></span><span class="byline"> by <span class="author vcard"><a class="url fn n" href="http://athena.smartcatdev.wpengine.com/author/smartcatdev/">smartcatdev</a></span></span>
                                            </div>

                                            <div class="author"><span class="fa fa-user"></span> smartcatdev</div>

                                            <div id="single-post-views">
                                                <span class="fa fa-eye"></span> 145 </div>

                                        </div>

                                    </div>
                                    <!-- .entry-meta -->
                                </header>
                                <!-- .entry-header -->

                                <div class="entry-content">
                                    Installation Congratulations on purchasing Athena Pro! You should have received an email from Smartcat containing your licence number, a link to generate your invoice, and a link to download your compressed theme files. Once youӶe downloaded the theme files, there are two ways to install them on your WordPress site:&hellip;
                                </div>
                                <!-- .entry-content -->

                                <div class="continue-reading">
                                    <a class="athena-button primary" href="http://athena.smartcatdev.wpengine.com/2016/05/03/getting-started-your-athena-pro-licence/">Continue Reading</a>
                                </div>

                                <footer class="entry-footer">
                                </footer>
                                <!-- .entry-footer -->
                            </div>

                        </article>
                        <!-- #post-## -->

                        <?php endwhile; ?>

                </div>

                <?php include(dirname(__FILE__).'/sidebar.php'); ?>

            </div>
            <!-- #secondary -->
        </div>
    </div>
    <div class="clear"></div>
    <div class="athena-pagination">
			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>
    </div>

    </div>
    <!-- #primary -->

    </div>
    <!-- #content -->

    <?php include(dirname(__FILE__).'/footer.php'); ?>


