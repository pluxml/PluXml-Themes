<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">

                <div id="athena-jumbotron">

                    <div id="athena-slider" class="hero">

                        <?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

                            <div id="slide<?php echo $plxShow->artId(); ?>" data-src="<?php $plxShow->artThumbnail('#img_url'); ?>">

                                <div class="overlay">
                                    <div class="row">

                                        <div class="col-sm-6 parallax">
                                            <h2 class="header-text animated slideInDown slide1-header"> <?php $plxShow->artTitle(); ?></h2>

                                            <a href="<?php $plxShow->artUrl(); ?>" class="athena-button primary large animated flipInX slide1_button1 delay3">
                                Lire                            </a>

                                        </div>
                                        <div class="col-sm-6">

                                        </div>

                                    </div>
                                </div>

                            </div>

                            <?php endwhile; ?>

                    </div>

                    <div id="athena-overlay-trigger">

                        <div class="overlay-widget">
                            <div class="row">
                                <aside id="text-8" class="widget widget_text col-sm-12">
                                    <h2 class="widget-title">Petit rideau discret</h2>
                                    <div class="textwidget">
										Un paragraphe explicatif escamotable qui ajoute un petit plus visuel.  Ce serait bien triste de ne rien trouver à dire, c'est tellement mignon d'appuyer sur le bouton et de faire dérouler le rideau.
									</div>
                                </aside>
                            </div>
                        </div>

                        <span class="fa fa-question-circle animated rotateIn delay3"></span>

                    </div>

                    <div class="slider-bottom">
                        <div>
                            <span class="fa fa-chevron-down scroll-down animated slideInUp delay-long"></span>
                        </div>
                    </div>

                </div>

                <div class="clear"></div>

                <div id="athena-featured">

				
				
                    <div class="col-sm-4 featured-box featured-box1" data-target="#">

                        <div class="reveal animated fadeInUp reveal">

                            <div class="athena-icon">
                                <span class="fa fa-laptop"></span>
                            </div>

                            <h3 class="athena-title">Boîte gauche</h3>

                            <p class="athena-desc">Athena looks amazing on desktop and mobile devices.</p>

                        </div>

                    </div>

                    <div class="col-sm-4 featured-box featured-box2" data-target="#">

                        <div class="reveal animated fadeInUp delay1">

                            <div class="athena-icon">
                                <span class="fa fa-magic"></span>
                            </div>

                            <h3 class="athena-title">Boîte centre</h3>

                            <p class="athena-desc">Athena is easy to use and customize without having to touch code</p>

                        </div>

                    </div>

                    <div class="col-sm-4 featured-box featured-box3" data-target="#">

                        <div class="reveal animated fadeInUp delay2">

                            <div class="athena-icon">
                                <span class="fa fa-shopping-cart"></span>
                            </div>

                            <h3 class="athena-title">Boîte droite</h3>

                            <p class="athena-desc">Athena supports WooCommerce to build an online shopping site</p>

                        </div>
                    </div>

                </div>

                <div class="clear"></div>

                <div id="athena-homepage-widget" data-parallax="scroll" data-image-src="<?php $plxShow->lastArtList('#img_url',1,'','','random'); ?>">

                    <div>
                        <div class="row ">
                            <div class="widget-area reveal animated fadeInUp">
                                <aside id="athena_testimonials_widget-2" class="widget widget_athena_testimonials_widget col-sm-12">
                                    <ul id="athena-testimonials" class="athena-testimonials owl-carousel owl-theme">
										<?php $plxShow->lastArtList('
                                        <li>
                                            <div class="testimonial-content">
                                                <div class="col-xs-12">
                                                    <i class="fa fa-quote-left"></i>#art_chapo</div>
                                                <div class="clear"></div>
                                                <!--<i class="fa fa-quote-right"></i>-->
                                            </div>
                                            <div class="testimonial-author center">
                                                - #art_author -
                                            </div>
                                        </li>',3); ?>
                                    </ul>

                            </div>
                        </div>
                    </div>

                </div>

                <div class="row">

                    <div class="homepage-page-content col-sm-12">

                        <article id="post-186" class="post-186 page type-page status-publish hentry">

                            <div class="entry-content">

                                <header class="entry-header">
                                    <h1 class="entry-title">Frontpage &#8211; Slider</h1> </header>
                                <!-- .entry-header -->

                                <h2>Premier paragraphe</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum gravida dolor ac sem dapibus consectetur. Vestibulum ut libero purus. Aliquam non viverra odio. Suspendisse et pharetra metus, ut pretium dui. Nullam scelerisque, est non finibus faucibus, ex sem aliquet mauris, id posuere massa diam ut elit. Maecenas volutpat eros at ligula placerat, in luctus enim hendrerit. Nullam convallis metus sit amet nunc ornare pharetra. Nam sit amet facilisis orci. Etiam tristique mi in libero volutpat tincidunt. Donec laoreet nunc dui, vitae porta velit tristique vel. In dignissim sem sit amet accumsan feugiat. Aenean volutpat nisl augue, id consequat justo congue nec. Donec sit amet augue sed massa rhoncus cursus id id arcu. Nam ultricies metus pharetra neque vehicula euismod.</p>
                                <h2>Deuxième paragraphe</h2>
                                <p>Nulla placerat sem urna, eu luctus nulla porta ac. Quisque porttitor tellus ac tellus dignissim, condimentum gravida mauris porta. Praesent varius, felis in iaculis iaculis, est justo bibendum eros, vel scelerisque nulla sapien et elit. Nam turpis diam, aliquam vitae interdum sit amet, faucibus ac enim. Ut ligula elit, fringilla ut turpis ut, tempus varius augue. Sed at suscipit libero, aliquam suscipit lacus. Nunc pharetra gravida ipsum, at bibendum mi lacinia quis. Suspendisse volutpat eget quam sollicitudin condimentum. Vestibulum congue ipsum vel ultricies suscipit. Donec mauris est, vestibulum ut eros quis, rhoncus blandit dolor.</p>
                            </div>
                            <!-- .entry-content -->

                            <footer class="entry-footer">
							
							
							
                            </footer>
                            <!-- .entry-footer -->

                        </article>
                        <!-- #post-## -->
                        <div class="athena-pagination">
                        </div>

                    </div>

                </div>

				</div>
        <!-- #primary -->

    </div>
    <!-- #content -->

    <?php include(dirname(__FILE__).'/footer.php'); ?>