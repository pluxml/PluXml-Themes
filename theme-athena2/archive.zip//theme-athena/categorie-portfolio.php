<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="<?php $plxShow->lastArtList('#img_url',1,$plxShow->catId(),'','random'); ?>">
                <header class="entry-header">
                    <h1 class="entry-title"><?php $plxShow->catName(); ?></h1>
                </header>
            </div>
        </div>

		<div class="row">
			<div class="col-sm-12">
				<article id="post-135" class="post-135 page type-page status-publish has-post-thumbnail hentry">
					<div class="entry-content">
						<div id="gallery" style="display:none;" class="athena-gallery">
							<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
								<a href="<?php $plxShow->artUrl(); ?>">
									<img alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" src="<?php $plxShow->artThumbnail('#img_url'); ?>" data-image="<?php $plxShow->artThumbnail('#img_url'); ?>" data-description="<?php $plxShow->artThumbnail('#img_title'); ?>" style="display:none">
								</a>
							<?php endwhile; ?>
						</div>
					</div>
				</article>
			</div>
		</div>
	</div>
</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>