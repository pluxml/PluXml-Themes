<?php if(!defined('PLX_ROOT')) exit; ?>

    <div class="col-sm-3" id="athena-sidebar">
        <div id="secondary" class="widget-area" role="complementary">
            <aside id="search-2" class="widget widget_search">
                <h2 class="widget-title">Recherche</h2>
					<?php	
					$placeholder = '';
					# r�cup�ration d'une instance de plxMotor
					$plxMotor = plxMotor::getInstance();
					$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
					$searchword = '';
					if(!empty($_POST['searchfield'])) {
						$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
					}
					if($plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang)!='') {
						$placeholder=' placeholder="'.$plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang).'"';
					}
					?>
					<div class="searchform">
						<form  class="search-form" action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>" method="post">
							<?php if($title) : ?>
							<p class="searchtitle">
								<?php
									if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)=='')
										$plxPlugin->lang('L_FORM_SEARCHFIELD');
									else
										$plxPlugin->lang('L_FORM_SEARCHFIELD_2');
								?>&nbsp;:
							</p>
							<?php endif; ?>
							<div class="searchfields">
								<?php
								if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)!='') {
									if($chk = explode(';', $plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang))) {
										echo '<ul>';
										foreach($chk as $k => $v) {
											$c = plxUtils::title2url(trim($v));
											$sel = "";
											if(isset($_POST['searchcheckboxes'])) {
												foreach($_POST['searchcheckboxes'] as $s) {
													if($s==$c) {
														$sel = ' checked="checked"';
													}
												}
											}
											echo '<li><input'.$sel.' class="searchcheckboxes" type="checkbox" name="searchcheckboxes[]" id="id_searchcheckboxes[]" value="'.$c.'" />&nbsp;'.plxUtils::strCheck($v).'</li>';
										}
										echo '</ul>';
									}
								}
								?>
								<input type="text" <?php echo $placeholder ?> class="searchfield" name="searchfield" value="<?php echo $searchword ?>" />
								<input type="submit" class="searchbutton" name="searchbutton" value="<?php echo $plxPlugin->getParam('frmLibButton_'.$plxPlugin->default_lang) ?>" />

							</div>
						</form>
					</div>

                <!--form role="search" method="get" class="search-form" action="http://athena.smartcatdev.wpengine.com/">
                    <label>
                        <span class="screen-reader-text">Search for:</span>
                        <input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
                    </label>
                    <input type="submit" class="search-submit" value="Search" />
                </form-->
            </aside>

			<aside id="smartcat_team_widget-2" class="widget widget_smartcat_team_widget">
			
			<h2 class="widget-title"><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
			<div id="sc_our_team" class="widget">
                
				<?php $plxShow->lastArtList('
				<div itemscope="" itemtype="http://schema.org/Person" class="sc_sidebar_team_member">
					<a href="#art_url" rel="bookmark" title="Lucy Jameson">
						<img width="300" height="300" src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=68&h=68&crop-to-fit" class="attachment-medium size-medium wp-post-image" alt="team-member1" srcset="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=68&h=68&crop-to-fit" sizes="(max-width: 300px) 100vw, 300px">  
					</a>
					<div class="sc_team_member_overlay">
						<div itemprop="name" class="sc_team_member_name">
							#art_title
						</div>
						<div itemprop="jobtitle" class="sc_team_member_jobtitle">
							#art_chapo 
						</div>
						<div class="icons"></div>
					</div>
				</div>',3); ?>

				</div>
			</aside>
			<aside id="text-6" class="widget widget_text">
				<h2 class="widget-title">Petit paragraphe</h2>			
				<div class="textwidget">
					Athena Pro page templates include left sidebar, right sidebar, both sidebars, and no sidebar options. You can view your options under "Templates" in the menu above.
				</div>
			</aside>
			

            <aside id="tag_cloud-2" class="widget widget_tag_cloud">
                <h2 class="widget-title"><?php $plxShow->lang('TAGS'); ?></h2>
                <div class="tagcloud">
					<?php $format='<a href="#tag_url" title="#tag_name" style="font-size: #tag_sizeem;">#tag_name</a>';
						$max=''; 
						$order='';
						$datetime = date('YmdHi');
						$array=array();
						$alphasort=array();
						$plxMotor = plxMotor::getInstance();
						$plxPlugin = $plxMotor->plxPlugins->callHook('plxShowTagList');
						if($plxShow->plxMotor->aTags) {
							foreach($plxShow->plxMotor->aTags as $idart => $tag) {
								if(isset($plxShow->plxMotor->activeArts[$idart]) AND $tag['date']<=$datetime AND $tag['active']) {
									if($tags = array_map('trim', explode(',', $tag['tags']))) {
										foreach($tags as $tag) {
											if($tag!='') {
												$t = plxUtils::title2url($tag);
												if(!isset($array['_'.$tag])) {
													$array['_'.$tag]=array('name'=>$tag,'url'=>$t,'count'=>1);
												}
												else
													$array['_'.$tag]['count']++;
												if(!in_array($t, $alphasort))
													$alphasort[] = $t; # pour le tri alpha
											}
										}
									}
								}
							}
							if($max!='') $array=array_slice($array, 0, intval($max), true);
							switch($order) {
								case 'alpha':
									if($alphasort) array_multisort($alphasort, SORT_ASC, $array);
									break;
								case 'random':
									$arr_elem = array();
									$keys = array_keys($array);
									shuffle($keys);
									foreach ($keys as $key) {
										$arr_elem[$key] = $array[$key];
									}
									$array = $arr_elem;
									break;
							}
						}
						$size=0;
						foreach($array as $tagname => $tag) {
							$name = str_replace('#tag_id','tag-'.$size++,$format);
							$name = str_replace('#tag_size',($tag['count']>10?'max':(0.5+$tag['count']/5)),$name);
							$name = str_replace('#tag_count',$tag['count'],$name);
							$name = str_replace('#tag_item',$tag['url'],$name);
							$name = str_replace('#tag_url',$plxShow->plxMotor->urlRewrite('?tag/'.$tag['url']),$name);
							$name = str_replace('#tag_name',plxUtils::strCheck($tag['name']),$name);
							$name = str_replace('#nb_art',$tag['count'],$name);
							$name = str_replace('#tag_status',(($plxShow->plxMotor->mode=='tags' AND $plxShow->plxMotor->cible==$tag['url'])?'active':'noactive'), $name);
							echo $name.' ';
						}	?>
					</aside>
            <aside id="calendar-2" class="widget widget_calendar">
                <h2 class="widget-title">Calendrier (inactif)</h2>
                <div id="calendar_wrap" class="calendar_wrap">
                    <table id="wp-calendar">
                        <caption>Juin 2016</caption>
                        <thead>
                            <tr>
                                <th scope="col" title="Monday">L</th>
                                <th scope="col" title="Tuesday">M</th>
                                <th scope="col" title="Wednesday">M</th>
                                <th scope="col" title="Thursday">J</th>
                                <th scope="col" title="Friday">V</th>
                                <th scope="col" title="Saturday">S</th>
                                <th scope="col" title="Sunday">D</th>
                            </tr>
                        </thead>

                        <tfoot>
                            <tr>
                                <td colspan="3" id="prev"><a href="http://athena.smartcatdev.wpengine.com/2016/05/">&laquo; Mai</a></td>
                                <td class="pad">&nbsp;</td>
                                <td colspan="3" id="next" class="pad">&nbsp;</td>
                            </tr>
                        </tfoot>

                        <tbody>
                            <tr>
                                <td colspan="2" class="pad">&nbsp;</td>
                                <td>1</td>
                                <td>2</td>
                                <td>3</td>
                                <td>4</td>
                                <td>5</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>7</td>
                                <td>8</td>
                                <td>9</td>
                                <td>10</td>
                                <td>11</td>
                                <td>12</td>
                            </tr>
                            <tr>
                                <td>13</td>
                                <td>14</td>
                                <td>15</td>
                                <td>16</td>
                                <td>17</td>
                                <td>18</td>
                                <td>19</td>
                            </tr>
                            <tr>
                                <td>20</td>
                                <td>21</td>
                                <td>22</td>
                                <td>23</td>
                                <td>24</td>
                                <td>25</td>
                                <td>26</td>
                            </tr>
                            <tr>
                                <td>27</td>
                                <td>28</td>
                                <td>29</td>
                                <td id="today">30</td>
                                <td class="pad" colspan="3">&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </aside>
            <aside id="text-5" class="widget widget_text">
                <h2 class="widget-title">Un autre petit paragraphe</h2>
                <div class="textwidget">
					This is the Right Sidebar. Athena Pro page templates include left sidebar, right sidebar, both sidebars, and no sidebar options. You can view your options under "Templates" in the menu above.
				</div>
            </aside>
	
            <aside id="recent-posts-3" class="widget widget_recent_entries">
                <h2 class="widget-title"><?php $plxShow->lang('CATEGORIES'); ?></h2>
                <ul>
					<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
                </ul>
            </aside>
	
            <aside id="recent-posts-3" class="widget widget_recent_entries">
                <h2 class="widget-title"><?php $plxShow->lang('ARCHIVES'); ?></h2>
                <ul>
					<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
                </ul>
            </aside>
            <aside id="recent-posts-3" class="widget widget_recent_entries">
                <h2 class="widget-title">RSS</h2>
                <ul>
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
                </ul>
            </aside>
        </div>
        <!-- #secondary -->
    </div>