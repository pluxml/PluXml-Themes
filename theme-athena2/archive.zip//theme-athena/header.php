<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php $plxShow->pageTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>
	<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />

	<link rel='stylesheet'  href='<?php $plxShow->template(); ?>/css/sc_our_team.css?ver=2.5.0' type='text/css' media='all' />
	<link rel='stylesheet'  href='<?php $plxShow->template(); ?>/css/style.css?ver=1.0' type='text/css' media='all' />
	<link rel='stylesheet'  href='<?php $plxShow->template(); ?>/css/woocommerce-layout.css?ver=2.5.5' type='text/css' media='all' />
	<link rel='stylesheet'  href='<?php $plxShow->template(); ?>/css/woocommerce-smallscreen.css?ver=2.5.5' type='text/css' media='only screen and (max-width: 768px)' />
	<link rel='stylesheet'  href='<?php $plxShow->template(); ?>/css/woocommerce.css?ver=2.5.5' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/style.css?ver=4.5.3' type='text/css' media='all' />
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Josefin+Sans%3A300%2C400%2C600%2C700&#038;ver=20130115' type='text/css' media='all' />
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Abel&#038;ver=20130115' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/bootstrap.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/bootstrap-theme.min.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/font-awesome.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/style2.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/camera.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/animate.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/owl.carousel.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/slicknav.min.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/unite-gallery.css?ver=1.04' type='text/css' media='all' />
	<link rel='stylesheet' href='<?php $plxShow->template(); ?>/css/green.css?ver=1.04' type='text/css' media='all' />
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.js?ver=1.12.4'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery-migrate.min.js?ver=1.4.1'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/hc.js?ver=2.5.0'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/carousel.js?ver=2.5.0'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/sc_our_team.js?ver=2.5.0'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/frontend.min.js?ver=1.0.0'></script>
	<script type='text/javascript'>
	/* <![CDATA[ */
	var theme_object = {"ajax_url":"\/wp-admin\/admin-ajax.php","theme_name":"athena"};
	/* ]]> */
	</script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/script.js?ver=1.0'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/core.min.js?ver=1.11.4'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/masonry.min.js?ver=3.1.2'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.masonry.min.js?ver=3.1.2'></script>
	<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/script2.js?ver=1.04'></script>


	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />


        <style>
            
            #sc_our_team a,
            .sc_our_team_lightbox .name,
            .sc_personal_quote span.sc_team_icon-quote-left{ color: #36B3A8; }
            .grid#sc_our_team .sc_team_member .sc_team_member_name,
            .grid#sc_our_team .sc_team_member .sc_team_member_jobtitle,
            .grid_circles#sc_our_team .sc_team_member .sc_team_member_jobtitle,
            .grid_circles#sc_our_team .sc_team_member .sc_team_member_name,
            #sc_our_team_lightbox .progress,
            .sc_our_team_panel .sc-right-panel .sc-name,
            #sc_our_team .sc_team_member .icons span,
            .sc_our_team_panel .sc-right-panel .sc-skills .progress,
            #sc_our_team_lightbox .sc_our_team_lightbox .social span,
            .sc_team_single_member .sc_team_single_skills .progress{ background: #36B3A8;}
            .stacked#sc_our_team .smartcat_team_member{ border-color: #36B3A8;}
            /*.grid#sc_our_team .sc_team_member_inner{ height: px; }*/
            .grid#sc_our_team .sc_team_member{ padding: 5px;}
            #sc_our_team_lightbox .sc_our_team_lightbox{ margin-top: px }
 

}
            
        </style>


    <script>
        jQuery(document).ready(function ($) {

            function get_height() {

                if (jQuery(window).width() < 601) {
                    return jQuery(window).height();
                } else {
                    return jQuery(window).height();
                }


            }

            if( jQuery('#athena-slider').html() ) {
                athena_slider();
            }


            function athena_slider() {

                var height = get_height();

                jQuery('#athena-slider').camera({
                    height: height + 'px',
                    loader: "bar",
                    overlay: false,
                    fx: "simpleFade",
                    time: "3000",
                    pagination: false,
                    thumbnails: false,
                    transPeriod: 1000,
                    overlayer: false,
                    playPause: false,
                    hover: false,
                    navigation : true

                });
            }
        });

    </script>
    
    <script type="text/javascript">
    jQuery(document).ready( function($) {
        $('.athena-blog-content').imagesLoaded(function () {
            $('.athena-blog-content').masonry({
                itemSelector: '.athena-blog-post',
                gutter: 0,
                transitionDuration: 0,
            }).masonry('reloadItems');
        });
    });
    </script>
        <style type="text/css">


        body{
            font-size: 16px;
            font-family: Abel, sans-serif;

        }
        h1,h2,h3,h4,h5,h6,.slide2-header,.slide1-header,.athena-title, .widget-title,.entry-title, .product_title{
            font-family: Josefin Sans, sans-serif;
        }

        ul.athena-nav > li.menu-item a{
            font-size: 16px;
        }
        
        ul.athena-nav a{
            color: rgba(255,255,255,0.8)        }
        
        .site-title{
            font-size: 40pxpx;
        }
        
        #athena-jumbotron h2.header-text{
            color: #ffffff        }
        

		ul.athena-nav > li.menu-item.current-menu-parent a, li.active, ul.athena-nav > li.menu-item a:hover {
			border-bottom: 2px solid #17987F;

    </style>
    
    <style type="text/css">ul#footer-menu {
padding-left: 0;
margin-left: 0;
}</style>    


</head>

    <body class="page  page-template page-template-templates page-template-frontpage-slider page-template-templatesfrontpage-slider-php">
        
        <div id="athena-search" class="noshow">
            <span class="fa fa-close"></span>
            <div class="row animated slideInDown">
                <span class="fa fa-search"></span>
				<?php	
				$placeholder = '';
				# récupération d'une instance de plxMotor
				$plxMotor = plxMotor::getInstance();
				$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
				$searchword = '';
				if(!empty($_POST['searchfield'])) {
					$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
				}
				if($plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang)!='') {
					$placeholder=' placeholder="'.$plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang).'"';
				}
				?>
				<form role="search" method="post" class="search-form" action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>">
					<label>
						<input type="search" class="search-field" placeholder="Rechercher &hellip;" name="searchfield" value="<?php echo $searchword ?>" />
					</label>
					<input type="submit" class="search-submit" value="<?php echo $plxPlugin->getParam('frmLibButton_'.$plxPlugin->default_lang) ?>" />
				</form>            
			</div>
        </div>
        
		
        <div id="athena-contact" class="noshow">
			<span class="fa fa-close"></span>
            <div class="row animated slideInDown">
					<?php				
					extract($_POST);

					/* 
					BELLonline PHP MAILER SCRIPT v1.5
					Copyright 2006 Gavin Bell 
					http://www.bellonline.co.uk 
					gavin@bellonline.co.uk
					*/

					// changer le courriel ci-dessous pour votre adresse personnelle qui recevra les messages
					$sendto_email = "adresse@courriel.com";

					// Disable email addresses from the same domain as your email from being sent? 
					// This will often reduce spam but will not allow antone to send from anything@yourdomain. 
					$checkdomain = "yes";
					// Language variables
					$lang_title = "Envoyer un courriel";
					$lang_notice = "N'hésitez pas à remplir le formulaire pour nous contacter par courriel.  Tous les champs sont obligatoires.";
					$lang_name = "Votre nom";
					$lang_youremail = "Votre de courriel";
					$lang_subject = "Sujet";
					$lang_message = "Message";
					$lang_confirmation = "Entrez le code de validation";
					$lang_submit = "Envoyer le courriel";
					// Error messages
					$lang_error = "Votre courriel n'a pas été envoyé, les erreurs suivantes sont à corriger:";
					$lang_noname = "Votre nom n'a pas été inscrit";
					$lang_noemail = "Votre courriel n'a pas été inscrit correctement";
//						$lang_nosubject = "You did not enter a subject";
					$lang_nomessage = "Vous devez inclure un message";
					$lang_nocode = "Vous n'avez pas inscrit le code de validation";
					$lang_wrongcode = "Le code de validation entré est erroné.  SVP prendre note que la casse est prise en compte.";
					$lang_invalidemail = "Le courriel que vous avez inscrit ne semble pas valide, SVP vérifier.";
					// Success
					$lang_sent = "Votre message a été envoyé.  Le message suivant a été posté par courriel:";
					// Width of form inputs. Must include unites, e.g px 
					$input_width = "300px";
					// How do you want the title aligned?
					$title_align = "left"; // Can be left, center or right
					// To format the title text. If you are not confident with css then probably best left as it is
					$title_css = "font-weight: bold; font-size: 120%;";
					// Colour of error message
					$error_colour = "red"; // Must use HTML compatible colour
					// You can choose whether to display Powered by BELLonline PHP mailer script at the bottom of the mail form
					// I understand that some peopme might not want to show our link, but we would appreciate it if you could 
					// Possible options are yes or no
					$showlink = "no";
					// Thanks for using the PHP mailer script, I hope you find it useful!
					
				if ($sendto_email == "changeme@example.com") {
					print "N'oubliez pas de changer l'adresse de courriel dans le fichier config.php.  Attention, pas le config.php de PluXml mais bien celui au sous-répertoire /mail";
					exit;
				} 
					
				if (empty ($senders_name)) 	{
					$error = "1";
					$info_error .= $lang_noname . "<br>"; 
				}
				if (empty ($senders_email))	{
					$error = "1";
					$info_error .= $lang_noemail . "<br>";  
				}
				/*if (empty ($mail_subject)) {
					$error = "1";
					$info_error .= $lang_nosubject . "<br>";  
				}
				*/	
				if (empty ($mail_message)) 	{
					$error = "1";
					$info_error .= $lang_nomessage . "<br>";  
				}
				if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,6}$", $senders_email))	{
					$error = "1";
					$info_error .= $lang_invalidemail . "<br>"; 
				}
				if (empty ($security_code))  {
					$error = "1";
					$info_error .= $lang_nocode . "<br>";  
				}
				elseif ($security_code != $randomness)	{
					$error = "1";
					$info_error .= $lang_wrongcode . "<br>";  
				}
				if ($showlink != "no")	{
					$link = "<br><span style=\"font-size: 10px;\">Powered by <a href=\"http://bellonline.co.uk/downloads/php-mailer-script/\" title=\"free PHP mailer script\">BELLonline PHP mailer script</a></span>";
				}
				if ($error == "1") {
					$info_notice = "<span style=\"color: " . $error_colour . "; font-weight: bold;\">" . $lang_error . "</span><br>"; 
					
					if (empty ($submit)) {
						$info_error = "";
						$info_notice = $lang_notice;
					}	

					function Random() {
						$chars = "ABCDEFGHJKLMNPQRSTUVWZYZ23456789";
						srand((double)microtime()*1000000);
						$i = 0;
						$pass = '' ;
						while ($i <= 4) {
							$num = rand() % 32;
							$tmp = substr($chars, $num, 1);
							$pass = $pass . $tmp;
							$i++; 
						} 
						return $pass; 
					}

					$random_code = Random();
					$mail_message = stripslashes($mail_message); ?>
					
					<form name="BELLonline_email" method="post" action=""  id="athena-contact-form">
						<?php echo $info_notice; ?><?php echo $info_error; ?>
						<br/>
						<br/>
						<?php $plxShow->lang('NAME') ?>
						<br/>
						<input name="senders_name" type="text" class="mailform_input" id="senders_name"  value="<?php echo $senders_name; ?>" maxlength="32">
						<br/>
						<?php $plxShow->lang('EMAIL') ?>
						<br/>
						<input name="senders_email" type="text" class="mailform_input" id="senders_email"  value="<?php echo $senders_email; ?>" maxlength="64">
						<br/>
						<?php //echo $lang_subject; ?>
						<!--br/>
						<input name="mail_subject" type="text" class="mailform_input" id="mail_subject" style="width: <?php //echo $input_width; ?>;" value="<?php //echo $mail_subject; ?>" maxlength="64"-->
						<br/>
						<?php $plxShow->lang('COMMENT') ?>
						<br/>
						<textarea name="mail_message" cols="36" rows="5"  class="mailform_input"><?php echo $mail_message; ?></textarea>
						<br/>
						<br/>
						<?php echo $lang_confirmation; ?>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $random_code; ?></b>
						<input name="security_code" type="text" id="security_code" size="5"> 
						
						<input name="randomness" type="hidden" id="randomness" value="<?php echo $random_code; ?>" >
						<br/>
						<br/>
						<input name="submit" type="submit" id="submit" value="<?php echo $lang_submit; ?>">
					</form>
				<?php 	
				}else{
					if ($checkdomain == "yes") 	{
						$sender_domain = substr($senders_email, (strpos($senders_email, '@')) +1);
						$recipient_domain = substr($sendto_email, (strpos($sendto_email, '@')) +1);
						if ($sender_domain == $recipient_domain){
							print "Désolé, il ne sera pas possible d'envoyer votre message de ce domaine ($sender_domain)";
							exit;
						}		
					}
					$info_notice = $lang_sent;
					$mail_message = stripslashes($mail_message);
					$senders_email = preg_replace("/[^a-zA-Z0-9s.@-_]/", "-", $senders_email);
					$senders_name = preg_replace("/[^a-zA-Z0-9s]/", " ", $senders_name);
					$headers = "From: $senders_name <$senders_email> \r\n";
					$headers .= "X-Mailer: BELLonline.co.uk PHP mailer \r\n";
				//	mail($sendto_email, $mail_subject, $mail_message, $headers); 
					mail($sendto_email, "Un message de votre site web", $mail_message, $headers); 
					?>
					
					<?php echo $info_notice; ?>
					<br/>
					<br/>
					<?php echo $lang_name.': '; ?>
					<br/>
					<?php echo $senders_name; ?>
					<br/>
					<br/>
					<?php echo $lang_youremail.': '; ?>
					<br/>
					<?php echo $senders_email; ?>
					<?php //echo $lang_subject; ?>
					<?php// echo $mail_subject; ?>
					<br/>
					<br/>
					<?php echo $lang_message.': '; ?>
					<br/>
					<?php echo $mail_message; ?>
					<br/>
				<?php 
				}
//				print $link;
				?>
				
				<br/>
				<br/>
				<a href="http://bellonline.co.uk/downloads/php-mailer-script/" target="_blank" title="BELLonline PHP mailer"><?php $plxShow->lang('POWERED_BY') ?>&nbsp;BELLonline PHP mailer</a>
			
            </div>
        </div>
        
        <div id="page" class="hfeed site">

            <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

            <header id="masthead" class="site-header" role="banner">

                <div id="athena-header" class="frontpage">

                    <div class="header-inner">

                        <div class="row">

                            <div class="athena-branding">

                                <div class="site-branding">
                                    
                                    <div id="athena-logo" class="show">
                                        <a href="." rel="home">
                                            <img src="<?php $plxShow->template(); ?>/images/logo.png" title="Athena Theme" />
                                        </a>
                                    </div>

									</div><!-- .site-branding -->

                            </div>

                            <div class="athena-header-menu">

								<!--div class="athena-mobile-cart">
									<a class="athena-cart" href=""><span class="fa fa-shopping-cart"></span> <span class="amount">&pound;0.00</span></a>
								</div-->
                                
                                <nav id="site-navigation" class="main-navigation" role="navigation">
                                    <div class="menu-top-menu-2-container">
										<ul id="primary-menu" class="athena-nav">
											<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="menu-item #static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
											<?php $plxShow->pageBlog('<li class="menu-item" id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
											<li class="menu-item menu-item-type-custom menu-item-has-children"><a href="#"><?php $plxShow->lang('CATEGORIES'); ?></a>
											<ul class="sub-menu">
												<?php $plxShow->catList('','<li id="#cat_id" class="menu-item"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a></li>'); ?>
											</ul>
											</li>
											<li class="menu-item">
												<a class="athena-search" href="#search" role="button" data-toggle="modal">
													<span class="fa fa-search"></span>
												</a>
											</li>
											<li class="menu-item">
												<a class="athena-contact" href="#contact" role="button" data-toggle="modal">
													<span class="fa fa-envelope"></span>
												</a>
											</li>
										</ul>
									</div>
                                </nav>
                            </div>

                        </div>
                    </div>
                </div>
            </header><!-- #masthead -->

