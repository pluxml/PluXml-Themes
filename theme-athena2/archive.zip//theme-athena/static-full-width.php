<?php include(dirname(__FILE__).'/header.php'); ?>
<?php $plxShow = plxShow::getInstance();?>

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="<?php $plxShow->lastArtList('#img_url',1,'','','random'); ?>">
                    <header class="entry-header">
                        <h1 class="entry-title"><?php $plxShow->staticTitle(); ?></h1>
                    </header>
            </div>
        </div>

                <div class="row">

                    <div class="col-sm-12">

                        <article id="post-2" class="post-2 page type-page status-publish has-post-thumbnail hentry">

                            <div class="entry-content">
                                <?php $plxShow->staticContent(); ?>
                            </div>
                            <!-- .entry-content -->

                            <footer class="entry-footer">
                            </footer>
                            <!-- .entry-footer -->

                        </article>
                        <!-- #post-## -->
                    </div>

                </div>


        </div>
        <!-- #primary -->

    </div>
    <!-- #content -->

    <?php include(dirname(__FILE__).'/footer.php'); ?>