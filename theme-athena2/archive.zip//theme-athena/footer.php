<?php if (!defined('PLX_ROOT')) exit; ?>
    <footer id="colophon" class="site-footer" role="contentinfo">

        <div class="athena-footer" data-parallax="scroll" data-image-src="<?php $plxShow->lastArtList('#img_url',1,'','','random'); ?>">
            <div>

                <div class="row">
                </div>

                <div class="row">

                    <div id="secondary" class="widget-area" role="complementary">
                        <aside id="recent-posts-4" class="widget widget_recent_entries col-sm-4">
                            <h2 class="widget-title"><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
                            <ul>
								<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
                           </ul>
                        </aside>
                        <aside id="text-7" class="widget widget_text col-sm-4">
                            <h2 class="widget-title">Un bout de texte</h2>
                            <div class="textwidget">Petit paragraphe qui peut être codé en dur (comme ici) ou tiré d'un article qui le rendra dynamique.</div>
                        </aside>
                        <aside id="tag_cloud-3" class="widget widget_tag_cloud col-sm-4">
                            <h2 class="widget-title"><?php $plxShow->lang('TAGS'); ?></h2>
                            <div class="tagcloud">
							<?php $format='<a href="#tag_url" title="#tag_name" style="font-size: #tag_sizeem;">#tag_name</a>';
								$max=''; 
								$order='';
								$datetime = date('YmdHi');
								$array=array();
								$alphasort=array();
								$plxMotor = plxMotor::getInstance();
								$plxPlugin = $plxMotor->plxPlugins->callHook('plxShowTagList');
								if($plxShow->plxMotor->aTags) {
									foreach($plxShow->plxMotor->aTags as $idart => $tag) {
										if(isset($plxShow->plxMotor->activeArts[$idart]) AND $tag['date']<=$datetime AND $tag['active']) {
											if($tags = array_map('trim', explode(',', $tag['tags']))) {
												foreach($tags as $tag) {
													if($tag!='') {
														$t = plxUtils::title2url($tag);
														if(!isset($array['_'.$tag])) {
															$array['_'.$tag]=array('name'=>$tag,'url'=>$t,'count'=>1);
														}
														else
															$array['_'.$tag]['count']++;
														if(!in_array($t, $alphasort))
															$alphasort[] = $t; # pour le tri alpha
													}
												}
											}
										}
									}
									if($max!='') $array=array_slice($array, 0, intval($max), true);
									switch($order) {
										case 'alpha':
											if($alphasort) array_multisort($alphasort, SORT_ASC, $array);
											break;
										case 'random':
											$arr_elem = array();
											$keys = array_keys($array);
											shuffle($keys);
											foreach ($keys as $key) {
												$arr_elem[$key] = $array[$key];
											}
											$array = $arr_elem;
											break;
									}
								}
								$size=0;
								foreach($array as $tagname => $tag) {
									$name = str_replace('#tag_id','tag-'.$size++,$format);
									$name = str_replace('#tag_size',($tag['count']>10?'max':(0.5+$tag['count']/5)),$name);
									$name = str_replace('#tag_count',$tag['count'],$name);
									$name = str_replace('#tag_item',$tag['url'],$name);
									$name = str_replace('#tag_url',$plxShow->plxMotor->urlRewrite('?tag/'.$tag['url']),$name);
									$name = str_replace('#tag_name',plxUtils::strCheck($tag['name']),$name);
									$name = str_replace('#nb_art',$tag['count'],$name);
									$name = str_replace('#tag_status',(($plxShow->plxMotor->mode=='tags' AND $plxShow->plxMotor->cible==$tag['url'])?'active':'noactive'), $name);
									echo $name.' ';
								}	?>
							</aside>
						</div>
					</div>
				</div>
			</div>
			<div class="clear"></div>

            <div class="site-info">
			<div class="row">
				<div class="athena-copyright">
					Copyright <?php $plxShow->mainTitle('link'); ?> 2016 - <?php $plxShow->subTitle(); ?>
			</div>

				<div id="authica-social">
					<a href="http://facebook.com" target="_BLANK" class="athena-facebook">
						<span class="fa fa-facebook"></span>
					</a>

					<a href="http://gplus.com" target="_BLANK" class="athena-gplus">
						<span class="fa fa-google-plus"></span>
					</a>

					<a href="http://instagram.com" target="_BLANK" class="athena-instagram">
						<span class="fa fa-instagram"></span>
					</a>

					<a href="http://linkedin.com" target="_BLANK" class="athena-linkedin">
						<span class="fa fa-linkedin"></span>
					</a>

					<a href="http://pinterest.com" target="_BLANK" class="athena-pinterest">
						<span class="fa fa-pinterest"></span>
					</a>

					<a href="http://twitter.com" target="_BLANK" class="athena-twitter">
						<span class="fa fa-twitter"></span>
					</a>

				</div>

				<div class="menu-footer-menu-container">
					<ul id="footer-menu" class="athena-footer-nav">
									<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="menu-item  #static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
									<?php $plxShow->pageBlog('<li class="menu-item"  id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
									<li class="menu-item">
										<a class="athena-search" href="#search" role="button" data-toggle="modal">
											<span class="fa fa-search"></span></a>
									</li>
									<li class="menu-item">
										<a class="athena-contact" href="#contact" role="button" data-toggle="modal">
											<span class="fa fa-envelope"></span></a>
									</li>
                            </ul>
                        </div>
                        <br>
						<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
						<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp;
						
                        <a href="http://athena.smartcatdev.wpengine.com/" target="_blank" rel="designer" >
							<img src="<?php $plxShow->template(); ?>/images/cat_logo_mini.png"/> Design par Smartcat 
						</a>

                    </div>

                    <div class="scroll-top alignright">
                        <span class="fa fa-chevron-up"></span>
                    </div>

                </div>
                <!-- .site-info -->

            </footer>
            <!-- #colophon -->
        </div>
        <!-- #page -->
        <link rel='stylesheet' id='smartcat_customizer_theme_style-css' href='<?php $plxShow->template(); ?>/css/athena.css?ver=1.0' type='text/css' media='all' />
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/add-to-cart.min.js?ver=2.5.5'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.blockUI.min.js?ver=2.70'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/woocommerce.min.js?ver=2.5.5'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.cookie.min.js?ver=1.4.1'></script>

        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/cart-fragments.min.js?ver=2.5.5'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/navigation.js?ver=20120206'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/skip-link-focus-fix.js?ver=20130115'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/unite.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/bootstrap.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/sticky.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/easing.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/camera.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/parallax.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/owl.carousel.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/slicknav.min.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/wow.js?ver=1.04'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/wp-embed.min.js?ver=4.5.2'></script>
    </body>

    </html>