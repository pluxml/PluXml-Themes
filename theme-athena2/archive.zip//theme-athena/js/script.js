/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
jQuery(document).ready(function ($) {

    $('.clicker-part').hover(function () {

        $('.fa-cog', this).addClass('fa-spin');

    }, function () {
        $('.fa-cog', this).removeClass('fa-spin');
    })


    $('.clicker-part').click(function () {


        if ( $(this).hasClass('open') ) {
            
            $('#smartcat-customizer').animate({
                left: '-250px',
            }, 350);
            
            $(this).removeClass('open');

        } else {

            $('#smartcat-customizer').animate({
                left: 0,
            }, 350);
            
            $(this).addClass('open');
        }


    });



    var data = {
        action: 'smartcat_customizer_set_color'
    };

    $.post( theme_object.ajax_url, data, function (response) {
    }).success(function (response) {

        if (response.length > 0 && response != '') {
            smartcat_set_template(response);
            $('.theme-color .color').removeClass('active');
            $('.theme-color .color').each(function () {
                if ($(this).attr('data-name') == response) {
                    $(this).addClass('active');
                }
            });
        }

    });


    // dropdown
    $(document).click(function (e) {

        if ($(e.target).closest('.theme-selector').length) {
            $('.themebox').show().addClass('visible');
        } else {
            $('.themebox').hide().removeClass('visible');
        }
    })

    // theme dropdown
    $('.themebox li a').hover(function () {
        $('.theme-name').html($(this).attr('data-title'));
        $('.theme-thumbnail img').attr('src', $(this).attr('data-img'));
        $('.theme-description').html($(this).attr('data-desc'));
        $('.themebox .buy-now').attr('href', $(this).attr('data-url'));
    });

    // theme changer
    $('.theme-color .color').click(function () {


        var theme = $(this).attr('data-name');
        $('.theme-color .color').removeClass('active');
        $(this).addClass('active');


        var data = {
            action: 'smartcat_customizer_change_color',
            theme: theme,
        };

        $.post( theme_object.ajax_url, data, function (response) {
        }).success(function (response) {
	
        });

        smartcat_set_template(theme);

    });

    function smartcat_set_template(theme) {
	
		var url = '#' + theme_object.theme_name + '-template-css';
		
		
        var href = $(url).attr('href');
        var href_path = href.substring(0, href.lastIndexOf('/')) + '/' + theme + '.css';
        $(url).attr('href', href_path);
    }

    $('.theme-skin .skin').click(function () {
        $('.theme-skin .skin').removeClass('active');
        $(this).addClass('active');
        if ($(this).hasClass('dark')) {
            $('.site-branding').addClass('dark');
        } else {
            $('.site-branding').removeClass('dark');
        }
    });


});

