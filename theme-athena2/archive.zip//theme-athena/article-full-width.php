<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">

            <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="<?php $plxShow->artThumbnail('#img_url'); ?>">

                <header class="entry-header">
                    <h1 class="entry-title"><?php// $plxShow->artTitle(); ?></h1>
                </header>
                <!-- .entry-header -->

            </div>

            <div class="row">

                <div class="col-sm-12">

                    <article id="post-1" class="post-1 post type-post status-publish format-standard has-post-thumbnail hentry category-smartcat category-wordpress-themes tag-responsive-themes tag-setup tag-wordpress">
                        <header class="entry-header">
                            <h1 class="entry-title"><?php $plxShow->artTitle(); ?></h1>
                            <div class="entry-meta">
                                <div class="meta-detail">

                                    <div>
                                        <span class="fa fa-calendar"></span>
                                        <span class="posted-on">
								<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>">
									<?php $plxShow->artDate('#num_day #month #num_year(4)'); ?>
								</time>
							</span>
                                    </div>

                                    <div class="author"><span class="fa fa-user"></span>
                                        <?php $plxShow->lang('WRITTEN_BY'); ?>
                                            <?php $plxShow->artAuthor() ?>
                                    </div>

                                    <div><span class="fa fa-comment"></span> <a href="#comments" title="<?php $plxShow->artNbCom(); ?>"><?php $plxShow->artNbCom(); ?></a></div>

                                    <div id="single-post-views">
                                        <span class="fa fa-eye"></span>
                                        <?php $plxShow->lang('CLASSIFIED_IN') ?> :
                                            <?php $plxShow->artCat() ?> -
                                                <?php $plxShow->lang('TAGS') ?> :
                                                    <?php $plxShow->artTags() ?>
                                    </div>

                                </div>

                            </div>
                            <!-- .entry-meta -->

                        </header>
                        <!-- .entry-header -->

                        <div class="entry-content">
                            <?php $plxShow->artContent(); ?>
						   <?php $plxShow->artThumbnail(); ?>
						   <?php include(dirname(__FILE__).'/commentaires.php'); ?>
                        </div>
                        <!-- .entry-content -->

                        <div class="clear"></div>
                        <div class="athena-pagination">
                            <nav class="pagination text-center">
                                <?php $plxShow->pagination(); ?>
                            </nav>
                        </div>

                    </article>
                    <!-- #post-## -->

                </div>

            </div>
            <!-- .entry-content -->


            </article>
            <!-- #post-## -->
        </div>
    </div>

    </div>
    <!-- #primary -->

    </div>
    <!-- #content -->

    <?php include(dirname(__FILE__).'/footer.php'); ?>