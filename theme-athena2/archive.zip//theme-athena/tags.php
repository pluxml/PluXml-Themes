<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
			<div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="<?php $plxShow->lastArtList('#img_url',1,$plxShow->catId(),'','random'); ?>">
                <header class="entry-header">
                    <h1 class="entry-title"><?php $plxShow->tagName(); ?></h1>
                </header>
            </div>
            <div class="row">

                <div class="athena-blog-content col-sm-9">

                    <?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

                        <article class="athena-blog-post reveal fadeInUp post type-post status-publish format-standard has-post-thumbnail hentry">

                            <div id="athena-posts-image">
                                <a href="<?php $plxShow->artThumbnail('#art_url'); ?>"> 
									<img width="300" height="200" src="<?php $plxShow->artThumbnail('#img_url'); ?>" class="attachment-medium size-medium wp-post-image" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" srcset="<?php $plxShow->artThumbnail('#img_url'); ?>" />     
								</a>
                            </div>

                            <div class="post-panel-content">

                                <header class="entry-header">
                                    <h2 class="entry-title"><?php $plxShow->artTitle('link'); ?></h2>
                                    <div class="entry-meta">
                                        <div class="meta-detail">

                                            <div><span class="fa fa-calendar"></span>
											<span class="posted-on">
												<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></time>
											</span>
											<span class="byline"> <?php $plxShow->lang('WRITTEN_BY'); ?> 
													
											</span>
                                            </div>

                                            <div class="author"><span class="fa fa-user"></span> <?php $plxShow->artAuthor() ?></div>

                                            <div id="single-post-views">
                                                <span class="fa fa-eye"></span>
												<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?> - 
												<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
 
											</div>
                                        </div>
                                    </div>
                                </header>
                                <div class="entry-content">
									<?php $plxShow->artChapo(''); ?>
                                </div>
                                <div class="continue-reading">
                                    <a class="athena-button primary" href="<?php $plxShow->artUrl(); ?>">Lire</a>
                                </div>
                            </div>
                        </article>

                        <?php endwhile; ?>

                </div>

                <?php include(dirname(__FILE__).'/sidebar.php'); ?>

            </div>
            <!-- #secondary -->
        </div>
    </div>
	
    <div class="clear"></div>
	<span>
		<?php $plxShow->tagFeed() ?>
	</span>
    <div class="athena-pagination">
			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>
    </div>

    </div>
    <!-- #primary -->

    </div>
    <!-- #content -->

    <?php include(dirname(__FILE__).'/footer.php'); ?>
	
