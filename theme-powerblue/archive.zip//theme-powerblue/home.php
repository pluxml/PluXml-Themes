<?php include('header.php'); # On insere le header ?>
<div id="page">
	<div id="content">
		<?php $i = 0; ?>
<?php while($plxShow->plxMotor->plxRecord_arts->loop() AND $i < 6): # On boucle sur les articles ?>
        <div class="post">
            <h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
            <p class="post-info">Cat&eacute;gorie : <?php $plxShow->artCat(); ?> | le <?php $plxShow->artDate(); ?> | <span class="art_comment_nb"><?php $plxShow->artNbCom(); ?></span></p>
             <?php if($i < 3) : ?>
                            <div class="chapo"><?php $plxShow->artChapo(); ?></div> 
            <?php endif; ?>
                        <?php $i++; ?>    
            </div>
<?php endwhile; # Fin de la boucle sur les articles ?>
		<?php # On affiche la pagination ?>
		<p id="pagination"><?php $plxShow->pagination(); ?></p>
	</div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
</div>
<?php include('footer.php'); # On insere le footer ?>
