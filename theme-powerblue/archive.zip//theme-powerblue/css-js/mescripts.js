// shadowbox - affichage d'image		
			$(document).ready(function(){
			    var options = {
			        resizeLgImages:     true,
			        counterType:		'skip',
			        continuous: 		true,
			        keysClose:          ['c', 27] // c or esc
			     };
			   Shadowbox.init(options);
			});
	