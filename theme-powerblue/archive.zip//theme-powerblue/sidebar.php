<div id="sidebar">
	<div id="block-recherche">
		<h2>Rechercher</h2>
			<form class="formsearch" method="post" action="?static1/rechercher"> <!-- mettre l\'adresse de votre page static de recherche  -->
                   <fieldset><p><input name="search" size="15" maxlength=\"255\" value="" type="text" class="search" />  <input type="submit" type="image" id="btnsearch" value="" /></p>
          </fieldset>
</form>
	</div>
	
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('','<span class="nomcat">#cat_name</span>  <span class="nbartcat">#art_nb articles</span>'); ?>
		</ul>
	</div>
	
	
	<div id="syndication">
		<h2>Syndication</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
	</div>
	
	<!-- ACTIVER le lien pour la version mobile
	<div id="version-mobile">
		<h2>Version Mobile</h2>
	<ul><li><a href="./?style=mobile" title="version mobile / bas d&eacute;bit">version mobile / bas d&eacute;bit</a></li></ul>
	</div>  -->
	
</div>
<div class="clearer"></div>