<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<title><?php $plxShow->pageTitle(); ?></title>
	<script type="text/javascript"> var chemin='<?php $plxShow->template(); ?>'; </script>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php $plxShow->charset(); ?>" />
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css-js/style.css" media="screen" />
	<link rel="alternate" type="application/atom+xml" title="Atom articles" href="./feed.php?atom" />
	<link rel="alternate" type="application/rss+xml" title="Rss articles" href="./feed.php?rss" />
	<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="./feed.php?atom/commentaires" />
	<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="./feed.php?rss/commentaires" />
	
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/jquery-1.2.6.pack.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/jquery.flash.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/mescripts.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css-js/shadowbox.css" media="screen" />
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/shadowbox-jquery.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/shadowbox.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/scrollto.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/cufon_yui.js"></script>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/css-js/fonts/Anivers_400.font.js"></script>

<!-- <script type="text/javascript">
       Cufon.replace('h1, #header p, h2.title, #sidebar h2');
    </script>
    <style type="text/css">
    h1 {
      font-size:250%;
    }
    #header p {
      font-size:150%;
    }
    </style> -->

</head>
<body>
<div id="top">
	<div id="menu">
	<ul id="menustatic">
	<?php $plxShow->staticList('Accueil'); ?>
	</ul>
</div>
	<div class="clearer"></div>
	</div>
	<div id="header">
		<h1><?php $plxShow->mainTitle('link'); ?></h1>
		<p><?php $plxShow->subTitle(); ?></p>
	</div>
</div>
