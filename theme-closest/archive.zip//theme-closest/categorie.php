<?php include(dirname(__FILE__).'/header.php'); ?>

		<section id="product">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-12 section-heading text-center">
						<h1><?php $plxShow->catName(); ?></h1>
						<div class="row">
							<div class="col-md-6 col-md-offset-3 subtext">
								<p><?php $plxShow->catDescription('#cat_description'); ?></p>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="post-entry">
						<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
							<div class="col-md-6" role="article" id="post-<?php echo $plxShow->artId(); ?>">
								<div class="post animate-box">
									<a href="<?php $plxShow->artUrl(); ?>"><img src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt="Product"></a>
									<div>
										<h3><?php $plxShow->artTitle('link'); ?></h3>
										<p><?php $plxShow->artChapo(); ?></p>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
