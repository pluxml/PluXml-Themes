<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
		<meta charset="<?php $plxShow->charset('min'); ?>">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php $plxShow->pageTitle(); ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="<?php $plxShow->meta('description') ?>"/>
		<?php $plxShow->meta('keywords') ?>
		<?php $plxShow->meta('author') ?>

		<meta property="og:title" content="<?php $plxShow->pageTitle(); ?>"/>
		<meta property="og:site_name" content="<?php $plxShow->mainTitle(); ?>"/>
		<meta property="og:description" content="<?php $plxShow->meta('description') ?>"/>
		<meta name="twitter:title" content="<?php $plxShow->pageTitle(); ?>" />

		<link rel="shortcut icon" href="<?php $plxShow->template(); ?>/images/favicon.ico">
		<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,700|Roboto:300,400' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/animate.css">
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/icomoon.css">
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/bootstrap.css">
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/style.css">

		<script src="<?php $plxShow->template(); ?>/js/modernizr-2.6.2.min.js"></script>
		<!--[if lt IE 9]>
			<script src="<?php $plxShow->template(); ?>/js/respond.min.js"></script>
		<![endif]-->
	</head>
	
	<body>
		<div class="box-wrap">
			<header role="banner" id="fh5co-header">
				<div class="container">
					<nav class="navbar navbar-default">
						<div class="row">
							<div class="col-md-3">
								<div class="fh5co-navbar-brand">
									<a class="fh5co-logo" href=".">
										<img src="<?php $plxShow->template(); ?>/images/brand-nav.png" alt="Closest Logo">
									</a>
								</div>
							</div>
							<div class="col-md-6">
								<ul class="nav text-center">
									<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
									<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
								</ul>
							</div>
							<div class="col-md-3">
								<ul class="social">
									<li><a href="#"><i class="icon-twitter"></i></a></li>
									<li><a href="#"><i class="icon-dribbble"></i></a></li>
									<li><a href="#"><i class="icon-instagram"></i></a></li>
								</ul>
							</div>
						</div>
					</nav>
			  </div>
			</header>
			<!-- END: header -->
