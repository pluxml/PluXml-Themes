<?php include(dirname(__FILE__).'/header.php'); ?>

			<section id="intro">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 text-center">
							<div class="intro animate-box">
								<h2>Le thème Cleanest met vos images en valeur de belle façon.</h2>
							</div>
						</div>
					</div>
				<div>
			</section>

			<section id="work">
				<div class="container">
					<div class="row">
						<?php $largeur=12;
						while($plxShow->plxMotor->plxRecord_arts->loop()): 
							$largeur = ($largeur == 12)? $largeur = array_rand(array_flip(array(4,6,8,12)), 1) : $largeur = 12-$largeur; ?>
							<div class="col-md-<?php echo $largeur;?>"  role="article" id="post-<?php echo $plxShow->artId(); ?>">
								<div class="fh5co-grid animate-box" style="background-image: url(<?php $plxShow->artThumbnail('#img_url'); ?>);">
									<a class="image-popup text-center" href="<?php $plxShow->artUrl(); ?>">
										<div class="work-title">
											<h3><?php $plxShow->artTitle(); ?></h3>
											<span><?php $plxShow->artChapo(''); ?></span>
										</div>
									</a>
								</div>
							</div>
							<?php 
						endwhile; ?>
					</div>
				</div>
			</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
