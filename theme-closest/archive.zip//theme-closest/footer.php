<?php if (!defined('PLX_ROOT')) exit; ?>
			<section id="services">
				<div class="container">
					<div class="row">
						<div class="col-md-4 animate-box">
							<div class="service">
								<div class="service-icon">
									<i class="icon-command"></i>
								</div>
								<h2><?php $plxShow->lang('CATEGORIES'); ?></h2>	
								<ul class="cat-list unstyled-list">
									<?php $plxShow->catList('','<li id="#cat_id" style="list-style-type:none;"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
								</ul>
							</div>
						</div>
						<div class="col-md-4 animate-box">
							<div class="service">
								<div class="service-icon">
									<i class="icon-drop2"></i>
								</div>
								<h2><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
								<ul class="lastart-list unstyled-list">
									<?php $plxShow->lastArtList('<li  style="list-style-type:none;"><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
								</ul>
							</div>
						</div>
						<div class="col-md-4 animate-box">
							<div class="service">
								<div class="service-icon">
									<i class="icon-anchor"></i>
								</div>
								<h2><?php $plxShow->lang('TAGS'); ?></h2>
								<ul class="tag-list">
									<?php $plxShow->tagList('<li class="tag #tag_size"  style="list-style-type:none;"><a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a></li>'); ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>

			<footer id="footer" role="contentinfo">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center ">
							<div class="footer-widget border">
								<p class="pull-left">
								<small>
									&copy; <?php echo date("Y"); ?> <?php $plxShow->mainTitle('link'); ?> - 
									<?php $plxShow->subTitle(); ?> - 
									<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
									<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp;
									<?php $plxShow->httpEncoding() ?> - <a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
								</small>
								</p>
								<p class="pull-right">
									<small>
										Design par  <a href="http://freehtml5.co/" target="_blank">freehtml5.co</a>
									</small>
								</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
		<!-- END: box-wrap -->

		<script src="<?php $plxShow->template(); ?>/js/jquery.min.js"></script>
		<script src="<?php $plxShow->template(); ?>/js/jquery.easing.1.3.js"></script>
		<script src="<?php $plxShow->template(); ?>/js/bootstrap.min.js"></script>
		<script src="<?php $plxShow->template(); ?>/js/jquery.waypoints.min.js"></script>
		<script src="<?php $plxShow->template(); ?>/js/main.js"></script>
	</body>
</html>
