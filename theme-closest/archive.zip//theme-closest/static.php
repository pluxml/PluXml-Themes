<?php include(dirname(__FILE__).'/header.php'); ?>

	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 text-center">
				<div class="intro animate-box">
					<h1><?php $plxShow->staticTitle(); ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-12 animate-box">
			<?php $plxShow->staticContent(); ?>
		</div>
		<!-- <div class="col-md-4"></div> -->
	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>
