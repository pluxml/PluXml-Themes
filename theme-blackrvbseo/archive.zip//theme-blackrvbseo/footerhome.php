<?php if (!defined('PLX_ROOT')) exit; ?>
<hr>
	<nav class="enbas">
		<ul>
		<!-- à personnaliser selon votre config -->
<li><a href="index.php" class="active" title="Accueil">Accueil</a></li>
<li><a href="index.php?contact" title="Contact">Contact</a></li>
<li><a href="index.php?static2/geolocalisation"   title="Géolocalisation">Géolocalisation</a></li>
<li><a href="index.php?allarchive"   title="Archives">Archives</a></li>
<li><a href="index.php?static3/tags-cloud"   title="Tags Cloud">Tags Cloud</a></li>
<li><a href="sitemap.php" title="Sitemap">Sitemap</a></li>
<li><a href="<?php $plxShow->urlRewrite('#top') ?>" class="active" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a></li>
		</ul>
	</nav>
		<footer class="footer">

				<p>
					&copy; 2016 <?php $plxShow->mainTitle('link'); ?> - 
					<?php $plxShow->subTitle(); ?> - 
					<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a rel="nofollow" href="http://www.pluxml.org" onclick="window.open(this.href);return false;" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
					<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp;
					<?php $plxShow->httpEncoding() ?>
				</p>
				<p>
				<!-- don't remove-->
				Thème 'blackRVB' by bg from <a rel="nofollow" href="http://www.unesourisetmoi.info" onclick="window.open(this.href);return false;" title="fonds d'écran">fonds d'écran</a>
				</p>	<!--  -->
				<ul class="menu">
					<li><a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a></li>
				</ul>
		</footer>

</div>

</body>

</html>