<?php include(dirname(__FILE__).'/headerhome.php'); ?>
	<main class="main grid">
		<section class="col sml-12 med-8">
			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
			<article class="article"  id="post-<?php echo $plxShow->artId(); ?>">
				<header>
					<h1>
						<?php $plxShow->artTitle('link'); ?>
					</h1>
				</header>
				<section>
					<?php $plxShow->artThumbnail(); ?>
					<?php $plxShow->artChapo(); ?>			
				</section>
	
			</article>
			
				<div class="article-info">		<?php $plxShow->artDate('#num_day #month #num_year(4)'); ?> - <?php $plxShow->lang('WRITTEN_BY') ?> <?php $plxShow->artAuthor() ?> -
						<?php $plxShow->artNbCom(); ?>
				
						<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat(); ?>
				
						<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?>
						</div>
					<div class="linehome"></div>
			<?php endwhile; ?>
			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>
		</section>
		<?php include(dirname(__FILE__).'/sidebarhome.php'); ?>
	</main>
<?php include(dirname(__FILE__).'/footerhome.php'); ?>
