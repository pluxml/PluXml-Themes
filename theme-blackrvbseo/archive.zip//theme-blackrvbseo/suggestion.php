<?php
	/**
	* Méthode qui affiche une liste d'articles au hasard dans la même catégorie.
	*
	* @param    max      nombre d'articles maximum affichés
	* @param    cat_id   id de la catégorie cible (1,home)
	* @param    maxSeek  nombres d'articles les plus rescents à parser
	* @param    exclude  id de l'article à exclure
	* @return   stdout
	* @author   Amaury GRAILLAT, Florent MONTHEL
	**/
	function suggestion ($max = 8, $cat_id = '', $maxSeek = 350, $exclude = -1)
	{
		# Récupération des instances :
		$plxShow_inst = plxShow::getInstance();
		$plxMotor_inst = plxMotor::getInstance();
	
		#Génération de notre motif
		if (empty ($cat_id))
			$motif = '/[0-9]{4}.[0-9,]*.[0-9]{3}.[0-9]{12}.[a-z0-9-]+.xml$/';
		elseif ($cat_id == 'home')
			$motif = '/[0-9]{4}.(home[0-9,]*).[0-9]{3}.[0-9]{12}.[a-z0-9-]+.xml$/';
		else
			$motif = '/[0-9]{4}.[0-9,]*'.str_pad ($cat_id, 3, '0', STR_PAD_LEFT).'[0-9,]*.[0-9]{3}.[0-9]{12}.[a-z0-9-]+.xml$/';

		#Nouvel objet plxGlob et récupération des fichiers
		$plxGlob_arts = plxGlob::getInstance(PLX_ROOT.$plxShow_inst->plxMotor->aConf['racine_articles']);

		$aFiles = $plxGlob_arts->query ($motif, 'art', 'rsort', 0, $maxSeek, 'before');

		#On parse les fichiers
		if (is_array ($aFiles))
		{
			#On a des fichiers
			foreach ($aFiles as $v)
			{
				#On parcourt tous les fichiers
				$array[] = $plxShow_inst->plxMotor->parseArticle (PLX_ROOT.$plxShow_inst->plxMotor-> aConf['racine_articles'].$v);
				#On stocke les enregistrements dans un objet plxRecord
				$plxRecord_arts = new plxRecord ($array);
			}
		}


		if ($plxGlob_arts->count AND $plxRecord_arts->size)
		{
			#On a des articles

			//Pas plus qu'on en a...
			if ($maxSeek > $plxGlob_arts->count)
			$maxPars = $plxGlob_arts->count - 1;
			else
			$maxPars = $maxSeek - 1;

			if ($max > $maxPars)
			$max = $maxPars;

			#On boucle sur nos articles
			$used = array ();
			$loop = 0;

			while ($loop < $max)
			{
				for ($antilag = 0; $antilag < $maxPars * 2; $antilag++)
				{
					$plxRecord_arts->i = rand (1, $maxPars);
					if (!$used[$plxRecord_arts->i])
					{
						$used[$plxRecord_arts->i] = true;
						break;
					}
				}

				$num = intval ($plxRecord_arts->f ('numero'));

				if ($num != $exclude && $antilag < $maxPars * 2)	//Si l'article n'est pas exclu, on l'affiche
				{
					#On genère notre ligne
					$row = '<a href="'.'./?article'.$num.'/'.$plxRecord_arts->f ('url').'">'.htmlspecialchars ($plxRecord_arts->f ('title'),ENT_QUOTES, PLX_CHARSET).'</a>';
					echo '<li>'.$row.'</li>';
					$loop++;
				}
				else $loop += 0.1;	// Système antilag, mais évite quand même d'afficher
									// que 4 titres au lieu de 5 quand on a trouvé un exclu. J'assume.
			}
		}
	}

	$plxShow_inst = plxShow::getInstance();
	$plxMotor_inst = plxMotor::getInstance();
	
	$artId = $plxMotor_inst->plxRecord_arts->f ('numero');	//cet article
	
	// Gestion du multi-catégorie : prend une des catégories au hasard.
	$catIdSel = $plxMotor_inst->plxRecord_arts->f ('categorie');
	$catIdSel = explode (',', $catIdSel);
	$catIdSel = array_rand ($catIdSel);
		
	suggestion (8, $catIdSel, 350, $artId);
?>