<?php include(dirname(__FILE__).'/headerarticle.php'); ?>
	<main class="main grid" >

<!--<?php eval($plxShow->callHook('MySocialButtons')) ?>-->
		<section class="col sml-12 med-8">
			<article class="article"  id="post-<?php echo $plxShow->artId(); ?>">
				<header>
					<h1>
						<?php $plxShow->artTitle(); ?>
					</h1>
				</header>
				<section>
					<?php $plxShow->artContent(); ?>
					<!--<?php eval($plxShow->callHook("ArtgalerieDisplay")); ?>	-->
				</section>
			
<div class="prevNext">
					<?php echo $plxShow->callHook('prevNext',array(
				true,
				'<p style="float:left;margin-top:0"><a href="#prevUrl" rel="prev">&laquo; #prevTitle</a></p>'."\n\t\t\t\t\t",
				'<p style="text-align:right;"><a href="#nextUrl" rel="next">#nextTitle &raquo;</a></p>'
			)); ?></div>

				<br /><div class="hasard">autres articles à lire :
		 </div>
				   <ul>
    <?php include(dirname(__FILE__).'/suggestion.php'); ?>
    </ul>
				<footer>
				<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
				<br /><small>
				<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?> - <?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?> -
						<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></time> -
						<a href="#comments" title="<?php $plxShow->artNbCom(); ?>"><?php $plxShow->artNbCom(); ?></a>
						</small>
				</footer>
    			</article>
			<?php $plxShow->artAuthorInfos('<div class="author-infos">#art_authorinfos</div>'); ?>
			<?php include(dirname(__FILE__).'/commentaires.php'); ?>
		</section>
		<?php include(dirname(__FILE__).'/sidebararticle.php'); ?>
	</main>
<?php include(dirname(__FILE__).'/footer.php'); ?>
