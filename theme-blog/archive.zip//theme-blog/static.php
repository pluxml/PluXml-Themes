<?php include('header.php'); # On insere le header ?>
<div id="page">
	<div id="content">
		<?php $plxShow->staticContent(); ?>
	</div>
</div>
<?php include('footer.php'); # On insere le footer ?>
