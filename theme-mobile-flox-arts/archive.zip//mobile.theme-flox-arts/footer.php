<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> - Th&egrave;me par <a href="http://www.flox-arts.net">Flox-arts.net</a><br />
		<a href="#top">Haut de page</a>
	</p>
</div>
</body>
</html>