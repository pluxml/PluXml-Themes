<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Decorative
Description: Fixed-width, two-column design from small sites and blogs.
Version    : 1.0
Released   : 20071101

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title><?php __('pagetitle'); ?></title>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <link rel="stylesheet" type="text/css" href="<?php __('template'); ?>/default.css" media="screen" />
 <link rel="alternate" type="application/rss+xml" title="Rss" href="core/rss.php" />
 <link rel="alternate" type="application/atom+xml" title="Atom" href="core/atom.php" />
</head>
<body>
<!-- start header -->
<div id="header">
 <div id="logo">
  <h1><?php __('maintitle', 'link'); ?></h1>
  <p><?php __('subtitle'); ?></p>
 </div>
 <!-- Pour ceux qui veulent la recherche: <div id="search">
  <form method="get" action="">
   <fieldset>
   <input id="s" type="text" name="s" value="" class="text" />
   <input id="x" type="submit" value="Search" class="button" />
   </fieldset>
  </form> -->
 </div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
 <!-- start content -->
 <div id="content">

 <?php # En mode 'home' ou 'catégorie' # ?>
 <?php if($pluxml->mode == 'home' || $pluxml->mode =='cat') : ?>
 <?php # Liste d'articles # ?>
 <?php while($pluxml->result->loop()):?>

  <div class="post">
   <p class="meta"><small><?php __('date'); ?>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php __('categorie'); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php __('nb_com'); ?></small></p>
   <h2><?php __('title', 'link'); ?></h2> <!-- Si vous en voulez un plus grand, remplacez le h2 par un h1 class="title" -->
   <div class="entry">
    <?php __('chapo'); ?>
   </div>
  </div>

 <?php endwhile; ?>
 <div class="post"><div class="entry"><?php __('pagination'); ?></div></div>
 <?php endif; ?>
 <?php # Fin mode 'home'/'catégorie' # ?>

 <?php # En mode 'article' # ?>
 <?php if($pluxml->mode == 'article') : ?>		
 <?php # Liste d'articles # ?>
 <?php while($pluxml->result->loop()):?>

<div class="post">
   <p class="meta"><small><?php __('date'); ?> &agrave; <?php __('hour'); ?> 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php __('categorie'); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Par <?php __('author'); ?></small></p>
   <h2><?php __('title'); ?></h2> <!-- Si vous en voulez un plus grand, remplacez le h2 par un h1 class="title" -->
   <div class="entry">
    <?php __('content'); ?>
   </div>
  </div>
  
 <?php endwhile; ?>
 <?php if($pluxml->coms):?>
 <div class="post"><h2>Commentaires</h2></div>

<?php while($pluxml->coms->loop()):?>

<div class="post">
   <p class="meta"><small><?php __('com_date'); ?>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php __('com_author', 'link'); ?> </small></p>
   <div class="entry">
    <?php __('com_content'); ?>
   </div>
  </div>

 <?php endwhile; ?>
 <?php endif; ?>
 
<?php if($pluxml->config['allow_com'] == 1 && $pluxml->result->f('allow_com') == 1) : ?>
<h3>&Eacute;crire un commentaire</h3>
<form action="index.php?<?php echo $pluxml->get; ?>" method="post">
  <label>Nom&nbsp;:</label>
  <input name="name" type="text" size="30" value="" /><br />
  <label>Site (facultatif)&nbsp;:</label>
  <input name="site" type="text" size="30" value="http://" /><br />
  <label>E-mail (facultatif)&nbsp;:</label>
  <input name="mail" type="text" size="30" value="" /><br />
  <label>Commentaire&nbsp;:</label><br /><br />
  <textarea name="message" cols="35" rows="8"></textarea>

  <?php # affichage du capcha anti-spam
   if($pluxml->config['capcha'] == 1){
    echo '<label><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label><br />';
    echo '<p>'.$capcha->q().'<input name="rep" type="text" size="10" /></p>';
    echo '<input name="rep2" type="hidden" value="'.$capcha->r().'" />';
    } ?>

  <p><input type="submit" value="Envoyer" /></p>
</form>

<?php endif; ?>
<?php endif; ?>
<?php # Fin mode 'article' # ?>


 </div>
 <!-- end content -->
 <!-- start sidebar -->
 <div id="sidebar">
  <ul>
   <li>
    <h2>Cat&eacute;gories</h2>
     <?php __('catlist', 'Accueil'); ?>
   </li>
   <li>
    <h2>Syndication</h2>
    <ul>
     <li><?php __('rss'); ?></li>
     <li><?php __('atom'); ?></li>
    </ul>
   </li>
  </ul>
 </div>
 <!-- end sidebar -->
 <div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
 <p>&copy;2007 All Rights Reserved. &nbsp;&bull;&nbsp; Design par <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></p>
 <p>Adaptation par <a href="http://antalmir.net">Eolhyte</a> Sous License By-Sa</p>
</div>
<!-- end footer -->
</body>
</html>
