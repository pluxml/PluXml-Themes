<?php
@ob_start("ob_gzhandler");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--

	Nonzero1.0 by nodethirtythree design
	http://www.nodethirtythree.com
	missing in a maze

-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="generator" content="Pluxml <?php __('version');?>" />
<meta name="robots" content="all" />
<link rel="stylesheet" type="text/css" href="<?php __('template'); ?>/style.css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="Rss" href="core/rss.php" />
<link rel="alternate" type="application/atom+xml" title="Atom" href="core/atom.php" />
<title><?php __('pagetitle'); ?></title>
</head>
<body>

<div id="header">

	<div id="header_inner" class="fluid">

		<div id="logo">
			<h1><?php __('maintitle'); ?></h1>
			<h2><?php __('subtitle'); ?></h2>
		</div>
		
		<div id="menu">
			<?php __('catlist', 'Accueil'); ?>
		</div>
		
	</div>
</div>

<div id="main">

	<div id="main_inner" class="fluid">

		<div id="primaryContent_2columns">

			<div id="columnA_2columns">
			
				<?php # En mode 'home' ou 'cat�gorie' # ?>
				<?php if($pluxml->mode == 'home' || $pluxml->mode =='cat') : ?>

		
				<?php # Liste d'articles # ?>
				<?php while($pluxml->result->loop()):?>
					<div class="post">
						<h3><?php __('title', 'link'); ?></h3>
						<ul class="post_info">
						<li class="date">le <?php __('date'); ?> | <?php __('categorie'); ?></li>
						<li class="comments"><?php __('nb_com'); ?></li>
						</ul>
					<?php __('chapo'); ?>
					</div>
				<?php endwhile; ?>
		
				<?php endif; ?>
				<?php # Fin mode 'home'/'cat�gorie' # ?>
				
				<?php # En mode 'article' # ?>
			
				<?php if($pluxml->mode == 'article') : ?>
		
				<?php # Liste d'articles # ?>
				<?php while($pluxml->result->loop()):?>
					<div class="post">
						<h3><?php __('title'); ?></h3>
						<ul class="post_info">
							<li class="date">Par <?php __('author'); ?>, le <?php __('date'); ?> � <?php __('hour'); ?> |  <?php __('categorie'); ?></li>
						</ul>
						<?php __('content'); ?>
					
				<?php endwhile; ?>


				<?php if($pluxml->coms):?>	
				<div id="comments">
					<h2>Commentaires</h2>
				</div>
				<?php while($pluxml->coms->loop()):?>
					<div class="comment">
						<p><?php __('com_author', 'link'); ?> a dit le <?php __('com_date'); ?> :</p>
						<blockquote><?php __('com_content'); ?></blockquote><br />
					</div>
				<?php endwhile; ?>
				<?php endif; ?>
				<?php if($pluxml->config['allow_com'] == 1 && $pluxml->result->f('allow_com') == 1) : ?>
				<div id="form">
					<h2>Ecrire un commentaire</h2>
					<form action="index.php?<?php echo $pluxml->get; ?>" method="post">
						Nom&nbsp;:<br />
						<input name="name" type="text" size="30" maxlength="255" value="" /><br />
						Site (facultatif)&nbsp;:<br />
						<input name="site" type="text" size="40" maxlength="255" value="http://" /><br />
						E-mail (facultatif)&nbsp;:<br />
						<input name="mail" type="text" size="40" maxlength="255" value="" /><br />
						Commentaire&nbsp;:<br />
						<textarea name="message" cols="35" rows="8"></textarea><br />
				
						<?php # affichage du capcha anti-spam
						if($pluxml->config['capcha'] == 1){
							echo '<br />V�rification anti-spam&nbsp;:<br />';
							echo ''.$capcha->q().'&nbsp;&nbsp;<input name="rep" type="text" size="10" /><br />';
							echo '<input name="rep2" type="hidden" value="'.$capcha->r().'" />';
						} ?>
				
						<br /><input type="submit" value="Envoyer" />
					</form>
				</div>
				<?php endif; ?>

				</div>
				<?php endif; ?>
				<?php # Fin mode 'article' # ?>
				<?php __('pagination'); ?>
			</div>
	
		</div>
		
		<div id="secondaryContent_2columns">
		
			<div id="columnC_2columns">
	
				<h4><span>Syndication</span></h4>
				<ul class="links">
				<li class="first"><?php __('rss'); ?></li>
				<li><?php __('atom'); ?></li>
				<li><a href="core/admin/">Admin</a></li>
				</ul>
				
				<h4><span>Liens</span> externes</h4>
				<ul class="links">
				<li class="first"><a href="http://www.blogotext.com/">BlogoText</a></li>
				<li><a href="http://arcsin.se/">Arcsin</a></li>
				<li><a href="http://www.ginger-ninja.net/">GingerNinja!</a></li>
				<li><a href="http://www.free-css-templates.com/">David Herreman</a></li>
				</ul>

			</div>

		</div>

		<br class="clear" />

	</div>

</div>

<div id="footer" class="fluid">
	&copy; 2007 <?php __('maintitle'); ?>. G�n�r� par <a href="http://pluxml.org">Pluxml</a> en <?php __('chrono'); ?>. Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree Design</a>.
</div>

</body>
</html>