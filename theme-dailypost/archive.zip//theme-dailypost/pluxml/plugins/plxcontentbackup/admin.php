<?php if(!defined('PLX_ROOT')) exit; ?>
<?php header('location:parametres_plugin.php?p='.urlencode('plxcontentbackup')) ?>