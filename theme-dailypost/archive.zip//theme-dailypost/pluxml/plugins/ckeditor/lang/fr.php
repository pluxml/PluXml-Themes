<?php

$LANG = array(

'L_ERROR_INVALID_DIR'				=> 'Répertoire invalide',
'L_UPLOAD_DIR'						=> 'Répertoire de stockage des fichiers (chemin relatif)',
'L_ERR_UPLDIR_NOT_DEFINED'			=> 'Répertoire de stockage des fichiers non défini',
'L_SAVE'							=> 'Enregister',

);
?>