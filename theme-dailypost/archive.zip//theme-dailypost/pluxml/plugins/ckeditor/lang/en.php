<?php

$LANG = array(

'L_ERROR_INVALID_DIR'				=> 'Invalid directory',
'L_UPLOAD_DIR'						=> 'Upload directory (relative path)',
'L_ERR_UPLDIR_NOT_DEFINED'			=> 'Upload directory not defined',
'L_SAVE'							=> 'Save',

);
?>