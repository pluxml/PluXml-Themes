<?php

$LANG = array(

'L_MESSAGE'				=>	'Enter image code',	,
'L_MESSAGE_MAL_VOYANT'	=> 	'Check this box if it\'s difficult to read the code &rarr;'

);
?>