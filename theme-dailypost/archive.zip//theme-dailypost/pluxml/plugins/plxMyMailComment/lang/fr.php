<?php

$LANG = array(

'L_EMAIL_NEW_COMMENT'			=> 'Nouveau commentaire :',
'L_EMAIL_NEW_COMMENT_BY'		=> 'Nouveau commentaire de',
'L_EMAIL_EDIT_COMMENT'			=> 'Editer le commentaire',
'L_EMAIL_READ_ONLINE'			=> 'Lire le commentaire en ligne ici ',
'L_EMAIL_DIRECT_ANSWER'			=> 'R&eacute;pondre &agrave; ce commentaire',
'L_EMAIL_WAITING_MODERATION'	=> 'Commentaire en attente de mod&eacute;ration',
'L_EMAIL_MANAGE_COMMENTS'		=> 'G&eacute;rer les commentaires',

# admin

'L_WARNING_NO_EMAIL'			=> 'Veuillez renseigner une adresse email dans votre profil',
'L_MAIL_AVAILABLE'				=> 'Fonction d\'envoi de mail disponible',
'L_MAIL_NOT_AVAILABLE'			=> 'Fonction d\'envoi de mail non disponible',
'L_SENDER_CC'					=> 'Destinataires en copie du mail<br />(s&eacute;par&eacute;s par des virgules)',
'L_SENDER_BCC'					=> 'Destinataires en copie cach&eacute;e du mail<br />(s&eacute;par&eacute;s par des virgules)',
'L_SAVE'						=> 'Enregistrer',

);
?>