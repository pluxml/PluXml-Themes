<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="fond-blanc">
<article id="article"> <!-- L'article proprement dit commence ici. On indique aux crawlers que c'est la partie intéressante à indexer... -->
    <header class="titre">       
	<h1>Une erreur a &eacute;t&eacute; d&eacute;tect&eacute;e :</h1>    
    </header>		

    <section><!-- contenus de la page -->
    	<?php $plxShow->erreurMessage(); ?>
	<p><a href="./" title="Accueil du site">Retour page d'accueil</a></p>
    </section>

</article>		
		
<nav id="sidebar"><!-- Début de la sidebar. Comme c'est un élément de navigation on le met aussi dans une balise <nav> -->
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</nav>
<div style="clear:both;"></div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>