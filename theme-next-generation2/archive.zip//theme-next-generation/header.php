<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta http-equiv="Content-type" content="text/html;charset=<?php $plxShow->charset(); ?>" />
        <link rel="stylesheet" href="<?php $plxShow->template(); ?>/style.css" type="text/css" />
	<link rel="alternate" type="application/atom+xml" title="Atom articles" href="./feed.php?atom" />
	<link rel="alternate" type="application/rss+xml" title="Rss articles" href="./feed.php?rss" />
	<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="./feed.php?atom/commentaires" />
	<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="./feed.php?rss/commentaires" />
<title><?php $plxShow->pageTitle(); ?></title>  
<!-- TRES IMPORTANT : Les lignes ci-dessous permettent au navigateur MSIE de prendre en compte les nouvelles balises HTML -->

<!--[if IE]>
    <script type="text/javascript">
        document.createElement("header");
        document.createElement("footer");
        document.createElement("nav");
        document.createElement("article");
        document.createElement("section");
        document.createElement("hgroup");
        document.createElement("aside");
    </script>
<![endif]-->
</head>

<body>
<div id="conteneur"> <!-- nécessaire pour utiliser la technique de centrage par margin:auto -->
<header> <!-- on indique que les éléments compris dans cette balise est un header -->
	<nav id="pages"> <!-- comme vous pouvez le constater, on peut appliquer un style aux balises html5 (bien que ceci limite la compatibilité) -->
      <ul id="navlist">
		<?php $plxShow->staticList('Accueil'); ?>
	  </ul>
    </nav>
	<hgroup id="logo"> <!-- On regroupe le logo et sa baseline -->
        <h1><?php $plxShow->mainTitle('link'); ?></h1>
        <h2><?php $plxShow->subTitle(); ?></h2>

    </hgroup>
</header>