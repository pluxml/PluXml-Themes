<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="fond-blanc">
<article id="article">

    <header class="titre" id="<?php echo $plxShow->plxMotor->plxRecord_arts->f('url') ?>"><!-- Voici un nouveau header mais rapporté à l'article et non à la page -->
        
	<h1><?php $plxShow->artTitle(); ?></h1>
        <pre>Le <?php $plxShow->artDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?> - Dans <?php $plxShow->artCat(); ?></pre>
      
    </header>
		
    <section><!-- contenus de l'article -->
        <?php $plxShow->artContent(); ?>
    </section>	

    <aside id="autres">
		<?php # Si on a des commentaires ?>
		<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>

				<h2>Commentaires</h2>
				<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
					<div id="<?php $plxShow->comId(); ?>" class="comment">
						<div class="info_comment">
							<p>Par <?php $plxShow->comAuthor('link'); ?> 
							le <?php $plxShow->comDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?></p>
						</div>
						<blockquote><?php $plxShow->comContent() ?></blockquote>
					</div>
				<?php endwhile; # Fin de la boucle sur les commentaires ?>
				<?php # On affiche le fil Atom de cet article ?>
				<div class="feed_article"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>
				
		<?php endif; # Fin du if sur la prescence des commentaires ?>
	
		<?php # Si on autorise les commentaires ?>
		<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>				
<div id="formulaire">
				
<fieldset>
<legend><span>Laisser un Commentaire</span></legend>
<p><?php $plxShow->comMessage(); ?></p>

<form action="<?php $plxShow->artUrl(); ?>#form" method="post" id="contact">

<label for="name">Nom</label>
<input  tabindex="1" type="text" name="name" id="name" value="" />

<label for="mail">E-mail <span>(facultatif)</span></label>
<input  tabindex="2" type="text" name="mail" id="mail" value="" />

<label for="site">Site</label>
<input  tabindex="3" type="text" name="site" id="site" value="" />

<?php # Affichage du capcha anti-spam
if($plxShow->plxMotor->aConf['capcha']): ?>
<label for="rep">V&eacute;rification anti-spam <span><?php $plxShow->capchaQ(); ?></span></label>
<input  tabindex="4" type="text" name="rep" id="rep" value="" />
<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
<?php endif; # Fin du if sur le capcha anti-spam ?>

<label for="content">Commentaire</label>
<textarea  tabindex="5" cols="30" rows="10" name="content" id="content"><?php $plxShow->comGet('content',''); ?></textarea>


<button tabindex="6" type="submit" name="submit" id="send">Envoyer</button>

</form>

</fieldset>
</div>
		<?php endif; # Fin du if sur l'autorisation des commentaires ?>
   </aside>	
</article>		
		
<nav id="sidebar"><!-- Début de la sidebar. Comme c'est un élément de navigation on le met aussi dans une balise <nav> -->
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</nav>
<div style="clear:both;"></div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>