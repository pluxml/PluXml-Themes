<?php if(!defined('PLX_ROOT')) exit; ?>
<footer id="general">
	<p>Carbure au <a href="http://pluxml.org" title="Blog ou Cms sans base de données">Pluxml</a> 
		<?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?>, Valide <a href="http://validator.w3.org/check?uri=referer">HTML 5</a> | 
		<a href="core/admin/">Administration</a> | 
		<a href="#">Haut de page</a></p>
</footer>
</div>
</div>
</body>
</html>