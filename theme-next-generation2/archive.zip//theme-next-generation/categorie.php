<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="fond-blanc">
<article id="article"> <!-- L'article proprement dit commence ici. On indique aux crawlers que c'est la partie intéressante à indexer... -->

		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>

    <header class="titre" id="<?php echo $plxShow->plxMotor->plxRecord_arts->f('url') ?>">
        
	<h1><?php $plxShow->artTitle('link'); ?></h1>
        <pre>Le <?php $plxShow->artDate('#day #num_day #month #num_year(4)'); ?> - Dans <?php $plxShow->artCat(); ?> - <?php $plxShow->artNbCom(); ?></pre>
      
    </header>

    <section><!-- contenus de l'article -->
        <?php $plxShow->artChapo(); ?>
    </section>

		<?php endwhile; # Fin de la boucle sur les articles ?>

    <aside id="autres"><!-- la balise <aside> indique au crawler ce qui vient compléter l'article, si l'on s'en tient stricto sensu aux specs du W3C. A priori elle ne sert donc pas à indiquer une sidebar !! -->
		<?php # On affiche le fil Atom de cet article ?>
		<ul><li><?php $plxShow->artFeed('atom',$plxShow->catId()); ?></li></ul>
		<?php # On affiche la pagination ?>
		<p id="pagination"><?php $plxShow->pagination(); ?></p>   
    </aside>
</article>		
		
<nav id="sidebar"><!-- Début de la sidebar. Comme c'est un élément de navigation on le met aussi dans une balise <nav> -->
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</nav>
<div style="clear:both;"></div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>