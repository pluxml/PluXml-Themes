<?php if(!defined('PLX_ROOT')) exit; ?>
    <div class="item">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('Accueil','#cat_name'); ?>
		</ul>
		<h2>Derniers articles</h2>
		<ul>
			<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
		</ul>
		<h2>Derniers commentaires</h2>
		<ul>
			<?php $plxShow->lastComList('<a href="#com_url">#com_author a dit :</a><br/>#com_content(70)'); ?>
		</ul>
	</div>
    <div class="item">
		<h2>Syndication</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
	</div>