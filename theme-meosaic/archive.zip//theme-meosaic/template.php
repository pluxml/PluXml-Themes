<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Mosaic
Description: A two-column, fixed width Web 2.0 design with fluid header and menu. Suitable for small business websites and blogs.
Version    : 1.0
Released   : 20071028

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title><?php __('pagetitle'); ?></title>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <link rel="stylesheet" type="text/css" href="<?php __('template'); ?>/default.css" media="screen" />
 <link rel="alternate" type="application/rss+xml" title="Rss" href="core/rss.php" />
 <link rel="alternate" type="application/atom+xml" title="Atom" href="core/atom.php" />
</head>
<body>
<!-- start header -->
<div id="header">
 <div id="logo">
  <h1><?php __('maintitle','link'); ?></h1>
  <p><?php __('subtitle'); ?></p>
 </div>
 <div id="menu">
  <ul>
   <li><a href="index.php">Accueil</a></li>
  </ul>
 </div>
</div>
<!-- end header -->
<hr />
<!-- start page -->
<div id="page">
 <!-- start content -->
 <div id="content">

<?php # En mode 'home' ou 'catégorie' # ?>
<?php if($pluxml->mode == 'home' || $pluxml->mode =='cat') : ?>
<?php # Liste d'articles # ?>
<?php while($pluxml->result->loop()):?>

  <div class="post">
   <p class="meta">
    <span class="date"> <?php __('date'); ?> &agrave; <?php __('hour'); ?></span> &nbsp;&nbsp;&nbsp;
    <span class="comments"><?php __('nb_com'); ?></span> &nbsp;&nbsp;&nbsp;
    </p>
   <h1 class="title"><?php __('title', 'link'); ?></h1>
   <div class="entry">
    <?php __('chapo'); ?>
   </div>
   <div class="bgbottom" style="clear: both;"></div>
  </div>

<?php endwhile; ?>
<?php __('pagination'); ?>
<?php endif; ?>
<?php # Fin mode 'home'/'catégorie' # ?>

<?php # En mode 'article' # ?>
<?php if($pluxml->mode == 'article') : ?>		
<?php # Liste d'articles # ?>
<?php while($pluxml->result->loop()):?>

  <div class="post">
   <p class="meta">
    <span class="date"> <?php __('date'); ?> &agrave; <?php __('hour'); ?></span> &nbsp;&nbsp;&nbsp;
    <span class="comments"><?php __('nb_com'); ?></span> &nbsp;&nbsp;&nbsp;
    </p>
   <h1 class="title"><?php __('title'); ?></h1>
   <div class="entry">
    <?php __('content'); ?>
   </div>
   <div class="bgbottom" style="clear: both;"></div>
  </div>
<?php endwhile; ?>
<?php if($pluxml->coms):?>
<h2>Commentaires</h2>
<?php while($pluxml->coms->loop()):?>

  <div>
   <h3 class="title"><?php __('com_author','link'); ?> <small>le <?php __('com_date'); ?></small></h3>
   <div class="entry">
    <blockquote><p><?php __('com_content'); ?></p></blockquote>
   </div>
   <div class="bgbottom" style="clear: both;"></div>
  </div>
<?php endwhile; ?>
<?php endif; ?>

<?php if($pluxml->config['allow_com'] == 1 && $pluxml->result->f('allow_com') == 1) : ?>
<h2>&Eacute;crire un commentaire</h2>
<form action="index.php?<?php echo $pluxml->get; ?>" method="post">
 <fieldset>
  <label>Nom&nbsp;:</label>
  <input name="name" type="text" size="30" value="" /><br />
  <label>Site (facultatif)&nbsp;:</label>
  <input name="site" type="text" size="30" value="http://" /><br />
  <label>E-mail (facultatif)&nbsp;:</label>
  <input name="mail" type="text" size="30" value="" /><br />
  <label>Commentaire&nbsp;:</label><br /><br />
  <textarea name="message" cols="35" rows="8"></textarea>

  <?php # affichage du capcha anti-spam
   if($pluxml->config['capcha'] == 1){
    echo '<br /><label><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label><br />';
    echo '<p>'.$capcha->q().'<input name="rep" type="text" size="10" /></p>';
    echo '<input name="rep2" type="hidden" value="'.$capcha->r().'" />';
    } ?>

  <p><input type="submit" value="Envoyer" /></p>
 </fieldset>
</form>

<?php endif; ?>
<?php endif; ?>
<?php # Fin mode 'article' # ?>	

  </div>
 </div>
 <!-- end content -->
 <!-- start sidebar -->
 <div id="sidebar">
  <ul>
   <!-- pour la recherche <li id="search" class="widget widget_search">
    <form id="searchform" method="get" action="">
     <div>
      <input type="text" name="s" id="s" size="15" value="" />
      <br />
      <input type="submit" value="Search" />
     </div>
    </form>
   </li> -->
    <li>
     <h2 class="widgettitle">Cat&eacute;gories</h2>
     <?php __('catlist'); ?>
    </li>
    <li>
    <h2>Syndication</h2>
     <ul>
      <li><?php __('rss'); ?></li>
      <li><?php __('atom'); ?></li>
     </ul>
    </li>
  </ul>
 </div>
 <!-- end sidebar -->
</div>
<!-- end page -->
<hr />
<!-- start footer -->
<div id="footer">
 <p>&copy; <?php __('maintitle'); ?> &nbsp;&bull;&nbsp; Design: <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>
 &nbsp;&bull;&nbsp; Adaptation: <a href="http://antalmir.net">Eolhyte</a></p>
</div>
<!-- end footer -->
</body>
</html>
