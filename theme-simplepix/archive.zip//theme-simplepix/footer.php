<?php if (!defined('PLX_ROOT')) exit; ?>


    <!-- Once the page is loaded, initialized the plugin. -->
    <script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery-2.1.1.js" ></script>
	
	<!-- jQuery Pinterest -->
    <script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.pinto.js"></script>
    <script type="text/javascript" src="<?php $plxShow->template(); ?>/js/main.js"></script>
	
	<!-- Light Box -->
	<script src="<?php $plxShow->template(); ?>/js/lightbox-plus-jquery.min.js"></script>
	
	<!-- Menu -->
	<script src="<?php $plxShow->template(); ?>/js/script.js"></script>
	
	<script type="text/javascript">
		$('#container').pinto();
	</script>
	
</body>
</html>