<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="page-content" class="sub-page">
		<div class="container">
			<center>
				<article>
					<div class="content-item">
						<h3 class="title-item"><?php $plxShow->staticTitle(); ?></h3>
						<?php $plxShow->staticContent(); ?>
					</div>
				</article>
			</center>
		</div>
	</div>
<?php include(dirname(__FILE__).'/footer.php'); ?>
