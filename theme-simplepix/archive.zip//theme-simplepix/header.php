<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">
	<title><?php $plxShow->pageTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/menu.css">
    <link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/plucss.css">
    <link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/theme.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/font-awesome-4.4.0/css/font-awesome.min.css"  type="text/css">
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/lightbox.css">
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
	
    <!--[if lt IE 9]>
        <script src="<?php $plxShow->template(); ?>/js/html5shiv.js"></script>
        <script src="<?php $plxShow->template(); ?>/js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
	<div class="header">
		<div id='cssmenu' >
			<ul>
				<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
				<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
			   <li class=' has-sub'><a href='.'><span><?php $plxShow->lang('CATEGORIES'); ?></span></a>
				  <ul>
			  			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a></li>'); ?>
				  </ul>
			   </li>
			</ul>
		</div>
	</div>
    