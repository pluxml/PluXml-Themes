<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="page-content" class="sub-page">
		<div class="container">
			<center><article>
				<a class="example-image-link" href="<?php $plxShow->artThumbnail('#img_url'); ?>" data-lightbox="example-set">
				<img class="example-image" src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt=""></a>
				<div class="content-item">
					<h3 class="title-item"><?php $plxShow->artTitle(); ?></h3>
					<div class="time"> <?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></div>
					<ul class="list-inline">
						<li><a href="#"><i class="fa fa-eye"></i> 260</a></li>
						<li><a href="#"><i class="fa fa-comment"></i> 260</a></li>
						<li><a href="#"><i class="fa fa-heart"></i> 260</a></li>
						<li><a href="#"><i class="fa fa-share"></i> 260</a></li>
					</ul>
					<?php $plxShow->artContent(); ?>
				</div>
				<div class="bottom-item">
					<a href="." class="btn btn-share share"><i class="fa fa-share-alt"></i> Partager</a>
					<span class="user f-right"><?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?></span>
				</div>
				<?php include(dirname(__FILE__).'/commentaires.php'); ?>
			</article></center>
		</div>
	</div>
<?php include(dirname(__FILE__).'/footer.php'); ?>
