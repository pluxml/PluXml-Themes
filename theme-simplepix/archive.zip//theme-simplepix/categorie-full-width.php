<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="page-content" class="index-page">
		<div id="container">
			<div>
				<h1><?php $plxShow->catName(); ?></h1>
			</div>
			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
				<div class="item">
					<a class="example-image-link" href="<?php $plxShow->artThumbnail('#img_url'); ?>" data-lightbox="example-set" >
						<img class="example-image" src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>"/>
					</a>
					<div class="content-item">
						<h3 class="title-item"><?php $plxShow->artTitle('link'); ?></h3>
						<div class="time"> <?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></div>
						<p class="info"><?php $plxShow->artChapo(''); ?></p>
						
					</div>
					<div class="bottom-item">
						<a href="#" class="btn btn-share share"><i class="fa fa-share-alt"></i> Partager</a>
						<a href="#" class="btn btn-like"><i class="fa fa-heart-o"></i></a>
						<a href="#" class="btn btn-comment"><i class="fa fa-comment-o"></i></a>
						<a href="<?php $plxShow->artUrl(); ?>" class="btn btn-more"><i class="fa fa-long-arrow-right "></i></a>
					</div>
				</div>
			<?php endwhile; ?>
			
		</div>
	</div>
	
<?php include(dirname(__FILE__).'/footer.php'); ?>

