<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="page-content" class="sub-page">
		<div class="container">
			<center>
			<article>
				<a class="example-image-link" href="<?php $plxShow->artThumbnail('#img_url'); ?>" data-lightbox="example-set">
				<img class="example-image" src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt=""></a>
				<div class="content-item">
					<h3 class="title-item"><?php $plxShow->lang('ERROR'); ?></h3>
						<?php $plxShow->erreurMessage(); ?>
				</div>
			</article>
			</center>
		</div>
	</div>
<?php include(dirname(__FILE__).'/footer.php'); ?>
