<?php if(!defined('PLX_ROOT')) exit; ?>
                <!-- tabbed content -->
                <div class="tabbed-content post-tabs clearfix" id="post-tabs">

                  <!-- tab navigation (items must be in reverse order because of the tab-design) -->
                  <div class="tabs-wrap clearfix">
                    <ul class="tabs">
                      <li class="related-posts"><a href="#section-relatedPosts"><span>Articles similaires</span></a></li>
                      <li class="comments"><a href="#section-comments"><span>Commentaires</span></a></li>
                    </ul>
                  </div>
                  <!-- /tab nav -->

                  <!-- tab sections -->
                  <div class="sections">

                    <!-- comments -->
                    <div class="section clearfix" id="section-comments">
                      <div id="comments-wrap">
                        <div class="clearfix">

<?php # Si on a des commentaires ?>
<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
                          <ul id="comments" class="comments">
                          
		<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>

                            <!-- comment entry -->
                            <li class="comment depth-1 withAvatars" id="comment-<?php $plxShow->comId(); ?>">
                              <div class="comment-head comment depth-1 withAvatars">
                                <!-- <div class="avatar-box"><img alt="avatar" src="gravatar code" class="avatar" height='48' width='48' /></div> -->

                                <div class="author">
                                  <span class="by"><a class="comment-id" href="#comment-<?php $plxShow->comId(); ?>">#<?php $plxShow->comId(); ?></a> <?php $plxShow->comAuthor('link'); ?> &agrave; dit :</span><br />
                                  Le <?php $plxShow->comDate('#num_day #month #num_year(4)'); ?> 
                                </div>

                                <div class="controls bubble">
                                  <a class="reply" id="reply-to-<?php $plxShow->comId(); ?>" href="#respond" name="reply-to-<?php $plxShow->comId(); ?>">Répondre</a> <a class="quote" title="Quote" href="#respond">Citer</a>
                                </div>
                              </div>

                              <div class="comment-body clearfix" id="comment-body-<?php $plxShow->comId(); ?>">
                                <div class="comment-text">
                                  <?php $plxShow->comContent() ?>
                                </div><a id="comment-reply-<?php $plxShow->comId(); ?>" name="comment-reply-<?php $plxShow->comId(); ?>"></a>
                              </div>
                            </li>
                            <!-- /comment entry -->
		<?php endwhile; # Fin de la boucle sur les commentaires ?>

                          </ul>
		<?php # On affiche le fil Atom de cet article ?>
		<p style="float:right;"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></p>
<?php endif; # Fin du if sur la prescence des commentaires ?>

                        </div>
                      </div>
<?php # Si on autorise les commentaires ?>
<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>

                      <!-- comment form -->
                      <div class="comment-form clearfix" id="respond">
                      <strong style="color:red;"><?php $plxShow->comMessage(); ?></strong>
                        <script type="text/javascript">
                        /* <![CDATA[ */
                        function checkvalues(){
                          if(jQuery('#field-name').val()=='Nom (requis)') jQuery('#field-name').val('');
                          if(jQuery('#field-mail').val()=='E-mail (facultatif)') jQuery('#field-mail').val('');
                          if(jQuery('#field-site').val()==('Site (facultatif)' || 'http://')) jQuery('#field-site').val('');
                        }
                        /* ]]> */
                        </script>

                        <form action="<?php $plxShow->artUrl(); ?>#respond" method="post" id="commentform">
                          <p><a class="js-link" id="show-author-info" name="show-author-info">Afficher tout les champs</a></p>

                          <div id="author-info" class="hidden">
                            <div class="row">
                              <input type="text" name="name" id="field-name" class="validate required textfield clearField" value="<?php $plxShow->comGet('name','Votre Nom'); ?>" size="40" />
                            </div>
                            <div class="row">
                               <input type="text" name="mail" id="field-mail" class="validate required textfield clearField" value="<?php $plxShow->comGet('mail','@'); ?>" size="40" />
                            </div>
                            <div class="row">
                               <input type="text" name="site" id="field-site" class="textfield clearField" value="<?php $plxShow->comGet('site','http://'); ?>" size="40" />
                            </div>
                          </div>

                          <div class="row">
                            <textarea name="content" id="comment" class="validate required" rows="8" cols="50"><?php $plxShow->comGet('content',''); ?></textarea>
                          </div>
                          
					<?php # Affichage du capcha anti-spam
					if($plxShow->plxMotor->aConf['capcha']): ?>
                          <div class="row">
						<?php $plxShow->capchaQ(); ?>&nbsp;:&nbsp;<input name="rep" type="text" size="10" />
						<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
                          </div>
					<?php endif; # Fin du if sur le capcha anti-spam ?>
                    
                          <div class="clearfix"></div>

                          <div id="submitbox">
                            <input name="submit" type="submit" id="submit" class="button" value="Envoyer" />
                            <input name="cancel-reply" type="button" id="cancel-reply" class="button hidden" value="Effacer" />
                          </div>
                        </form>
                      </div>
                      <!-- /comment form -->

                    </div>
                    <!-- /comments -->

                    <!-- trackbacks -->
                    <div class="section" id="section-trackbacks">
                      <h6 class="title">Aucun Commentaire pour le moment.</h6>
                    </div>
                    <!-- /trackbacks -->


                  </div>
                  <!-- /tab sections -->
<?php endif; # Fin du if sur l'autorisation des commentaires ?>
                </div>
                <!-- /tabbed content -->