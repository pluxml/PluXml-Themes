<?php if(!defined('PLX_ROOT')) exit; ?>
            <!-- sidebar -->
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
            <!-- sidebar -->

          </div>
        </div>
        <!-- /main content -->

        <!-- footer -->
        <div id="footer">
          <div class="page-content">
           <div id="copyright">&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> / Mystique theme by <a href="http://digitalnature.ro">digitalnature</a> adapté par <a href="http://forum.pluxml.org/profile.php?id=2985">Fred</a>.<br />
              <a class="rss-subscribe" href="feed.php?rss" title="RSS Feeds">RSS Feeds</a> <a class="valid-xhtml" href="http://validator.w3.org/check?uri=referer" title="Valid XHTML">XHTML 1.1</a> <a class="valid-xhtml" href="core/admin/">Administration</a> <a id="goTop" class="js-link" name="goTop">Haut de page</a> <!--[if lte IE 6]> <script type="text/javascript"> isIE6 = true; isIE = true; </script> <![endif]-->
               <!--[if gte IE 7]> <script type="text/javascript"> isIE = true; </script> <![endif]-->
               <script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery.mystique.js">
</script>
            </div>
          </div>
        </div>
        <!-- /footer -->

      </div>
    </div>
    <!-- /shadow -->

    <!-- page controls -->
    <div id="pageControls"></div>
    <!-- /page controls -->

  </div>
  <!-- /page -->
</body>
</html>