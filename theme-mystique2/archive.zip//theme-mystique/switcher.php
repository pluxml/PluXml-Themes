<?php 
/**
 * Switcher de Feuilles de style
 *
 * @package Theme PluXml
 * @author    Fred
 * @website  http://mypluxml.com
 **/

function construire_url($css) {
global $plxMotor;

return PLX_ROOT.'themes/'.$plxMotor->style.'/color-' . htmlspecialchars($css) . '.css'; 
}
$css = array( 
    'green', 
    'red', 
    'grey', 
    'blue' 
); 
 
$actuel = htmlspecialchars($_SERVER['PHP_SELF']); 
$new_style = (isset($_GET['style'])) ? $_GET['style'] : ''; 
$cookie_style = (isset($_COOKIE['style'])) ? $_COOKIE['style'] : ''; 
 
if(in_array($new_style, $css, true)) 
{ 
    setcookie('style', $new_style, time() + (365 * 24 * 3600), '/'); 
    $url = construire_url($new_style); 
} 
 
else if(in_array($cookie_style, $css, true)) 
{ 
    $url = construire_url($cookie_style); 
} 
 
else 
{ 
    $url = construire_url($css[0]); 
} 
?>