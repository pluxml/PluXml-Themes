<?php if(!defined('PLX_ROOT')) exit; ?>
            <div id="sidebar">

              <ul class="blocks">

                <!-- search form -->
                <li class="block">
                  <div class="search-form">
                    <form method="get" id="searchform" action="<?php echo PLX_ROOT ?>?static5/recherche" class="clearfix">
                      <fieldset>
                        <div id="searchfield">
                          <input type="hidden" name="search" value="search"  />
                          <input type="text" name="searchfield" id="searchbox" class="text clearField" value="Rechercher..." onblur="if(this.value=='') this.value='Rechercher...';" onfocus="if(this.value=='Rechercher...') this.value='';" />
                        </div><input type="submit" value="" class="submit" />
                      </fieldset>
                    </form>
                  </div>
                </li>
                <!-- /search form -->

                <!-- tabbed content -->
                <li class="block">
                  <div class="block-sidebar_tabs">

                    <div class="tabbed-content sidebar-tabs clearfix" id="instance-sidebartabswidget">

                      <!-- tab navigation (items must be in reverse order because of the tab-design) -->
                      <ul class="box-tabs clearfix">
                        <li class="archives"><a href="#instance-sidebartabswidget-section-archives" title="Archives"><span>Archives</span></a></li>

                        <li class="tags"><a href="#instance-sidebartabswidget-section-tags" title="Tags"><span>Tags</span></a></li>

                        <li class="recentcomm"><a href="#instance-sidebartabswidget-section-recentcomments" title="Derniers commentaires"><span>Derniers commentaires</span></a></li>

                        <li class="popular"><a href="#instance-sidebartabswidget-section-popular" title="Derniers articles"><span>Derniers articles</span></a></li>

                        <li class="categories"><a href="#instance-sidebartabswidget-section-categories" title="Cat&eacute;gories"><span>Cat&eacute;gories</span></a></li>
                      </ul>
                      <!-- /tab nav -->

                      <!-- tab sections -->
                      <div class="sections">

                        <div class="box section" id="instance-sidebartabswidget-section-categories">
                          <div class="box-top-left">
                            <div class="box-top-right"></div>
                          </div>

                          <div class="box-main">
                            <div class="box-content">
                              <ul class="menuList categories">
                                <?php $plxShow->catList('','<li id="#cat_id"><a href="#cat_url" class="#fadeThis cat_status" title="#cat_name"><span class="entry">#cat_name</span></a></li>'); ?>
                              </ul>
                            </div>
                          </div>
                        </div>

                        <div class="box section" id="instance-sidebartabswidget-section-tags">
                          <div class="box-top-left">
                            <div class="box-top-right"></div>
                          </div>

                          <div class="box-main">
                            <div class="box-content">
                              <div class="tag-cloud">
                                <a href="#" style='font-size: 8pt;'>bla</a> <a href="#" style='font-size: 8pt;'>blah</a> <a href="#" style='font-size: 16.4pt;'>computers</a> <a href="#" style='font-size: 8pt;'>cool</a> <a href="#" style='font-size: 8pt;'>crushing</a> <a href="#" style='font-size: 8pt;'>effects</a> <a href="#" style='font-size: 8pt;'>energy</a> <a href="#" style='font-size: 8pt;'>nexus</a> <a href="#" style='font-size: 22pt;'>fusion</a> <a href="#" style='font-size: 8pt;'>google</a> <a href="#" style='font-size: 8pt;'>bla</a> <a href="#" style='font-size: 8pt;'>blah</a> <a href="#" style='font-size: 16.4pt;'>computers</a> <a href="#" style='font-size: 8pt;'>energy</a> <a href="#" style='font-size: 8pt;'>nexus</a> <a href="#" style='font-size: 22pt;'>fusion</a> <a href="#" style='font-size: 8pt;'>google</a> <a href="#" style='font-size: 8pt;'>cool</a> <a href="#" style='font-size: 8pt;'>crushing</a> <a href="#" style='font-size: 8pt;'>effects</a> <a href="#" style='font-size: 8pt;'>blah</a> <a href="#" style='font-size: 16.4pt;'>computers</a> <a href="#" style='font-size: 8pt;'>cool</a> <a href="#" style='font-size: 8pt;'>crushing</a> <a href="#" style='font-size: 8pt;'>effects</a> <a href="#" style='font-size: 8pt;'>energy</a> <a href="#" style='font-size: 8pt;'>nexus</a> <a href="#" style='font-size: 22pt;'>fusion</a> <a href="#" style='font-size: 8pt;'>google</a> <a href="#" style='font-size: 8pt;'>bla</a> <a href="#" style='font-size: 8pt;'>blah</a> <a href="#" style='font-size: 16.4pt;'>computers</a> <a href="#" style='font-size: 8pt;'>energy</a> <a href="#" style='font-size: 8pt;'>nexus</a> <a href="#" style='font-size: 22pt;'>fusion</a> <a href="#" style='font-size: 8pt;'>google</a> <a href="#" style='font-size: 8pt;'>cool</a> <a href="#" style='font-size: 8pt;'>crushing</a> <a href="#" style='font-size: 8pt;'>effects</a>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="box section" id="instance-sidebartabswidget-section-archives">
                          <div class="box-top-left">
                            <div class="box-top-right"></div>
                          </div>

                          <div class="box-main">
                            <div class="box-content">
                              <ul class="menuList">
                                <li><a href="#" class="fadeThis"><span class="entry">March 2010 <span class="details inline">(3)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">January 2010 <span class="details inline">(6)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">December 2009 <span class="details inline">(2)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">November 2009 <span class="details inline">(1)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">October 2009 <span class="details inline">(4)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">August 2009 <span class="details inline">(1)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">June 2009 <span class="details inline">(2)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">April 2009 <span class="details inline">(2)</span></span></a></li>

                                <li><a href="#" class="fadeThis"><span class="entry">March 2009 <span class="details inline">(2)</span></span></a></li>
                              </ul>
                            </div>
                          </div>
                        </div>

                        <div class="box section" id="instance-sidebartabswidget-section-popular">
                          <div class="box-top-left">
                            <div class="box-top-right"></div>
                          </div>

                          <div class="box-main">
                            <div class="box-content">
                              <ul class="menuList">
                                <?php $plxShow->lastArtList('<li><a href="#art_url" class="fadeThis #art_status" title="#art_title"><span class="entry">#art_title</span></a></li>'); ?>
                              </ul>
                            </div>
                          </div>
                        </div>

                        <div class="box section" id="instance-sidebartabswidget-section-recentcomments">
                          <div class="box-top-left">
                            <div class="box-top-right"></div>
                          </div>

                          <div class="box-main">
                            <div class="box-content">
                              <ul class="menuList recentcomm">
                                <?php $plxShow->lastComList('<li class="clearfix"><a href="#com_url"><span class="entry">#com_author a dit : <span class="details">#com_content(34)</span></span></a></li>'); ?>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- tabbed content -->

                  </div>
                </li>

                <!-- login -->
                <li class="block">
                  <div class="block-login clearfix">
                    <h3 class="title"><span>Espace Membre</span></h3>

                    <div class="block-div"></div>

                    <div class="block-div-arrow"></div>

                    <form action="#" method="post">
                      <fieldset>
                        <label for="log">Utilisateur</label><br />
                        <input type="text" name="log" id="log" value="" size="20" /><br />
                        <label for="pwd">Mot de Passe</label><br />
                        <input type="password" name="pwd" id="pwd" size="20" /><br />
                        <input type="submit" name="submit" value="Connexion" class="button" /> <label for="rememberme"><input name="rememberme" id="rememberme" type="checkbox" checked="checked" value="forever" />Se rappeler de moi ?</label><br />
                      </fieldset>
                    </form>

                    <ul>
                      <li><a href="#">Inscription</a></li>

                      <li><a href="#">Mot de Passe perdu ?</a></li>
                    </ul>
                  </div>
                </li>
                <!-- /login -->

                <!-- links -->
                <li class="block">
                  <div class="block-bookmarks">
                    <h3 class="title"><span>Liens</span></h3>

                    <div class="block-div"></div>

                    <div class="block-div-arrow"></div>

                    <ul>
                      <li><a href="http://digitalnature.ro">Digital Nature</a></li>

                      <li><a href="http://google.fr">Google</a></li>

                      <li><a href="http://wordpress.org">Wordpress</a></li>
                    </ul>
                  </div>
                </li>
                <!-- /links -->

              </ul>

            </div>