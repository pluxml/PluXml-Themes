<?php
class plxPlugin extends plxShow{
	/**
	 * Constructeur qui initialise l'objet plxMotor par r�f�rence
	 *
	 * @param	plxMotor	objet plxMotor pass� par r�f�rence
	 * @return	null
	 * @author	Florent MONTHEL
	 **/
	function plxShow(&$plxMotor) {

		$this->plxMotor = &$plxMotor;
	}

	/**
	* M�thode qui affiche la liste des $max derniers commentaires.
	* Si la variable $art_id est renseign�e, seulement les commentaires 
	* de cet article seront retourn�s.
	*
	* @param    format    format du texte pour chaque commentaire (variable: #com_id,#com_url,#com_author,#com_content(num),#com_content,#com_date,#com_hour)
	* @param    max    nombre de commentaires maximum
	* @param    art_id    id de l'article cible (24,3)
	* @return    stdout
	* @author    Florent MONTHEL
	**/
    function lastComList($format='<a href="#com_url">#com_author a dit :</a><br/>#com_content(60)',$max=5,$art_id='') {

        # G�n�ration de notre motif
        if(empty($art_id))
            $motif = '/^[0-9]{4}.[0-9]{10}-[0-9]+.xml$/';
        else
            $motif = '/^'.str_pad($art_id,4,'0',STR_PAD_LEFT).'.[0-9]{10}-[0-9]+.xml$/';
        # Nouvel objet plxGlob et r�cup�ration des fichiers
        $plxGlob_coms = & new plxGlob(PLX_ROOT.$this->plxMotor->aConf['racine_commentaires']);
        $aFiles = $plxGlob_coms->query($motif,'com','rsort',0,$max);
        # On parse les fichiers
        if(is_array($aFiles)) { # On a des fichiers
            while(list($k,$v) = each($aFiles)) # On parcourt tous les fichiers
                $array[ $k ] = $this->plxMotor->parseCommentaire(PLX_ROOT.$this->plxMotor->aConf['racine_commentaires'].$v);
            # On stocke les enregistrements dans un objet plxRecord
            $plxRecord_coms = & new plxRecord($array);
        }
        if($plxGlob_coms->count AND $plxRecord_coms->size) { # On a des commentaires
            # On boucle sur nos articles
            while($plxRecord_coms->loop()) {
                # On modifie nos motifs
                $row = str_replace('#com_id',$plxRecord_coms->f('numero'),$format);
                $row = str_replace('#com_url','./?article'.intval($plxRecord_coms->f('article')).'/#c'.$plxRecord_coms->f('numero'),$row);
                $row = str_replace('#com_author',$plxRecord_coms->f('author'),$row);
                while(preg_match('/#com_content\(([0-9]+)\)/',$row,$capture))
                    $row = str_replace('#com_content('.$capture[1].')',plxUtils::strCut($plxRecord_coms->f('content'),$capture[1]),$row);
                $row = str_replace('#com_content',$plxRecord_coms->f('content'),$row);
                $row = str_replace('#com_date',plxUtils::dateIsoToHum($plxRecord_coms->f('date')),$row);
                $row = str_replace('#com_hour',plxUtils::heureIsoToHum($plxRecord_coms->f('date')),$row);
                # On gen�re notre ligne
                echo '<li>'.$row.'</li>';
            }
        }
    }

	/**
	* M�thode qui affiche la liste des $max derniers articles.
	* Si la variable $cat_id est renseign�e, seulement les articles 
	* de cette cat�gorie seront retourn�s.
	*
	* @param    format    format du texte pour chaque article (variable: #art_id,#art_url,#art_author,#art_title,#art_date,#art_hour)
	* @param    max    nombre d'articles maximum
	* @param    cat_id    id de la cat�gorie cible (1,home)
	* @return    stdout
	* @author    Florent MONTHEL
	**/
    function lastArtList($format='<a href="#art_url" title="#art_title">#art_title</a>',$max=5,$cat_id='') {

        # G�n�ration de notre motif
        if(empty($cat_id))
            $motif = '/^[0-9]{4}.([0-9]{3}|home).[0-9]{12}.[a-z0-9-]+.xml$/';
        elseif($cat_id == 'home')
            $motif = '/^[0-9]{4}.home.[0-9]{12}.[a-z0-9-]+.xml$/';
        else
            $motif = '/^[0-9]{4}.'.str_pad($cat_id,3,'0',STR_PAD_LEFT).'.[0-9]{12}.[a-z0-9-]+.xml$/';
        # Nouvel objet plxGlob et r�cup�ration des fichiers
        $plxGlob_arts = & new plxGlob(PLX_ROOT.$this->plxMotor->aConf['racine_articles']);
        $aFiles = $plxGlob_arts->query($motif,'art','rsort',0,$max);
        # On parse les fichiers
        if(is_array($aFiles)) { # On a des fichiers
            while(list($k,$v) = each($aFiles)) # On parcourt tous les fichiers
                $array[ $k ] = $this->plxMotor->parseArticle(PLX_ROOT.$this->plxMotor->aConf['racine_articles'].$v);
            # On stocke les enregistrements dans un objet plxRecord
            $plxRecord_arts = & new plxRecord($array);
        }
        if($plxGlob_arts->count AND $plxRecord_arts->size) { # On a des articles
            # On boucle sur nos articles
            while($plxRecord_arts->loop()) {
                $num = intval($plxRecord_arts->f('numero'));
                # On modifie nos motifs
                $row = str_replace('#art_id',$num,$format);
                $row = str_replace('#art_url','./?article'.$num.'/'.$plxRecord_arts->f('url'),$row);
                $row = str_replace('#art_author',htmlspecialchars($plxRecord_arts->f('author'),ENT_QUOTES,PLX_CHARSET),$row);
                $row = str_replace('#art_title',htmlspecialchars($plxRecord_arts->f('title'),ENT_QUOTES,PLX_CHARSET),$row);
                $row = str_replace('#art_date',plxUtils::dateIsoToHum($plxRecord_arts->f('date')),$row);
                $row = str_replace('#art_hour',plxUtils::heureIsoToHum($plxRecord_arts->f('date')),$row);
                # On gen�re notre ligne
                echo '<li>'.$row.'</li>';
            }
        }
    }

	/**
	* M�thode qui affiche le gravatar de la personne
	*
	* @return    stdout
	* @author    Anthony T.
	**/
    
	function Gravatar($size = 32){
		$email = $this->plxMotor->plxRecord_arts->f('mail');
        $default = $this->plxMotor->racine.'themes/'.$this->plxMotor->style.'/gravatar.jpg';
        $grav_url = "http://www.gravatar.com/avatar/".md5($email)."?d=".urlencode($default)."&amp;s=".$size;
        echo $grav_url;
	}
}