<?php if(!defined('PLX_ROOT')) exit; ?>
			<div class="right" id="sidebar_outer">
				<div id="sidebar">
					<div class="box">
						<div class="box_title">Cat&eacute;gories</div>
						<div class="box_content">
							<ul>
								<?php $plxShow->catList('','#cat_name (#art_nb)'); ?>
							</ul>
						</div>
					</div>
					<div class="box">
						<div class="box_title">Syndication</div>
						<div class="box_content">
							<ul>
								<li><?php $plxShow->artFeed('atom'); ?></li>
								<li><?php $plxShow->comFeed('atom'); ?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="clearer">&nbsp;</div>
		</div>
		<div id="dashboard">
			<div id="dashboard_inner">
				<div class="col3 left">
					<div class="col3_content">
						<div class="col_title">Derniers commentaires</div>
						<ul>
							<?php $plxPlugin->lastComList('<a href="#com_url">#com_author</a> : #com_content(60)', 3); ?>
						</ul>
					</div>
				</div>
				<div class="col3mid left">
					<div class="col3_content">
						<div class="col_title">Derniers articles</div>
						<ul>
							<?php $plxPlugin->lastArtList(); ?>
						</ul>
					</div>
				</div>
				<div class="col3 right">
					<div class="col3_content">
						<div class="col_title">Liens</div>
						<ul>
							<li><a href="http://pluxml.org/">Pluxml</a></li>
							<li><a href="http://ressources.pluxml.org/">Ressources Pluxml</a></li>
							<li><a href="http://wiki.pluxml.org/">Wiki Pluxml</a></li>
							<li><a href="http://forum.pluxml.org/">Forum Pluxml</a></li>
						</ul>
					</div>
				</div>
				<div class="clearer">&nbsp;</div>
			</div>
		</div>