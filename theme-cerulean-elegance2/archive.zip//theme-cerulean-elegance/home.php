<?php include('header.php'); # On insere le header ?>
		<div id="main">
			<div class="left" id="content_outer">
				<div id="content">
					<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
					<div class="post">
						<div class="post_title"><h2><?php $plxShow->artTitle('link'); ?></h2></div>
						<div class="post_date">Post&eacute; le <?php $plxShow->artDate(); ?> &agrave; <?php $plxShow->artHour(); ?> par <?php $plxShow->artAuthor(); ?></div>
						<div class="post_body">
							<?php $plxShow->artChapo(); ?>
						</div>
						<div class="post_meta">
							<?php $plxShow->artNbCom('link'); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?>
						</div>
					</div>
					<?php endwhile; # Fin de la boucle sur les articles ?>
					<div style="text-align : center;"><?php $plxShow->pagination(); ?></div>
				</div>
			</div>
<?php include('sidebar.php'); # On insere la sidebar ?>
<?php include('footer.php'); # On insere le footer ?>