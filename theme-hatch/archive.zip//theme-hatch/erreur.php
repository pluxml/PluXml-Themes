<?php include(dirname(__FILE__).'/header.php'); ?>
	<div id="main"class="archive">
        <div id="content">
			<?php include(dirname(__FILE__).'/sidebar.php'); ?>
            <div class="hfeed" style="max-width: 640px;">
				<?php $plxShow->lang('ERROR'); ?>
            </div>
        </div>
    </div>
<?php include(dirname(__FILE__).'/footer.php'); ?> 

