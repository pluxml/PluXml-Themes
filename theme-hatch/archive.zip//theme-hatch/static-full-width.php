<?php include(dirname(__FILE__) . '/header.php'); ?>

<div id="main">
	<div id="content">
		<div class="hfeed">
			<div class="hentry page publish post-1 odd author-admin">
				<div class="entry-content">
					<h1 class='page-title'><?php $plxShow->staticTitle(); ?></h1>
					<?php $plxShow->staticContent(); ?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>

