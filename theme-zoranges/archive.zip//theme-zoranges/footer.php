<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute;  par <a href="http://pluxml.org">Pluxml</a> | <a href="http://randal.hebfree.org">Randal</a> | <a href="http://fuzzi-wuzzi.deviantart.com/art/Orange-Emote-Pack-149713581">Fuzzi-Wuzzi</a> | <a href="http://solenero73.deviantart.com/art/Some-orange-please-75020431">Solenero73</a></p>
	<p class="right"><a href="core/admin/">Administration</a> | <a href="#top" title="">Haut</a></p>
</div>
</body>
</html>
