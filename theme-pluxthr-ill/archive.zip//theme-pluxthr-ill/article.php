<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
	<div id="content">
		<h2 class="title"><?php $plxShow->artTitle(''); ?></h2>
		<p class="postinfo"><?php $plxShow->artDate('le #num_day-#num_month-#num_year(4)'); ?> | <?php $plxShow->artCat(); ?> | <span><?php $plxShow->artNbCom(); ?></span></p>
		<div class="post"><?php $plxShow->artContent(); ?></div>
		<?php include(dirname(__FILE__).'/commentaires.php'); # On insere la sidebar ?>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
	<div class="clearer"></div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
