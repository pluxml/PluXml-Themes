<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div class="item-1">
		<h3>Cat&eacute;gories</h3>
		<ul><?php $plxShow->catList('','<li id="#cat_id"><a href="#cat_url" class="#cat_status" title="#cat_name">#cat_name</a></li>'); ?></ul>
	</div>
		<p class="separator">&diams;&diams;&diams;&diams;&diams;&diams;</p>
	<div class="item-2">
		<h3>Derniers articles</h3>
		<ul><?php $plxShow->lastArtList('<li><a href="#art_url" class="#art_status" title="#art_title">#art_title</a></li>'); ?></ul>
	</div>
		<p class="separator">&diams;&diams;&diams;&diams;&diams;&diams;</p>
	<div class="item-3">
		<h3>Derniers commentaires</h3>
		<ul class="item3">
			<?php $plxShow->lastComList('<li><span class="com_author"<a href="#com_url">#com_author a dit :</a></span> #com_content(34)</li>'); ?>
		</ul>
	</div>
		<p class="separator">&diams;&diams;&diams;&diams;&diams;&diams;</p>
	<div class="item-4">
		<h3>Abonnements RSS</h3>
		<ul>
			<li><a href="./feed.php?atom" title="Fil Atom des articles">Fil des Articles</a></li>
			<li><a href="./feed.php?atom/commentaires" title="Fil Atom des commentaires">Fil des Commentaires</a></li>
		</ul>
		<div class="clearer"></div>
	</div>
		<p class="separator">&diams;&diams;&diams;&diams;&diams;&diams;</p>
	<div class="item-5">
		<h3>Cr&eacute;dits</h3>
		<ul class="poweredby">
			<li>Propuls&eacute; par <span class="creditlink"><a href="http://pluxml.org" title="Blog ou CMS sans base de données">PluXml</a></span></li>
			<li>Th&egrave;me par <span class="creditlink"><a href="http://leloupetlechien.fr">Gzyg</a></span></li>
			<li>inspir&eacute; par <span class="creditlink"><a href="http://www.csszengarden.com/?cssfile=/200/200.css&amp;page=1">Icicle Outback</a></span></li>
			<li>Valide <span class="creditlink"><a href="">xhtml</a></span> &amp; <span class="creditlink"><a href="">css</a></span></li>
			<li>&nbsp;</li>
			<li>!!&nbsp;Non test&eacute; sur IE&nbsp;!!</li>
			<li><span class="creditjoke">(but did someone still use it&nbsp;?)</span></li>
		</ul>
	</div>
		<p class="separator">&diams;&diams;&diams;&diams;&diams;&diams;</p>
</div>
<div class="clearer"></div>