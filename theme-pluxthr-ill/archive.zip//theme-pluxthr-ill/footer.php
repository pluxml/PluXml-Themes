<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
		<p id="credits"><span class="bad">&diams;</span> th&egrave;me <span class="pluxthrill">pluxthr'ill</span> par <a href="http://leloupetlechien.fr">Gzyg</a> pour <a href="http://pluxml.org">PluXml</a> <span class="bad">&diams;</span>  bas&eacute; sur le splendide <!-- ALERTE : NE PAS RETIRER CE QUI SUIT !! (vous pouvez néanmoins y appliquer vos propres styles css --><a href="http://www.csszengarden.com/?cssfile=/200/200.css&amp;page=1">Icicle Outback</a> de <a href="http://www.timovirtanen.com/">Timo Virtanen</a><!-- FIN D'ALERTE --> &nbsp;&nbsp;&nbsp;&nbsp;<span class="bad">&diams;&diams;&diams;&diams;&diams;&diams;</span>&nbsp;&nbsp;&nbsp;&nbsp; Retour <a href="#top">haut</a> de page <span class="bad">&diams;</span></p>
		<!-- FOR ENGLISH SPEAKERS : please, DO NOT REMOVE these two links : 
		    <a href="http://www.csszengarden.com/?cssfile=/200/200.css&amp;page=1>Icicle Outback</a>
		    <a href="http://www.timovirtanen.com/">Timo Virtanen</a>
		    since this is the wish of the author (Timo Virtanen) ; of course, you can give'em your own style -->
</div>
</body>
</html>