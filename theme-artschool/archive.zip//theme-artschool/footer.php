<?php if (!defined('PLX_ROOT')) exit; ?>

            <!--==============================footer=================================-->
            <footer>
                <p>© PluXml</p>
                <p>
					Gabarit par 
					<a rel="nofollow" href="http://www.zerotheme.com/" target="_blank" class="link">
						Zerotheme
					</a> | 
					<a class="link" rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" >
						<?php $plxShow->lang('ADMINISTRATION') ?>
					</a>
				</p>
            </footer>	  
          </div></div>
        </div>
    </section>    
   </div>      
</body>
</html>