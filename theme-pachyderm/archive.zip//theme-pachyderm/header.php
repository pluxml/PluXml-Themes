<?php if (!defined('PLX_ROOT')) exit; ?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<title><?php $plxShow->pageTitle(); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<!--[if lt IE 9]>
<script src="<?php $plxShow->template(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->

	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/pachyderm-demo.calobeedoodles.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='pachyderm-style-css'  href='<?php $plxShow->template(); ?>/css/style.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='pachyderm-gudea-css'  href='http://fonts.googleapis.com/css?family=Gudea%3A400%2C400italic%2C700&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='pachyderm-berkshire-swash-css'  href='http://fonts.googleapis.com/css?family=Berkshire+Swash&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='pachyderm-poiret-one-css'  href='http://fonts.googleapis.com/css?family=Poiret+One&#038;subset=latin%2Clatin-ext%2Ccyrillic&#038;ver=4.3.1' type='text/css' media='all' />
<meta name="generator" content="WordPress 4.3.1" />
<!-- Currently running on backup Linode instance. --><style type="text/css" id="custom-background-css">
body.custom-background { background-image: url('<?php $plxShow->template(); ?>/img/background.png'); 
background-repeat: repeat; background-position: top left; background-attachment: scroll; }
</style>
</head>

<body class="home blog custom-background">
<div id="page" class="hfeed site">
		<header id="masthead" class="site-header" role="banner">
					<a href="http://pachyderm-demo.calobeedoodles.com/" title="Pachyderm" rel="home">
				<img src="<?php $plxShow->template(); ?>/img/zoo.png" width="790" height="200" alt="" />
			</a>
				<hgroup>
			<h1 class="site-title"><?php $plxShow->mainTitle('link'); ?></h1>
			<h2 class="site-description"><?php $plxShow->subTitle(); ?></h2>
		</hgroup>

		<nav id="site-navigation" class="navigation-main" role="navigation">
			<h1 class="menu-toggle">Menu</h1>
			<div class="screen-reader-text skip-link"><a href="#content" title="Skip to content">Skip to content</a></div>

			<div class="menu-navigation-container">
			
			<ul id="menu-navigation" class="menu">
			
			<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status menu-item menu-item-type-custom menu-item-object-custom" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
				<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status menu-item menu-item-type-custom menu-item-object-custom" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
			</ul>
			</div>	
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

