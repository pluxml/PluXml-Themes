<?php include('header.php'); ?>
	<div id="content">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
			<div class="post">
				<span class="gris"><?php $plxShow->artDate(); ?>&nbsp;&nbsp;|&nbsp;&nbsp;Cat&eacute;gorie <em><?php $plxShow->artCat(); ?></em></span>
				<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
				<div class="clear">&nbsp;</div>
				<?php $plxShow->artChapo(); ?>
				<p class="comment_nb"><?php $plxShow->artNbCom(); ?></p>
				<div class="clear"></div>
			</div>
		<?php endwhile; ?>
		<?php ?>
		<p id="pagination"><?php $plxShow->pagination(); ?></p>
	</div>
	<?php include('sidebar.php'); ?>
</div>
<?php include('footer.php'); ?>
