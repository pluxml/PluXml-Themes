<?php include('header.php'); ?>

	<div id="content">
		<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
		<?php $plxShow->staticContent(); ?>
	</div>
	
	<?php include('sidebar.php'); ?>
</div>
<?php include('footer.php'); ?>
