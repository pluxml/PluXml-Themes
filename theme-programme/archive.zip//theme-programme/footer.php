<?php if(!defined('PLX_ROOT')) exit; ?>
<div style="clear: both;">&nbsp;</div>
<div id="footer">
	<p>&copy; <?php $plxShow->mainTitle('link'); ?> - 
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a> 
		en <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?>
		- Design by <a href="http://www.freecsstemplates.org/"> CSS Templates</a> - Adapté par <a href="http://www.favrecreation.fr">FavreCréation</a>
	</p>
	<p>
	<a href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="Administration">Administration</a> - <a href="<?php echo $plxShow->urlRewrite('#top') ?>" title="Remonter en haut de page">Haut de page</a>
	</p>
	<p>
	
	</p>
</div>
</body>
</html>
