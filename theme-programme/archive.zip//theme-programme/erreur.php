<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>

<div id="page">
	<div id="page-bgtop">
				<div id="page-bgbtm">		
						<div id="content">
								<div class="post">
									<p class="center"><?php $plxShow->erreurMessage(); ?></p>
									<p class="center"><a href="./" title="Accueil du site">Retour page d'accueil</a></p>
								</div>
						</div>
						<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
				
			</div>
		</div>
	</div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>