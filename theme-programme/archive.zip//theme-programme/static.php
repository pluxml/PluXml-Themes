<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
	<div id="page">
		<div id="page-bgtop">
					<div id="page-bgbtm">
							<div id="content">
								<div class="post">
									<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
									<div class="entry"><?php $plxShow->staticContent(); ?></div>
								
								</div>
							</div>
		<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
			</div>
		</div>
	</div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
