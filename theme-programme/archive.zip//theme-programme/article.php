<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
	<div id="page-bgtop">
					<div id="page-bgbtm">
							<div id="content">
								<div class="post">
									<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
									<div class="entry"><?php $plxShow->artChapo(); ?></div>
									<div class="byline">
										<p class="meta">R&eacute;dig&eacute; par <?php $plxShow->artAuthor() ?> le <?php $plxShow->artDate('#day #num_day #month, #num_year(4)'); ?> <br /> Class&eacute; dans : <?php $plxShow->artCat(); ?></p>
										<p class="links">Mots cl&eacute;s : <?php $plxShow->artTags(); ?> <br /> <?php $plxShow->artNbCom(); ?></p>
										<p><?php $plxShow->artAuthorInfos('<div class="infos">#art_authorinfos</div>'); ?></p>
									</div>
								</div>
									
									<?php include(dirname(__FILE__).'/commentaires.php'); # On insere les commentaires ?>

								</div>
								<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
	
			</div>
		</div>
	</div>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
