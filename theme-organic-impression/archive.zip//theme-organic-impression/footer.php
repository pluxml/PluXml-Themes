<?php if(!defined('PLX_ROOT')) exit; ?>

<div id="footer_outside">
<div id="footer_inside">

	<p>
		<small>&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> en <?php $plxShow->chrono(); ?> | <a href="#top" title="">Haut de page</a> | Template courtesy of <a title="Designs by Darren - Fress CSS Website Templates" href="http://www.designsbydarren.com">DesignsByDarren</a> &middot; Adapt&eacute; pour <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> par Gaius B. &middot; <a title="Valid XHTML 1.0 Strict" href="http://validator.w3.org/check?uri=referer">Valid XHTML 1.0 Strict</a></small>
	</p>

</div> <!-- footer_inside -->
<div class="clear"></div>
</div> <!-- footer_outside -->

</body>
</html>