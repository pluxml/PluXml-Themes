<?php if (!defined('PLX_ROOT')) exit; ?>


<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
    <head>
		<meta charset="<?php $plxShow->charset('min'); ?>">
		<title><?php $plxShow->pageTitle(); ?></title>
		<?php $plxShow->meta('description') ?>
		<?php $plxShow->meta('keywords') ?>
		<?php $plxShow->meta('author') ?>
		<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="http://gmpg.org/xfn/11">
		<link rel='dns-prefetch' href='//fonts.googleapis.com' />
		<link rel='dns-prefetch' href='//s.w.org' />
		<link rel="stylesheet" href="<?php //$plxShow->template(); ?>/css/plucss.css" media="screen"/>
		<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/theme.css" media="screen"/>
		<link rel='stylesheet' id='smartcat_team_default_style-css'  href='<?php $plxShow->template(); ?>/css/sc_our_team.css?ver=2.5.0' type='text/css' media='all' />

		<link rel='stylesheet' id='woocommerce-layout-css'  href='<?php $plxShow->template(); ?>/css/woocommerce-layout.css?ver=2.5.5' type='text/css' media='all' />
		<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php $plxShow->template(); ?>/css/woocommerce-smallscreen.css?ver=2.5.5' type='text/css' media='only screen and (max-width: 768px)' />
		<link rel='stylesheet' id='woocommerce-general-css'  href='<?php $plxShow->template(); ?>/css/woocommerce.css?ver=2.5.5' type='text/css' media='all' />

		<link rel='stylesheet' id='athena-style-css'  href='<?php $plxShow->template(); ?>/css/athena-style.css?ver=4.7.3' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-font-general-css'  href='//fonts.googleapis.com/css?family=Raleway%3A400%2C300%2C500%2C700&#038;ver=20130115' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-theme-general-css'  href='//fonts.googleapis.com/css?family=Open+Sans&#038;ver=20130115' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-bootstrap-css'  href='<?php $plxShow->template(); ?>/css/bootstrap.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-bootstrap-theme-css'  href='<?php $plxShow->template(); ?>/css/bootstrap-theme.min.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-fontawesome-css'  href='<?php $plxShow->template(); ?>/css/font-awesome.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-main-style-css'  href='<?php $plxShow->template(); ?>/css/athena-main-style.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-camera-style-css'  href='<?php $plxShow->template(); ?>/css/camera.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-animations-css'  href='<?php $plxShow->template(); ?>/css/animate.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-carousel-css'  href='<?php $plxShow->template(); ?>/css/owl.carousel.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-slicknav-css'  href='<?php $plxShow->template(); ?>/css/slicknav.min.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-unite-css'  href='<?php $plxShow->template(); ?>/css/unite-gallery.css?ver=1.0.6' type='text/css' media='all' />
		<link rel='stylesheet' id='athena-template-css'  href='<?php $plxShow->template(); ?>/css/green.css?ver=1.0.6' type='text/css' media='all' />

		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.js?ver=1.12.4'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery-migrate.min.js?ver=1.4.1'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/hc.js?ver=2.5.0'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/carousel.js?ver=2.5.0'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/sc_our_team.js?ver=2.5.0'></script>
		<script type='text/javascript'>
		/* <![CDATA[ */
		var theme_object = {"ajax_url":"<?php $plxShow->template(); ?>\/js\/admin-ajax.php","theme_name":"athena"};
		/* ]]> */
		</script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/core.min.js?ver=1.11.4'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/imagesloaded.min.js?ver=3.2.0'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/masonry.min.js?ver=3.3.2'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.masonry.min.js?ver=3.1.2b'></script>
		<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/script.js?ver=1.0.6'></script>
        <style>
            
            #sc_our_team a,
            .sc_our_team_lightbox .name,
            .sc_personal_quote span.sc_team_icon-quote-left{ color: #36B3A8; }
            .grid#sc_our_team .sc_team_member .sc_team_member_name,
            .grid#sc_our_team .sc_team_member .sc_team_member_jobtitle,
            .grid_circles#sc_our_team .sc_team_member .sc_team_member_jobtitle,
            .grid_circles#sc_our_team .sc_team_member .sc_team_member_name,
            #sc_our_team_lightbox .progress,
            .sc_our_team_panel .sc-right-panel .sc-name,
            #sc_our_team .sc_team_member .icons span,
            .sc_our_team_panel .sc-right-panel .sc-skills .progress,
            #sc_our_team_lightbox .sc_our_team_lightbox .social span,
            .sc_team_single_member .sc_team_single_skills .progress{ background: #36B3A8;}
            .stacked#sc_our_team .smartcat_team_member{ border-color: #36B3A8;}
            /*.grid#sc_our_team .sc_team_member_inner{ height: px; }*/
            .grid#sc_our_team .sc_team_member{ padding: 5px;}
            #sc_our_team_lightbox .sc_our_team_lightbox{ margin-top: px }

			@font-face {
			  font-family: 'FontAwesome';
			  src: url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.eot?v=4.4.0');
			  src: url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.eot?#iefix&v=4.4.0') format('embedded-opentype'), 
			  url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.woff2?v=4.4.0') format('woff2'), 
			  url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.woff?v=4.4.0') format('woff'), 
			  url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.ttf?v=4.4.0') format('truetype'), 
			  url('<?php $plxShow->template(); ?>/fonts/fontawesome-webfont.svg?v=4.4.0#fontawesomeregular') format('svg');
			  font-weight: normal;
			  font-style: normal;
			}

            

/* ---------- FORM ---------- */

form .col {
	margin-bottom: 1.5rem;
}
form.inline-form button,
form.inline-form input,
form.inline-form label,
form.inline-form select,
form.inline-form textarea {
	display: inline-block;
	width: auto;
}
form .col.label-centered {
	margin-bottom: 0;
}
form .label-centered label {
	padding-top: .3rem;
}
button,
input,
select,
textarea {
	border: 1px solid #bbb;
	border-radius: .3rem;
	transition-duration: .2s;
}
input:focus,
select:focus,
textarea:focus {
	border: 1px solid #258fd6;
	transition-duration: .2s;
}
[type="file"] {
	border: none;
}
button,
input[type="button"],
input[type="reset"],
input[type="submit"] {
	background-color: #777;
	color: #fff;
	transition-duration: .2s;
}
button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover {
	background-color: #555;
	transition-duration: .2s;
}
button[disabled],
input[disabled],
select[disabled],
textarea[disabled],
button[disabled]:hover,
input[disabled]:hover,
select[disabled]:hover,
textarea[disabled]:hover {
	background-color: #ddd;
	color: #aaa;
}
button.blue,
input[type="button"].blue,
input[type="reset"].blue,
input[type="submit"].blue {
	background-color: #258fd6;
	color: #eee;
}
button.blue:hover,
input[type="button"].blue:hover,
input[type="reset"].blue:hover,
input[type="submit"].blue:hover {
	background-color: #1f77b1;
}
button.green,
input[type="button"].green,
input[type="reset"].green,
input[type="submit"].green {
	background-color: #239c56;
	color: #eee;
}
button.green:hover,
input[type="button"].green:hover,
input[type="reset"].green:hover,
input[type="submit"].green:hover {
	background-color: #1c7943;
}
button.orange,
input[type="button"].orange,
input[type="reset"].orange,
input[type="submit"].orange {
	background-color: #da7418;
	color: #eee;
}
button.orange:hover,
input[type="button"].orange:hover,
input[type="reset"].orange:hover,
input[type="submit"].orange:hover {
	background-color: #b46014;
}
button.red,
input[type="button"].red,
input[type="reset"].red,
input[type="submit"].red {
	background-color: #e43d29;
	color: #eee;
}
button.red:hover,
input[type="button"].red:hover,
input[type="reset"].red:hover,
input[type="submit"].red:hover {
	background-color: #bc2818;
}

.level-0 {
	margin-left: 0;
}
.level-1 {
	margin-left: 5rem;
}
.level-2 {
	margin-left: 10rem
}
.level-3 {
	margin-left: 15rem;
}
.level-4 {
	margin-left: 20rem;
}
.level-5,
.level-max {
	margin-left: 25rem;
}
@media (max-width: 768px) {
  .comment { background-image: none; padding-left: 0; }
  .level-1 { margin-left: 1rem; }
  .level-2 { margin-left: 2rem; }
  .level-3 { margin-left: 3rem; }
  .level-4 { margin-left: 4rem; }
  .level-5, .level-max { margin-left: 5rem; }
}
#id_answer {
	margin-bottom: 1.5rem;
	padding:1.5rem;
	border:1px solid #eee;
	width:100%;
	background:#fafafa;
	display:none;
}
.capcha-letter,
.capcha-word {
	font-weight: bold;
}
.capcha-word {
	background-color: #ddd;
	border-radius: .3rem;
	letter-spacing: .5rem;
	padding: .9rem .7rem;
	transition-duration: .2s;
}
.capcha-word:hover {
	background-color: #666;
	color: #fff;
	transition-duration: .2s;
}


fieldset {
	border: none;
	padding: 0;
}
legend {
	margin-bottom: 1.5rem;
	padding: 0;
}
label {
	display: block;
	padding-bottom: .3rem;
}
button,
input,
select,
textarea {
	font: inherit;
	height: 3rem;
	margin: 0;
	outline: none;
	padding-left: .4rem;
	padding-right: .4rem;
	width: 100%;
}
button,
input {
	overflow: visible;
}
button::-moz-focus-inner,
input::-moz-focus-inner {
	border: 0;
	padding: 0;
}
button,
[type="button"],
[type="reset"],
[type="submit"] {
	border-color: transparent;
	cursor: pointer;
	padding-left: .7rem;
	padding-right: .7rem;
	width: auto;
}
textarea {
	height: auto;
	overflow: auto;
}

</style>

			<script>
				jQuery(document).ready(function ($) {
					function get_height() {
						if ( jQuery( window ).width() < 601 ) {
								return jQuery(window).height();
						} else {
								return jQuery(window).height();
						}
					}
					if( jQuery('#athena-slider').html() ) {
						athena_slider();
					}
					// Jumbotron
					var height = get_height();
					$('.athena-parallax').height( height );
					function athena_slider() {
						var height = get_height();
						jQuery('#athena-slider').camera({
							height: height + 'px',
							loader: "bar",
							overlay: false,
							fx: "random",
							time: "3000",
							pagination: false,
							thumbnails: false,
							transPeriod: 1000,
							overlayer: false,
							playPause: false,
							hover: false,
							navigation : true
						});
					}
					// Gallery
					if( $(".athena-gallery") ) {
						$(".athena-gallery").unitegallery({
							tiles_col_width: 390,
							theme_appearance_order: 'normal',
						});
						$('[data-parallax="scroll"]').parallax();
					}
				});

				jQuery(document).ready( function($) {
				$('.athena-blog-content').imagesLoaded(function () {
					$('.athena-blog-content').masonry({
						itemSelector: '.athena-blog-post',
						gutter: 0,
						transitionDuration: 0,
					}).masonry('reloadItems');
				});
			});
			</script>
			<style type="text/css">

				body{
					font-size: 14px;
					font-family: Open Sans, sans-serif;

				}
				h1,h2,h3,h4,h5,h6,.slide2-header,.slide1-header,.athena-title, .widget-title,.entry-title, .product_title{
					font-family: Raleway, sans-serif;
				}

				ul.athena-nav > li.menu-item a{
					font-size: 14px;
				}
				
				ul.athena-nav a{
					color: rgba(255,255,255,0.8)        }
				
				.site-title{
					font-size: 40pxpx;
				}
				
				#athena-jumbotron h2.header-text{
					color: #ffffff        }

			</style>
    
    		<style type="text/css" id="wp-custom-css">
				/*
				You can add your own CSS here.

				Click the help icon above to learn more.


				@media( min-height: 700px ) {
				#athena-slider, #athena-jumbotron{
					height: 700px !important;
				}
				}
				*/
			</style>
	    </head>

    <body class="home page-template page-template-templates page-template-right-sidebar page-template-templatesright-sidebar-php page page-id-257">
        <div id="athena-search" class="noshow">
            <span class="fa fa-close"></span>
            <div class="row animated slideInDown">
                <span class="fa fa-search"></span>
				<?php	
				# récupération d'une instance de plxMotor
				$plxMotor = plxMotor::getInstance();
				$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
				$searchword = '';
				if(!empty($_POST['searchfield'])) {
					$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
				}
				?>
				<form  role="search" class="search-form" action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>" method="post">
					<label style="display: inline-block;">
						<input type="search" placeholder="Rechercher &hellip;"  class="search-field" value="" />
					</label> 
					<input type="submit"  class="search-submit"  value="<?php echo $plxPlugin->getParam('frmLibButton_'.$plxPlugin->default_lang) ?>" />
				</form>
				
				<!--form role="search" method="get" class="search-form" action="http://athena.smartcatdev.wpengine.com/">
					<label>
						<span class="screen-reader-text">Search for:</span>
						<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
					</label>
					<input type="submit" class="search-submit" value="Search" />
				</form-->
			
            </div>
        </div>
        
		
                
		
		
        <div id="athena-contact" class="noshow">
            <span class="fa fa-close"></span>
            <div class="row animated slideInDown">
					<?php				
					extract($_POST);

					/* 
					BELLonline PHP MAILER SCRIPT v1.5
					Copyright 2006 Gavin Bell 
					http://www.bellonline.co.uk 
					gavin@bellonline.co.uk
					*/

					// changer le courriel ci-dessous pour votre adresse personnelle qui recevra les messages
					$sendto_email = "courriel@serveur.com";

					// Disable email addresses from the same domain as your email from being sent? 
					// This will often reduce spam but will not allow antone to send from anything@yourdomain. 
					$checkdomain = "yes";
					// Language variables
					$lang_title = "Envoyer un courriel";
					$lang_notice = "N'hésitez pas à remplir le formulaire pour nous contacter par courriel.  Tous les champs sont obligatoires.";
					$lang_name = "Votre nom";
					$lang_youremail = "Votre de courriel";
					$lang_subject = "Sujet";
					$lang_message = "Message";
					$lang_confirmation = "Entrez le code de validation";
					$lang_submit = "Envoyer le courriel";
					// Error messages
					$lang_error = "Votre courriel n'a pas été envoyé, les erreurs suivantes sont à corriger:";
					$lang_noname = "Votre nom n'a pas été inscrit";
					$lang_noemail = "Votre courriel n'a pas été inscrit correctement";
//						$lang_nosubject = "You did not enter a subject";
					$lang_nomessage = "Vous devez inclure un message";
					$lang_nocode = "Vous n'avez pas inscrit le code de validation";
					$lang_wrongcode = "Le code de validation entré est erroné.  SVP prendre note que la casse est prise en compte.";
					$lang_invalidemail = "Le courriel que vous avez inscrit ne semble pas valide, SVP vérifier.";
					// Success
					$lang_sent = "Votre message a été envoyé.  Le message suivant a été posté par courriel:";
					// Width of form inputs. Must include unites, e.g px 
					$input_width = "300px";
					// How do you want the title aligned?
					$title_align = "left"; // Can be left, center or right
					// To format the title text. If you are not confident with css then probably best left as it is
					$title_css = "font-weight: bold; font-size: 120%;";
					// Colour of error message
					$error_colour = "red"; // Must use HTML compatible colour
					// You can choose whether to display Powered by BELLonline PHP mailer script at the bottom of the mail form
					// I understand that some peopme might not want to show our link, but we would appreciate it if you could 
					// Possible options are yes or no
					$showlink = "no";
					// Thanks for using the PHP mailer script, I hope you find it useful!
					
				if ($sendto_email == "changeme@example.com") {
					print "N'oubliez pas de changer l'adresse de courriel dans le fichier config.php.  Attention, pas le config.php de PluXml mais bien celui au sous-répertoire /mail";
					exit;
				} 
					
				if (empty ($senders_name)) 	{
					$error = "1";
					$info_error .= $lang_noname . "<br>"; 
				}
				if (empty ($senders_email))	{
					$error = "1";
					$info_error .= $lang_noemail . "<br>";  
				}
				/*if (empty ($mail_subject)) {
					$error = "1";
					$info_error .= $lang_nosubject . "<br>";  
				}
				*/	
				if (empty ($mail_message)) 	{
					$error = "1";
					$info_error .= $lang_nomessage . "<br>";  
				}
				if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,6}$", $senders_email))	{
					$error = "1";
					$info_error .= $lang_invalidemail . "<br>"; 
				}
				if (empty ($security_code))  {
					$error = "1";
					$info_error .= $lang_nocode . "<br>";  
				}
				elseif ($security_code != $randomness)	{
					$error = "1";
					$info_error .= $lang_wrongcode . "<br>";  
				}
				if ($showlink != "no")	{
					$link = "<br><span style=\"font-size: 10px;\">Powered by <a href=\"http://bellonline.co.uk/downloads/php-mailer-script/\" title=\"free PHP mailer script\">BELLonline PHP mailer script</a></span>";
				}
				if ($error == "1") {
					$info_notice = "<span style=\"color: " . $error_colour . "; font-weight: bold;\">" . $lang_error . "</span><br>"; 
					
					if (empty ($submit)) {
						$info_error = "";
						$info_notice = $lang_notice;
					}	

					function Random() {
						$chars = "ABCDEFGHJKLMNPQRSTUVWZYZ23456789";
						srand((double)microtime()*1000000);
						$i = 0;
						$pass = '' ;
						while ($i <= 4) {
							$num = rand() % 32;
							$tmp = substr($chars, $num, 1);
							$pass = $pass . $tmp;
							$i++; 
						} 
						return $pass; 
					}

					$random_code = Random();
					$mail_message = stripslashes($mail_message); ?>
					
					<form  id="athena-contact-form" name="BELLonline_email" method="post" action="">
						<?php echo $info_notice; ?><?php echo $info_error; ?>
						<div class="group">
							<label><?php $plxShow->lang('NAME') ?></label>
							<input name="senders_name" type="text"  class="control name" id="senders_name"  value="<?php echo $senders_name; ?>" maxlength="32">
						</div>
						<div class="group">
							<label><?php $plxShow->lang('EMAIL') ?></label>
							<input name="senders_email" type="text"  class="control email" id="senders_email"  value="<?php echo $senders_email; ?>" maxlength="64">
						</div>
						<?php //echo $lang_subject; ?>
						<!--br/>
						<input name="mail_subject" type="text" class="mailform_input" id="mail_subject" style="width: <?php //echo $input_width; ?>;" value="<?php //echo $mail_subject; ?>" maxlength="64"-->
						<div class="group">
							<label><?php $plxShow->lang('COMMENT') ?></label>
							<textarea name="mail_message" cols="36" rows="5" class="control message"><?php echo $mail_message; ?></textarea>
						</div>
						<div class="group">
							<?php echo $lang_confirmation; ?>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $random_code; ?></b>
							<input name="security_code" type="text" id="security_code" size="5"> 
							<input name="randomness" type="hidden" id="randomness" value="<?php echo $random_code; ?>" >
						</div>
						<input type="submit" class="athena-button" value="<?php echo $lang_submit; ?>">
					</form>
				<?php 	
				}else{
					if ($checkdomain == "yes") 	{
						$sender_domain = substr($senders_email, (strpos($senders_email, '@')) +1);
						$recipient_domain = substr($sendto_email, (strpos($sendto_email, '@')) +1);
						if ($sender_domain == $recipient_domain){
							print "Désolé, il ne sera pas possible d'envoyer votre message de ce domaine ($sender_domain)";
							exit;
						}		
					}
					$info_notice = $lang_sent;
					$mail_message = stripslashes($mail_message);
					$senders_email = preg_replace("/[^a-zA-Z0-9s.@-_]/", "-", $senders_email);
					$senders_name = preg_replace("/[^a-zA-Z0-9s]/", " ", $senders_name);
					$headers = "From: $senders_name <$senders_email> \r\n";
					$headers .= "X-Mailer: BELLonline.co.uk PHP mailer \r\n";
				//	mail($sendto_email, $mail_subject, $mail_message, $headers); 
					mail($sendto_email, "Un message de votre site web", $mail_message, $headers); 
					?>
					
					<?php echo $info_notice; ?>
					<br/>
					<br/>
					<?php echo $lang_name.': '; ?>
					<br/>
					<?php echo $senders_name; ?>
					<br/>
					<br/>
					<?php echo $lang_youremail.': '; ?>
					<br/>
					<?php echo $senders_email; ?>
					<?php //echo $lang_subject; ?>
					<?php// echo $mail_subject; ?>
					<br/>
					<br/>
					<?php echo $lang_message.': '; ?>
					<br/>
					<?php echo $mail_message; ?>
					<br/>
				<?php 
				}
//				print $link;
				?>
				
				<br/>
				<br/>
				<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://bellonline.co.uk/downloads/php-mailer-script/" target="_blank" title="BELLonline PHP mailer">BELLonline PHP mailer</a>
               
            </div>
            
        </div>
        
        <div id="page" class="hfeed site">
            <header id="masthead" class="site-header" role="banner">
                <div id="athena-header" class="frontpage">
                    <div class="header-inner">
                        <div class="row">
                            <div class="athena-header-menu">
                                <div class="athena-mobile-cart">
                                    <a class="athena-cart" href=""><span class="fa fa-shopping-cart"></span> <span class="amount">&pound;0.00</span></a>
                                </div>
                                <nav id="site-navigation" class="main-navigation" role="navigation">
                                    <div class="menu-top-menu-2-container">
									<ul id="primary-menu" class="athena-nav">
										<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="menu-item #static_class #static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
										<?php $plxShow->pageBlog('<li class="menu-item #page_class #page_status" id="#page_id"><a href="#page_url" title="#page_name">#page_name</a></li>'); ?>
										<li class="menu-item"><a class="athena-search" href="#search" role="button" data-toggle="modal"><span class="fa fa-search"></span></a></li>
										<li class="menu-item"><a class="athena-contact" href="#contact" role="button" data-toggle="modal"><span class="fa fa-envelope"></span></a></li>
 										<!--li><a class="athena-cart" href=""><span class="fa fa-shopping-cart"></span> <span class="amount">&pound;0.00</span></a></li-->
									</ul>
								</div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </header>


