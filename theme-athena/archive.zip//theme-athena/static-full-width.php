<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">

                <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="http://athena.smartcatdev.wpengine.com/wp-content/uploads/sites/3/2016/02/foggy-sunday-1170158_640.jpg">

                    <header class="entry-header">
                        <h1 class="entry-title">
							<?php $plxShow->staticTitle(); ?>
						</h1>
					</header>

                </div>
				
				<div class="row">

					<div class="col-sm-12">

                        <article id="post-1" class="post-1 post type-post status-publish format-standard has-post-thumbnail hentry category-smartcat category-wordpress-themes tag-responsive-themes tag-setup tag-wordpress">
                            <header class="entry-header">
                                <h1 class="entry-title"><?php $plxShow->staticTitle(); ?></h1>
                            </header>

                            <div class="entry-content">

								<?php $plxShow->staticContent(); ?>

                            </div>
                            <!-- .entry-content -->

                        </article>
                        <!-- #post-## -->
                   
					</div>


				</div>


            </main>
        </div>
    </div>
        <!-- #primary -->

   
    <?php include(dirname(__FILE__).'/footer.php'); ?>
