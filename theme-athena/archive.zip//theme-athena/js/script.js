jQuery(document).ready(function ($) {
    
    $('.collapse').collapse();
    
    var athena_carousel = $(".athena-testimonials");
	var athena_products = $(".woocommerce.widget_products .product_list_widget");
	
    athena_carousel.owlCarousel({
        
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem:true,
        autoPlay : true

    });    
	
    athena_products.owlCarousel({
        items : 4,
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem:false,
        autoPlay : true,

    }); 

    $('#athena-featured .featured-box').click(function () {

        if( $(this).attr('data-target') && $(this).attr('data-target') != '#' ) {
        
            if( $(this).attr('data-window') == 'same' ) {
                window.location.href = $(this).attr('data-target');
            } else {
                window.open( $(this).attr('data-target'), '_blank');
            }
            
        }
        

    });


    $('.featured-box').hover(function () {

        $('.athena-icon', this).stop(true, false).animate({
            top: '-7px'

        }, 300);
        $('.athena-desc', this).stop(true, false).animate({
            top: '7px'

        }, 300);

        $('.athena-title', this).stop(true, false).animate({
            'letter-spacing': '1.5px'

        }, 300);

    }, function () {
        $('.athena-icon', this).stop(true, false).animate({
            top: '0px'

        }, 300);
        $('.athena-desc', this).stop(true, false).animate({
            top: '0px'

        }, 300);
        $('.athena-title', this).stop(true, false).animate({
            'letter-spacing': '1px'

        }, 300);
    });

    $('#primary-menu').slicknav({
        prependTo: $('.athena-header-menu'),
        label: '',
        allowParentLinks: true,
    });

    $('.athena-search, #athena-search .fa.fa-close').click(function () {

        $('#athena-search').fadeToggle(500)

    });

    $('.athena-contact, #athena-contact .fa.fa-close').click(function () {

        $('#athena-contact').fadeToggle(500)

    });

    // Homepage Overlay
    $('#athena-overlay-trigger .fa').click(function () {

        var selector = $('#athena-overlay-trigger');

        if (selector.hasClass('open')) {

            $('.overlay-widget').hide();
            selector.removeClass('open animated slideInUp');

        } else {

            selector.addClass('open animated slideInUp');
            $('.overlay-widget').fadeIn(330);
        }

    });

    // scroll to top trigger
    $('.scroll-top').click(function () {
        $("html, body").animate({scrollTop: 0}, 1000);
        return false;
    });

    // scroll to top trigger
    $('.scroll-down').click(function () {

        $("html, body").animate({
            scrollTop: ($(window).height() - 85)
        }, 1000);

        return false;

    });



    // Parallax
    $(window).scroll(function () {

        var s = $(window).scrollTop();

        $('.parallax').css({top: (s / 3.)});

        if (s > $(window).height()) {

            $('#athena-header.frontpage').addClass('sticky animated slideInDown');

        } else {
            $('#athena-header.frontpage').removeClass('sticky animated slideInDown');
        }

    })

    // ------------
    var athenaWow = new WOW({
        boxClass: 'reveal',
        animateClass: 'animated',
        offset: 150

    });

    athenaWow.init();
    
    
    function athenaValidateEmail(email) {
        var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
    
    // -----------
    // Contact Form
    $('#athena-contact-form').submit( function (e) {
       
        e.preventDefault();
        
        $('.mail-sent,.mail-not-sent').hide();
       
        var form = $(this);
        var name = $('.name', form ).val();
        var email = $('.email', form ).val();
        var message = $('.message', form ).val();
        var url = form.attr('action');
        
        if( name.length < 2 ) {
            alert( 'Please enter a name' );
            return false;
        }
        
        if( message.length < 2 ) {
            alert( 'Please enter a message' );
            return false;
        }
        
        if( ! athenaValidateEmail( email ) ) {
            alert( 'Please enter a valid email address' );
            return false;
        }
        
        var data = {
            
            action : 'athena_send_message',
            name : name,
            email : email,
            message : message
            
        }
        
        $.post( url, data, function ( response ) {
           
            if( response == 1 ) {
                $('.mail-sent').fadeIn(350);
                form[0].reset();
                
            }else{
                $('.mail-not-sent').fadeIn(350);
            }
            
        });
        
        
    });
    
});
