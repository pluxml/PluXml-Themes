<?php if(!defined('PLX_ROOT')) exit; ?>

<div class="col-sm-3" id="athena-sidebar">
	<div id="secondary" class="widget-area" role="complementary">

		<aside id="text-5" class="widget widget_text">
			<h2 class="widget-title">Right Sidebar</h2>
			<div class="textwidget">This is the Right Sidebar. Athena Pro page templates include left sidebar, right sidebar, both sidebars, and no sidebar options. You can view your options under "Templates" in the menu above.</div>
		</aside>

		<aside id="recent-posts-3" class="widget widget_recent_entries">
			<h2 class="widget-title"><?php $plxShow->lang('CATEGORIES'); ?></h2>
			<ul>
				<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
			</ul>
		</aside>
		
		<aside id="recent-posts-3" class="widget widget_recent_entries">
			<h2 class="widget-title"><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
			<ul>
				<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
			</ul>
		</aside>
	
		<aside id="recent-posts-3" class="widget widget_recent_entries">
			<h2 class="widget-title"><?php $plxShow->lang('LATEST_COMMENTS'); ?></h2>
			<ul>
				<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
			</ul>
		</aside>
	
		<aside id="tag_cloud-2" class="widget widget_tag_cloud">
			<h2 class="widget-title"><?php $plxShow->lang('TAGS'); ?></h2>
			<div class="tagcloud">
				<?php 
				$plxMotor = plxMotor::getInstance();
				$format='<a href="#tag_url" title="#tag_name" style="font-size: #tag_size pt;">#tag_name</a> ';
				$max='20';
				$order='';
				$datetime = date('YmdHi');
				$array=array();
				$alphasort=array();
				# On verifie qu'il y a des tags
				if($plxShow->plxMotor->aTags) {
					# On liste les tags sans cr�er de doublon
					foreach($plxShow->plxMotor->aTags as $idart => $tag) {
						if(isset($plxShow->plxMotor->activeArts[$idart]) AND $tag['date']<=$datetime AND $tag['active']) {
							if($tags = array_map('trim', explode(',', $tag['tags']))) {
								foreach($tags as $tag) {
									if($tag!='') {
										$t = plxUtils::title2url($tag);
										if(!isset($array['_'.$tag])) {
											$array['_'.$tag]=array('name'=>$tag,'url'=>$t,'count'=>1);
										}
										else
											$array['_'.$tag]['count']++;
										if(!in_array($t, $alphasort))
											$alphasort[] = $t; # pour le tri alpha
									}
								}
							}
						}
					}

					# tri des tags
					switch($order) {
						case 'alpha':
							if($alphasort) array_multisort($alphasort, SORT_ASC, $array);
							break;
						case 'random':
							$arr_elem = array();
							$keys = array_keys($array);
							shuffle($keys);
							foreach ($keys as $key) {
								$arr_elem[$key] = $array[$key];
							}
							$array = $arr_elem;
							break;
					}

					# limite sur le nombre de tags � afficher
					if($max!='') $array=array_slice($array, 0, intval($max), true);

				}

				$mode = $plxShow->plxMotor->mode;

				# R�cup�ration de la liste des tags de l'article si on est en mode 'article'
				# pour mettre en �vidence les tags dans la sidebar s'ils sont attach�s � l'article
				$artTags = array();
				if($mode=='article') {
					$artTagList = $plxShow->plxMotor->plxRecord_arts->f('tags');
					if(!empty($artTagList)) {
						$artTags = array_map('trim', explode(',', $artTagList));
					}
				}

				# On affiche la liste
				$size=0;
				foreach($array as $tagname => $tag) {
					$name = str_replace('#tag_id','tag-'.$size++,$format);
					$name = str_replace('#tag_size',($tag['count']>10?'max':($tag['count']*3)),$name);
					$name = str_replace('#tag_count',$tag['count'],$name);
					$name = str_replace('#tag_item',$tag['url'],$name);
					$name = str_replace('#tag_url',$plxShow->plxMotor->urlRewrite('?tag/'.$tag['url']),$name);
					$name = str_replace('#tag_name',plxUtils::strCheck($tag['name']),$name);
					$name = str_replace('#nb_art',$tag['count'],$name);
					if($mode=='article' AND in_array($tag['name'],$artTags))
						$tags = str_replace('#tag_status','active', $name);
					else
						$tags = str_replace('#tag_status',(($mode=='tags' AND $plxShow->plxMotor->cible==$tag['url'])?'active':'noactive'), $name);

					echo $tags;
				}
				?>
			</div>
		</aside>
			
		
		<aside id="calendar-2" class="widget widget_calendar">
			<h2 class="widget-title">Events Calendar</h2>
			<div id="calendar_wrap" class="calendar_wrap">
				<table id="wp-calendar">
					<caption>May 2016</caption>
					<thead>
						<tr>
							<th scope="col" title="Monday">M</th>
							<th scope="col" title="Tuesday">T</th>
							<th scope="col" title="Wednesday">W</th>
							<th scope="col" title="Thursday">T</th>
							<th scope="col" title="Friday">F</th>
							<th scope="col" title="Saturday">S</th>
							<th scope="col" title="Sunday">S</th>
						</tr>
					</thead>

					<tfoot>
						<tr>
							<td colspan="3" id="prev"><a href="http://athena.smartcatdev.wpengine.com/2016/04/">< Apr</a></td>
							<td class="pad">&nbsp;</td>
							<td colspan="3" id="next" class="pad">&nbsp;</td>
						</tr>
					</tfoot>

					<tbody>
						<tr>
							<td colspan="6" class="pad">&nbsp;</td>
							<td><a href="http://athena.smartcatdev.wpengine.com/2016/05/01/" aria-label="Posts published on May 1, 2016">1</a></td>
						</tr>
						<tr>
							<td><a href="http://athena.smartcatdev.wpengine.com/2016/05/02/" aria-label="Posts published on May 2, 2016">2</a></td>
							<td><a href="http://athena.smartcatdev.wpengine.com/2016/05/03/" aria-label="Posts published on May 3, 2016">3</a></td>
							<td>4</td>
							<td>5</td>
							<td>6</td>
							<td>7</td>
							<td>8</td>
						</tr>
						<tr>
							<td>9</td>
							<td>10</td>
							<td>11</td>
							<td>12</td>
							<td>13</td>
							<td>14</td>
							<td>15</td>
						</tr>
						<tr>
							<td>16</td>
							<td>17</td>
							<td>18</td>
							<td>19</td>
							<td>20</td>
							<td>21</td>
							<td>22</td>
						</tr>
						<tr>
							<td>23</td>
							<td>24</td>
							<td>25</td>
							<td>26</td>
							<td>27</td>
							<td>28</td>
							<td>29</td>
						</tr>
						<tr>
							<td>30</td>
							<td>31</td>
							<td class="pad" colspan="5">&nbsp;</td>
						</tr>
					</tbody>
				</table>
			</div>
		</aside>
		<aside id="recent-posts-3" class="widget widget_recent_entries">
			<h2 class="widget-title"><?php $plxShow->lang('ARCHIVES'); ?></h2>
			<ul>
				<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
			</ul>
		</aside>
	</div>
</div>
	<!-- #secondary -->
