<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">
                <div id="athena-jumbotron">
                    <div id="athena-slider" class="hero">
					
                        <?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
                            <div id="slide<?php $plxShow->artId(); ?>" data-src="<?php $plxShow->artThumbnail('#img_url'); ?>">
                                <div class="overlay">
                                    <div class="row">
                                        <div class="col-sm-6 parallax">
                                            <h2 class="header-text animated slideInDown slide1-header"><?php $plxShow->artTitle('link'); ?></h2>
                                            <a href="." class="athena-button primary large animated flipInX slide1_button1 delay3">Boîte un</a>
                                            <a href="." class="athena-button default large animated flipInX  slide1_button2 delay3">Boîte deux</a>
                                        </div>
                                        <div class="col-sm-6"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
						
                    </div>
                    <div id="athena-overlay-trigger">
                        <div class="overlay-widget">
                            <div class="row">
                                <aside id="text-8" class="widget widget_text col-sm-12">
                                    <h2 class="widget-title">Section escamotable</h2>
                                    <div class="textwidget">Section de texte statique superposée qui est affichée par le petit point d'interrogration au bas du carrousel.  Il peut être refermé en appuyant à nouveau sur le même bouton.</div>
                                </aside>
                            </div>
                        </div>
                        <span class="fa fa-question-circle animated rotateIn delay3"></span>
                    </div>
                    <div class="slider-bottom">
                        <div>
                            <span class="fa fa-chevron-down scroll-down animated slideInUp delay-long"></span>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>

                <div id="athena-featured">

					<?php $plxShow->lastArtList('
					
                    <div class="col-sm-4 featured-box featured-box1" data-target="#art_url" data-window="same">
                        <div class="reveal animated fadeInUp reveal">
                            <div class="athena-icon">
                                <span class="fa fa-laptop"></span>
                            </div>
                            <h3 class="athena-title">#art_title</h3>
                            <p class="athena-desc">#art_chapo</p>
                        </div>
                    </div>',1,'1'); ?>

					<?php $plxShow->lastArtList('
                    <div class="col-sm-4 featured-box featured-box2" data-target="#art_url" data-window="same">
                        <div class="reveal animated fadeInUp delay1">
                            <div class="athena-icon">
                                <span class="fa fa-magic"></span>
                            </div>
                            <h3 class="athena-title">#art_title</h3>
                            <p class="athena-desc">#art_chapo</p>
                        </div>
                    </div>',1,'1'); ?>

					<?php $plxShow->lastArtList('
                    <div class="col-sm-4 featured-box featured-box3" data-target="#art_url" data-window="same">
                        <div class="reveal animated fadeInUp delay2">
                            <div class="athena-icon">
                                <span class="fa fa-shopping-cart"></span>
                            </div>
                            <h3 class="athena-title">#art_title</h3>
                            <p class="athena-desc">#art_chapo</p>
                        </div>
                    </div>',1,'1'); ?>

                </div>

                <div class="clear"></div>

				<?php /*
				$images=array()  
				$dire= "data/medias/";
				
				if(count($images)==0){
					$images = glob($dire. '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
					shuffle($images);
				}
				
				$randomImage = array_pop($images);
				*/
				?>
				
                <div id="athena-homepage-widget" data-parallax="scroll" data-image-src="<?php echo $randomImage;?>">
                    <div>
                        <div class="row ">
                            <div class="widget-area reveal animated fadeInUp">
                                <aside id="athena_testimonials_widget-2" class="widget widget_athena_testimonials_widget col-sm-12">
                                    <ul id="athena-testimonials" class="athena-testimonials owl-carousel owl-theme">
										<?php $plxShow->lastArtList('
                                        <li>
                                            <div class="testimonial-content">
                                                <div class="col-xs-12">
                                                    <i class="fa fa-quote-left"></i>#art_chapo</div>
                                                <div class="clear"></div>
                                                <!--<i class="fa fa-quote-right"></i>-->
                                            </div>
                                            <div class="testimonial-author center">
                                                - #art_author -
                                            </div>
                                        </li>',3,'1'); ?>
                                    </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="athena-homepage-b-widget">
                    <div>
                        <div class="row">
                            <div class="widget-area">
                                <aside id="woocommerce_products-3" class="widget woocommerce widget_products col-sm-12">
                                    <h2 class="widget-title">Carrousel de produits</h2>
                                    <ul class="product_list_widget">
										<?php $plxShow->lastArtList('
										<li>
                                            <a href="#art_url" title="#art_title">
                                                <img width="640" height="640" src="#img_url" class="attachment-large size-large wp-post-image" alt="" srcset="#img_url" /> 
												<span class="#art_title">#art_title</span>
                                            </a>
                                            <del><span class="amount">#art_chapo</span></del> 
											<ins><span class="amount">#art_chapo</span></ins>
                                        </li>',4,'1'); ?>
                                    </ul> 
                                </aside>
								
                                <aside id="text-4" class="widget widget_text col-sm-12">
										<?php $plxShow->lastArtList('
                                    <h2 class="widget-title">#art_title</h2>
                                    <div class="textwidget">
										<img src="#img_url" style="position: relative; bottom: -75px" /> 
									</div>',1,'1'); ?>
								</aside>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="athena-homepage-c-widget">
                    <div>
                        <div class="row">
                            <div class="widget-area reveal animated fadeInUp">
                                <aside id="text-2" class="widget widget_text col-sm-12">
                                    <h2 class="widget-title">Trois articles d'une catégorie</h2>
                                    <div class="textwidget">
                                        <p>Petit texte statique qui explique la catégorie ou quelque chose comme ça.  L'étoile est un flag optionnel qui pourrait être contrôlé, il a été mis sur toutes les images par défaut pour ne pas oublier son existence.</p>
                                    </div>
                                </aside>
                                <?php $plxShow->lastArtList('
								<div class="col-sm-4 athena-pricing-table">
                                    <div class="inner">
                                        <span class="special"><span class="fa fa-star"></span></span>
                                        <h2 class="title">#art_title</h2>
                                        <div class="diviver"><span></span></div>
                                        <div class="price">#art_chapo</div>
                                        <!--div class="subtitle">Monthly</div-->
                                        <div class="description">
											#art_content
										</div>
                                        <div class="action">
                                            <a href="#art_url" class="athena-button primary">En savoir plus</a>
                                        </div>
                                    </div>
                                </div>',3,'1'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="athena-homepage-d-widget">
                    <div>
                        <div class="row">
                            <div class="widget-area reveal animated fadeInUp">
                                <aside id="text-3" class="widget widget_text col-sm-12">
                                    <h2 class="widget-title">Notre équipe</h2>
                                    <div class="textwidget">
                                        <p>Petit texte statique qui présente le personnel</p>
										<div id="sc_our_team" class="grid sc-col3">
                                            <div class="clear"></div>
												<?php $plxShow->lastArtList('
												<div itemscope itemtype="http://schema.org/Person" class="sc_team_member">
												<div class="sc_team_member_inner">
												<img width="300" height="300" src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=300&h=300&crop-to-fit" class="attachment-medium size-medium wp-post-image" alt="" srcset="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=300&h=300&crop-to-fit" />
												<div itemprop="name" class="sc_team_member_name">
												<a href="#art_url" rel="bookmark">#art_title</a>
												</div>
												<!--div itemprop="jobtitle" class="sc_team_member_jobtitle">#art_chapo</div-->
												<!--div class="sc_team_content">#art_content</div--> 
												<div class="icons">
												<a href="https://www.facebook.com/SmartcatDesign/"><img src="http://athena.smartcatdev.wpengine.com/wp-content/plugins/our-team-enhanced/inc/img/fb.png" class="sc-social" /></a>
												<a href="https://twitter.com/smartcat_dev"><img src="http://athena.smartcatdev.wpengine.com/wp-content/plugins/our-team-enhanced/inc/img/twitter.png" class="sc-social" /></a>
												<a href="https://smartcatdesign.net/"><img src="http://athena.smartcatdev.wpengine.com/wp-content/plugins/our-team-enhanced/inc/img/website.png" class="sc-social" /></a>
												<a href=mailto:email@email.com><img src="http://athena.smartcatdev.wpengine.com/wp-content/plugins/our-team-enhanced/inc/img/email.png" class="sc-social" /></a>
												</div>
												<div class="sc_team_member_overlay"></div>
												<div class="sc_team_more">
												<a href="#art_url" rel="bookmark" class="">
												<img src="'. $plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img/more.png" />
												</a>
												</div>
                                                </div>
                                            </div>',3,'1'); ?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="homepage-page-content col-sm-9">
						<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
							<article id="post-<?php echo $plxShow->artId(); ?>" class="page type-page status-publish hentry">
								<div class="entry-content">
									<header class="entry-header">
										<!--h1 class="entry-title">Page d'accueil</h1--> 
									</header>
									<h2><?php $plxShow->artTitle('link'); ?></h2>
									<p><?php $plxShow->artChapo(); ?></p>
								</div>
								<footer class="entry-footer">
									<small>
										<span class="classified-in">
											<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?>
										</span>
										<span class="tags">
											<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
										</span>
									</small>
								</footer>
							</article>
						<?php endwhile; ?>
						
                        <div class="athena-pagination">
							<?php $plxShow->pagination(); ?>
                        </div>
                    </div>

                    <?php include(dirname(__FILE__).'/sidebar.php'); ?>

                </div>
			</div>
        </main>
    </div>
 </div>

<?php include(dirname(__FILE__).'/footer.php'); ?>