<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">

                <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="<?php $plxShow->artThumbnail('#img_url'); ?>">

                    <header class="entry-header">
							<h1 class="entry-title">
								<?php $plxShow->artTitle(); ?>
							</h1>
					 </header>
                    <!-- .entry-header -->

                </div>

                <div class="row">

                    <div class="col-sm-9">

                        <article id="post-1" class="post-1 post type-post status-publish format-standard has-post-thumbnail hentry category-smartcat category-wordpress-themes tag-responsive-themes tag-setup tag-wordpress">
                            <header class="entry-header">
                                <h1 class="entry-title"><?php $plxShow->staticTitle(); ?></h1>
                            </header>

                            <div class="entry-content">
							
							<small>
								<span class="written-by">
									<?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?>
								</span>
								<time class="art-date" datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>">
									<?php $plxShow->artDate('#num_day #month #num_year(4)'); ?>
								</time>
								<span class="art-nb-com">
									<a href="<?php $plxShow->artUrl(); ?>#comments" title="<?php $plxShow->artNbCom(); ?>"><?php $plxShow->artNbCom(); ?></a>
								</span>
							</small>


							<?php $plxShow->artContent(); ?>

						<footer>
							<small>
								<span class="classified-in">
									<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?>
								</span>
								<span class="tags">
									<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
								</span>
							</small>
						</footer>
						<?php $plxShow->artThumbnail(); ?>

					</article>

					<?php $plxShow->artAuthorInfos('<div class="author-infos">#art_authorinfos</div>'); ?>

					<?php include(dirname(__FILE__).'/commentaires.php'); ?>

                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->

                    </div>

					<?php include(dirname(__FILE__).'/sidebar.php'); ?>
					
					
                    </div>
                </div>

            </main>
        </div>

    <?php include(dirname(__FILE__).'/footer.php'); ?>