<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">

                <div id="athena-page-jumbotron" class="parallax-window" data-parallax="scroll" data-image-src="http://athena.smartcatdev.wpengine.com/wp-content/uploads/sites/3/2016/02/foggy-sunday-1170158_640.jpg">

                    <header class="entry-header">
                        <h1 class="entry-title"><?php echo plxDate::formatDate($plxShow->plxMotor->cible, $plxShow->lang('ARCHIVES').' #month #num_year(4)') ?></h1> 
					</header>
                </div>
                <div class="row">				
                    <div class="athena-blog-content col-sm-9 masonry" style="position: relative; height: 2880.38px;">

					<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

						<article id="post-<?php echo $plxShow->artId(); ?>" class="athena-blog-post reveal fadeInUp post-<?php echo $plxShow->artId(); ?> post type-post status-publish format-standard has-post-thumbnail hentry category-smartcat category-wordpress-plugins category-wordpress-themes tag-athena-pro tag-how-to tag-plugins tag-setup tag-team tag-wordpress">
							<div id="athena-posts-image">
								<a href="<?php $plxShow->artUrl(); ?>"> 
									<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=300&h=201&crop-to-fit" class="attachment-medium size-medium wp-post-image" />
								</a> 
							</div>
							<div class="post-panel-content">
								<header class="entry-header">
									<h2 class="entry-title"><?php $plxShow->artTitle('link'); ?></h2>
									<div class="entry-meta">
										<div class="meta-detail">
											<div>
												<span class="fa fa-calendar"></span> 
												<span class="posted-on">
												<time class="art-date" datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>">
																			<?php $plxShow->artDate('#num_day #month #num_year(4)'); ?>
																		</time></span>
												<span class="byline"> <?php $plxShow->lang('WRITTEN_BY'); ?>
												<span class="author vcard"><?php $plxShow->artAuthor(); ?></span>
												</span>
											</div>
											<div class="author">
												<span class="fa fa-user"></span> <?php $plxShow->artAuthor(); ?>
											</div>
											<div id="single-post-views">
												<span class="fa fa-eye"></span> <?php $plxShow->artNbCom(); ?>
											</div>
										</div>
									</div>
								</header>
								<div class="entry-content">
								<?php $plxShow->artChapo(''); ?>&hellip;
								</div>

								<div class="continue-reading">
									<a class="athena-button primary" href="<?php $plxShow->artUrl(); ?>">Lire la suite</a>
								</div>
								<footer class="entry-footer"></footer>
							</div>
						</article>
					<?php endwhile; ?>

                       <div class="athena-pagination">
							<?php $plxShow->pagination(); ?>
                        </div>
 
                    </div>

		
							<?php include(dirname(__FILE__).'/sidebar.php'); ?>
		
                    </div>
                    </div>
    </main><!-- #main -->
</div><!-- #primary -->

</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>

