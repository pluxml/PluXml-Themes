<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="content" class="site-content">

        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">

				<div class="row">

				<div class="content col sml-12">

					<article class="article" id="post-<?php echo $plxShow->artId(); ?>">

						<header>
							<h2>
								<?php $plxShow->lang('ERROR'); ?>
							</h2>
						</header>

							<?php $plxShow->erreurMessage(); ?>


					</article>


				</div>
				</div>

	
			</main>
        </div>
    </div>

<?php include(dirname(__FILE__).'/footer.php'); ?>

	<main class="main">

		<div class="container">

			<div class="grid">

				<div class="content col sml-12 med-8">

					<article class="article">

						<header>
							<h2>
								<?php $plxShow->lang('ERROR'); ?>
							</h2>
						</header>

						<p>
							<?php $plxShow->erreurMessage(); ?>
						</p>

					</article>

				</div>

				<?php include(dirname(__FILE__).'/sidebar.php'); ?>

			</div>

		</div>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>

