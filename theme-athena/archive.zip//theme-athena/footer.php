<?php if (!defined('PLX_ROOT')) exit; ?>
    <footer id="colophon" class="site-footer" role="contentinfo">
        <div class="athena-footer" class="parallax-window" data-parallax="scroll" data-image-src="http://athena.smartcatdev.wpengine.com/wp-content/themes/Athena-Pro-1.0.6/inc/images/footer.jpg">
            <div>
                <div class="row"></div>
                <div class="row">
                    <div id="secondary" class="widget-area" role="complementary">
                        <aside id="recent-posts-4" class="widget widget_recent_entries col-sm-4">
                            <h2 class="widget-title"><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
                            <ul>
                                <?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
                            </ul>
                        </aside>
                        <aside id="text-7" class="widget widget_text col-sm-4">
                            <h2 class="widget-title">Texte central</h2>
                            <div class="textwidget">Petit bout de texte statique installé au centre du pied-de-page.  Aussi bien trouver quelque chose à dire, ça ferait u gros trou en l'enlevant.</div>
                        </aside>
                        <aside id="tag_cloud-3" class="widget widget_tag_cloud col-sm-4">
                            <h2 class="widget-title">Sujets populaire (mots-clés)</h2>
                            <div class="tagcloud">
                                <?php 
								$plxMotor = plxMotor::getInstance();
								$format='<a href="#tag_url" title="#tag_name" style="font-size: #tag_size pt;">#tag_name</a> ';
								$max='20';
								$order='';
								$datetime = date('YmdHi');
								$array=array();
								$alphasort=array();
								# On verifie qu'il y a des tags
								if($plxShow->plxMotor->aTags) {
									# On liste les tags sans créer de doublon
									foreach($plxShow->plxMotor->aTags as $idart => $tag) {
										if(isset($plxShow->plxMotor->activeArts[$idart]) AND $tag['date']<=$datetime AND $tag['active']) {
											if($tags = array_map('trim', explode(',', $tag['tags']))) {
												foreach($tags as $tag) {
													if($tag!='') {
														$t = plxUtils::title2url($tag);
														if(!isset($array['_'.$tag])) {
															$array['_'.$tag]=array('name'=>$tag,'url'=>$t,'count'=>1);
														}
														else
															$array['_'.$tag]['count']++;
														if(!in_array($t, $alphasort))
															$alphasort[] = $t; # pour le tri alpha
													}
												}
											}
										}
									}

									# tri des tags
									switch($order) {
										case 'alpha':
											if($alphasort) array_multisort($alphasort, SORT_ASC, $array);
											break;
										case 'random':
											$arr_elem = array();
											$keys = array_keys($array);
											shuffle($keys);
											foreach ($keys as $key) {
												$arr_elem[$key] = $array[$key];
											}
											$array = $arr_elem;
											break;
									}

									# limite sur le nombre de tags à afficher
									if($max!='') $array=array_slice($array, 0, intval($max), true);

								}

								$mode = $plxShow->plxMotor->mode;

								# Récupération de la liste des tags de l'article si on est en mode 'article'
								# pour mettre en évidence les tags dans la sidebar s'ils sont attachés à l'article
								$artTags = array();
								if($mode=='article') {
									$artTagList = $plxShow->plxMotor->plxRecord_arts->f('tags');
									if(!empty($artTagList)) {
										$artTags = array_map('trim', explode(',', $artTagList));
									}
								}

								# On affiche la liste
								$size=0;
								foreach($array as $tagname => $tag) {
									$name = str_replace('#tag_id','tag-'.$size++,$format);
									$name = str_replace('#tag_size',($tag['count']>10?'max':($tag['count']*3)),$name);
									$name = str_replace('#tag_count',$tag['count'],$name);
									$name = str_replace('#tag_item',$tag['url'],$name);
									$name = str_replace('#tag_url',$plxShow->plxMotor->urlRewrite('?tag/'.$tag['url']),$name);
									$name = str_replace('#tag_name',plxUtils::strCheck($tag['name']),$name);
									$name = str_replace('#nb_art',$tag['count'],$name);
									if($mode=='article' AND in_array($tag['name'],$artTags))
										$tags = str_replace('#tag_status','active', $name);
									else
										$tags = str_replace('#tag_status',(($mode=='tags' AND $plxShow->plxMotor->cible==$tag['url'])?'active':'noactive'), $name);

									echo $tags;
								}
								?>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>

        <div class="clear"></div>

        <div class="site-info">

            <div class="row">
                <div class="athena-copyright">Copyright 2017 </div>
                <div id="authica-social">
                    <a href="http://facebook.com" target="_BLANK" class="athena-facebook">
                        <span class="fa fa-facebook"></span>
                    </a>
                    <a href="http://gplus.com" target="_BLANK" class="athena-gplus">
                        <span class="fa fa-google-plus"></span>
                    </a>
                    <a href="http://instagram.com" target="_BLANK" class="athena-instagram">
                        <span class="fa fa-instagram"></span>
                    </a>
                    <a href="http://linkedin.com" target="_BLANK" class="athena-linkedin">
                        <span class="fa fa-linkedin"></span>
                    </a>
                    <a href="http://pinterest.com" target="_BLANK" class="athena-pinterest">
                        <span class="fa fa-pinterest"></span>
                    </a>
                    <a href="http://twitter.com" target="_BLANK" class="athena-twitter">
                        <span class="fa fa-twitter"></span>
                    </a>
                    <a href="#" target="_BLANK" class="athena-tumblr">
                        <span class="fa fa-tumblr"></span>
                    </a>
                    <a href="#" target="_BLANK" class="athena-youtube">
                        <span class="fa fa-youtube-play"></span>
                    </a>
                    <a href="#" target="_BLANK" class="athena-vimeo">
                        <span class="fa fa-vimeo"></span>
                    </a>
                    <a href="#" target="_BLANK" class="athena-soundcloud">
                        <span class="fa fa-soundcloud"></span>
                    </a>
                </div>

                <div class="menu-footer-menu-container">
                    <ul id="footer-menu" class="athena-footer-nav">
                        <?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="menu-item #static_class #static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
                        <?php $plxShow->pageBlog('<li class="menu-item #page_class #page_status" id="#page_id"><a href="#page_url" title="#page_name">#page_name</a></li>'); ?>
						<li class="menu-item"><a class="athena-search" href="#search" role="button" data-toggle="modal"><span class="fa fa-search"></span></a></li>
						<li class="menu-item"><a class="athena-contact" href="#contact" role="button" data-toggle="modal"><span class="fa fa-envelope"></span></a></li>
						<li class="menu-item"><a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a></li>
						<!--li><a class="athena-cart" href=""><span class="fa fa-shopping-cart"></span> <span class="amount">&pound;0.00</span></a></li-->
                    </ul>
                </div>
                <br>

                <a href="https://smartcatdesign.net" rel="designer" style="display: block !important" class="rel" target="_blank">
					Design par Smartcat <img src="<?php $plxShow->template(); ?>/images/cat_logo_mini.png"/>
				</a>

            </div>
            <div class="scroll-top alignright">
                <span class="fa fa-chevron-up"></span>
            </div>
        </div>
    </footer>
    </div>
    <link rel='stylesheet' id='smartcat_customizer_theme_style-css' href='<?php $plxShow->template(); ?>/css/athena.css?ver=1.0' type='text/css' media='all' />
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wc_add_to_cart_params = {
            "ajax_url": "<?php $plxShow->template(); ?>\/js\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
            "i18n_view_cart": "View Cart",
            "cart_url": "",
            "is_cart": "",
            "cart_redirect_after_add": "no"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/add-to-cart.min.js?ver=2.5.5'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.blockUI.min.js?ver=2.70'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var woocommerce_params = {
            "ajax_url": "<?php $plxShow->template(); ?>\/js\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/woocommerce.min.js?ver=2.5.5'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.cookie.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wc_cart_fragments_params = {
            "ajax_url": "<?php $plxShow->template(); ?>\/js\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
            "fragment_name": "wc_fragments"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/cart-fragments.min.js?ver=2.5.5'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/navigation.js?ver=20120206'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/skip-link-focus-fix.js?ver=20130115'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/unite.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/bootstrap.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/sticky.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/easing.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/camera.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/parallax.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/owl.carousel.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/slicknav.min.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/wow.js?ver=1.0.6'></script>
    <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/wp-embed.min.js?ver=4.7.3'></script>
 </body>

</html>