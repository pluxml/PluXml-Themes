<?php if(!defined('PLX_ROOT')) exit; ?>
<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
    <div id="content">
        <h2 class="title">R&eacute;sultat de la recherche</h2>
        <?php plxSearch::Results() ?>
    </div>
    <?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>