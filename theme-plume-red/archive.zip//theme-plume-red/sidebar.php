<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul><?php $plxShow->catList('Accueil'); ?></ul>
	</div>
	<div id="statiques">
		<h2>Pages</h2>
		<ul><?php $plxShow->staticList(); ?></ul>
	</div>
	<div id="liens">
		<h2>Liens</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
			<li><a href="core/admin/">Administration</a></li>
		</ul>
	</div>
</div>
<hr/>