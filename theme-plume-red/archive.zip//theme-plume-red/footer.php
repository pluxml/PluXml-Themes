<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>Généré par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> - Adapt&eacute; par <a href="http://www.flox-arts.net">Flox-arts.net</a></p>
</div>

</body>
</html>