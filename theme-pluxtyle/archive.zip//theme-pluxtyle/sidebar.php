<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('Accueil','#cat_name'); ?>
		</ul>
		<h2>Abonnements</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
		<h2>Derniers articles</h2>
		<ul>
			<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
		</ul>
		<h2>Derniers commentaires</h2>
		<ul id="lastcomm">
			<?php $plxShow->lastComList('<a href="#com_url"><span class="author">#com_author</span> a dit :</a><br/><ul class="sidecomm"><li>&laquo;&nbsp;#com_content(55)&nbsp;&raquo;</li></ul>'); ?>
		</ul>
	</div>
</div>
<div class="clearer"></div>