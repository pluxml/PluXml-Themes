<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p><a href="http://pluxml.org" title="Pluxml-beta-4.2 : blog ou CMS sans base de donn&eacute;es">pluxml</a> | <a href="core/admin/">admin</a> | <a href="#top" title="Retour en haut de page">top</a></p>
</div>
</body>
</html>