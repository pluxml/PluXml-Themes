<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="page">
	<div id="content">
		<div class="post">
			<h2 class="title"><?php $plxShow->artTitle(); ?></h2>
			<p class="post-info">
				Par <span class="author"><?php $plxShow->artAuthor(); ?></span>, 
				le <?php $plxShow->artDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?>
				|  <?php $plxShow->artCat(); ?>
			</p>
			<?php $plxShow->artContent(); ?>
			<div class="separator">&nbsp;</div>
		</div>
		<?php # Si on a des commentaires ?>
		<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
			<div id="comments">
				<h2>Commentaires</h2>
				<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
					<div id="<?php $plxShow->comId(); ?>" class="comment">
						<div class="info_comment">
							<p>Par <span class="author"><?php $plxShow->comAuthor('link'); ?></span>
							le <?php $plxShow->comDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?></p>
						</div>
						<blockquote><p><?php $plxShow->comContent() ?></p></blockquote>
					</div>
				<?php endwhile; # Fin de la boucle sur les commentaires ?>
				<?php # On affiche le fil Atom de cet article ?>
				<div class="feed_article"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>
				<div class="separator">&nbsp;</div>
			</div>
		<?php endif; # Fin du if sur la prescence des commentaires ?>
		<?php # Si on autorise les commentaires ?>
		<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
			<div id="form">
				<h2>&Eacute;crire un commentaire</h2>
				<p class="message_com"><?php $plxShow->comMessage(); ?></p>
				<form action="<?php $plxShow->artUrl(); ?>#form" method="post">
					<fieldset>
						<label>Votre nom&nbsp;:</label><br />
						<input name="name" type="text" size="20" value="<?php $plxShow->comGet('name',''); ?>" maxlength="30" /><br />
						<label>Votre site (facultatif)&nbsp;:</label><br />
						<input name="site" type="text" size="20" value="<?php $plxShow->comGet('site','http://'); ?>" /><br />
						<label>Votre courriel (facultatif)&nbsp;:</label><br />
						<input name="mail" type="text" size="20" value="<?php $plxShow->comGet('mail',''); ?>" /><br />
						<label>Votre commentaire&nbsp;:</label><br />
						<textarea name="content" cols="35" rows="8"><?php $plxShow->comGet('content',''); ?></textarea><br />
						<?php # Affichage du capcha anti-spam
						if($plxShow->plxMotor->aConf['capcha']): ?>
						<label><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label>
						<p><?php $plxShow->capchaQ(); ?>&nbsp;<input name="rep" type="text" size="4" />
						<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
						<?php endif; # Fin du if sur le capcha anti-spam ?><input type="reset" value="Effacer" /><input type="submit" value="Envoyer" /></p>
					</fieldset>
				</form>
				<div class="clearer"></div>
			</div>
		<?php endif; # Fin du if sur l'autorisation des commentaires ?>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>