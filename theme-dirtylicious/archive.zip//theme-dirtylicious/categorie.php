<?php include('header.php'); # On insere le header ?>
	<div class="path">
		<?php $plxShow->staticList('Accueil'); ?>
	</div>
	<div class="main">
		<div class="content">	
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
			<div class="post">
				<h1><?php $plxShow->artTitle('link'); ?></h1>
				<div class="entry"> <p class="post-info">Post&eacute; le 
			      <?php $plxShow->artDate(); ?> dans 
			      <?php $plxShow->artCat(); ?>.
				  </p>
				<?php $plxShow->artChapo(); ?>
				<p class="right"><br /><?php $plxShow->artNbCom(); ?></p><br /><br /></div>
			</div>
		<?php endwhile; # Fin de la boucle sur les articles ?>
		<?php # On affiche la pagination ?>
		<p class="aligncenter"><?php $plxShow->pagination(); ?></p>
	</div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
</div>
<?php include('footer.php'); # On insere le footer ?>
