	<div class="footer">
	<div class="left">
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | <a href="http://templates.arcsin.se/">Theme</a> by <a href="http://arcsin.se/">Arcsin</a> </div>
		<div class="right"><a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a></div>
	<div class="clearer"><span></span></div>
</div></div></div>

</body>
</html>
