<?php include('header.php'); # On insere le header ?>
	<div class="path">
		<?php $plxShow->staticList('Accueil'); ?>
	</div>
	<div class="main">
		<div class="content">		
		<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
		<?php $plxShow->staticContent(); ?>
	</div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
</div>
<?php include('footer.php'); # On insere le footer ?>
