<?php if(!defined('PLX_ROOT')) exit; ?>

<div id="navigation">
	<ul>
		<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li id="#static_id"><a href="#static_url" class="#static_status" title="#static_name"><span>#static_name</span></a></li>'); ?>
		<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name"><span>#page_name</span></a></li>'); ?>
	</ul>
	
	<div class="cl">&nbsp;</div>
</div>