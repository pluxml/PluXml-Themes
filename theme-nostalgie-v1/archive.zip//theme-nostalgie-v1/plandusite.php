<h1>Sitemap du site <?php $plxShow->mainTitle('link'); ?></h1>
<h2><?php $plxShow->subTitle(); ?></h2>
<br/><br/>

<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les autres articles ?>    <br/>
<?php $plxShow->artTitle('link'); ?><br/>
<?php endwhile; # Fin de la boucle sur les articles ?>