<?php include(dirname(__FILE__).'/header.php'); ?>

<section id="article-section" class="line">
         <div class="margin">
            <!-- ARTICLES -->             
            <div class="s-12">

				<h1 style="color: #fff;"><?php $plxShow->staticTitle(); ?></h1>

               <article class="margin-bottom">
                  <!-- text -->                 
                  <div class="post-text">
                     <h1><?php $plxShow->staticTitle(); ?></h1>
						
					<?php $plxShow->staticContent(); ?>
               </article>
               <!-- AD REGION -->
               <div class="line">
                  <div class="advertising horizontal">
                     <script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                     <!-- Fashion Blog -->
                     <ins class="adsbygoogle" style="display: block; height: 90px;" data-ad-client="ca-pub-8115128083480193" data-ad-slot="9121305263" data-ad-format="auto" data-adsbygoogle-status="done"><ins id="aswift_0_expand" style="display:inline-table;border:none;height:90px;margin:0;padding:0;position:relative;visibility:visible;width:771px;background-color:transparent"><ins id="aswift_0_anchor" style="display:block;border:none;height:90px;margin:0;padding:0;position:relative;visibility:visible;width:771px;background-color:transparent"><iframe width="771" height="90" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allowfullscreen="true" onload="var i=this.id,s=window.google_iframe_oncopy,H=s&amp;&amp;s.handlers,h=H&amp;&amp;H[i],w=this.contentWindow,d;try{d=w.document}catch(e){}if(h&amp;&amp;d&amp;&amp;(!d.body||!d.body.firstChild)){if(h.call){setTimeout(h,0)}else if(h.match){try{h=s.upd(h,i)}catch(e){}w.location.replace(h)}}" id="aswift_0" name="aswift_0" style="left:0;position:absolute;top:0;"></iframe></ins></ins></ins>
                     <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                     </script>          
                  </div>
               </div>
            </div>

         </div>
      </section>
<?php include(dirname(__FILE__).'/footer.php'); ?>
