<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a>  
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | 
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
		<br />
		Photo_Galery_Blue designed by <a href="http://csscreme.com">Css_Creme</a> | Valide <a href="http://validator.w3.org/check?uri=referer">xHTML</a> - <a href="http://jigsaw.w3.org/css-validator/check?uri=referer">Css</a>
	</p>
</div>

</body>
</html>