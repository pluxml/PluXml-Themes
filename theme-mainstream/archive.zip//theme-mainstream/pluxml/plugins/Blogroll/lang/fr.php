<?php
	$LANG = array(
		'L_TITLE'	=>	'Blogroll',
		'L_CONFIG_DESCRIPTION'		=>	'Page de configuration du plugin Blogroll',
		'L_CONFIG_ROOT_PATH'		=>	'Emplacement du fichier du blogroll (fichier xml)',
		'L_CONFIG_SAVE'				=>	'Enregistrer',
		'L_CONFIG_PUB_TITLE'		=>	'Afficher en tant que (partie publique)',
		'L_ADMIN_DESCRIPTION'		=>	'Page d\'administration du plugin Blogroll',		
		'L_ADMIN_APPLY_BUTTON'		=>	'Mettre à jour',
		'L_ADMIN_SELECTION'			=>	'Pour la séléction',
		'L_ADMIN_DELETE'			=>	'Effacer',
		'L_ADMIN_LIST_ID'			=>	'Identifiant',
		'L_ADMIN_LIST_NAME'			=>	'Titre',
		'L_ADMIN_LIST_URL'			=>	'URL',
		'L_ADMIN_LIST_DESC'			=>	'Description',
		'L_ADMIN_LIST_LANG'			=>	'Langue',
		'L_ADMIN_LIST_LINK'			=>	'Lien',
		'L_ADMIN_LIST_NEW'			=>	'Nouveau',
		'L_ADMIN_LIST_ORDER'			=>	'Ordre'
		
	);
?>
