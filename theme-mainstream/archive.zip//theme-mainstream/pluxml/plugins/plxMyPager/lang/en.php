<?php

$LANG = array(

# config.php
'L_PAGER_CHECK_LIB'				=> 'Check items to display',
'L_PAGER_NUM_PAGES'				=> 'Number of pages',
'L_PAGER_INDICATOR'				=> 'Indicator',
'L_PAGER_SAVE'					=> 'Save',

'L_PAGER_CSS_DESCRIPTION'		=> 'Display can be changed in the stylesheet of the theme by changing the following CSS classes',
'L_PAGER_CSS_ITEM'				=> 'item of the pager',
'L_PAGER_CSS_FIRST'				=> 'first page',
'L_PAGER_CSS_PREV'				=> 'previous page',
'L_PAGER_CSS_CURRENT'			=> 'current page',
'L_PAGER_CSS_NEXT'				=> 'next page',
'L_PAGER_CSS_LAST'				=> 'last dernière',

);
?>