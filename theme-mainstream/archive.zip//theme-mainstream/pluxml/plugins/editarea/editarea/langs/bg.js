/*
 *	Bulgarian translation
 *	Author:		Valentin Hristov
 *	Company:	SOFTKIT Bulgarian
 *	Site:		http://www.softkit-bg.com
 */
editAreaLoader.lang["bg"]={
new_document: "нов документ",
search_button: "търсене и замяна",
search_command: "търси следващия / отвори прозорец с търсачка",
search: "търсене",
replace: "замяна",
replace_command: "замяна / отвори прозорец с търсачка",
find_next: "намери следващия",
replace_all: "замени всички",
reg_exp: "реголярни изрази",
match_case: "чуствителен към регистъра",
not_found: "няма резултат.",
occurrence_replaced: "замяната е осъществена.",
search_field_empty: "Полето за търсене е празно",
restart_search_at_begin: "До края на документа. Почни с началото.",
move_popup: "премести прозореца с търсачката",
font_size: "--Размер на шрифта--",
go_to_line: "премени към реда",
go_to_line_prompt: "премени към номера на реда:",
undo: "отмени",
redo: "върни",
change_smooth_selection: "включи/изключи някой от функциите за преглед (по красиво, но повече натоварва)",
highlight: "превключване на оцветяване на синтаксиса включена/изключена",
reset_highlight: "въстанови оцветяване на синтаксиса (ако не е синхронизиран с текста)",
word_wrap: "режим на пренасяне на дълги редове",
help: "за програмата",
save: "съхрани",
load: "зареди",
line_abbr: "Стр",
char_abbr: "Стлб",
position: "Позиция",
total: "Всичко",
close_popup: "затвори прозореца",
shortcuts: "Бързи клавиши",
add_tab: "добави табулация в текста",
remove_tab: "премахни табулацията в текста",
about_notice: "Внимание: използвайте функцията оцветяване на синтаксиса само за малки текстове",
toggle: "Превключи редактор",
accesskey: "Бърз клавиш",
tab: "Tab",
shift: "Shift",
ctrl: "Ctrl",
esc: "Esc",
processing: "Зареждане...",
fullscreen: "на цял екран",
syntax_selection: "--Синтаксис--",
close_tab: "Затвори файла"
};
