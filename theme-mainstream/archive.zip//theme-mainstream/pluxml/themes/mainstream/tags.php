<?php include(dirname(__FILE__).'/header.php'); 
      include(dirname(__FILE__).'/smarty_modifier_truncate.php');?>

	<div id="content">

			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
			
				<div class="post">
				
					<p class="meta"><span class="date"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></span> ~ <span class="comments"><?php $plxShow->artNbCom(); ?></span></p>
			
					<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
					
					<div class="categories">
						<?php $plxShow->artCat(); ?>

					</div><!-- /.categories -->
					
					<div class="entry">
						<?php ob_start(); 
	                	$plxShow->artContent($chapo=true);
	                	$content = ob_get_clean();
	                	ob_start();
	                	$plxShow->artUrl();
	                	$link = ob_get_clean();

	                	$masque = '#<img(.+?)src="(.+?)"#i'; preg_match($masque, $content, $resultats);
	                	$extension = pathinfo($resultats[2], PATHINFO_EXTENSION); ?>

	                	<?php if($extension['extension'] == ('jpg'||'jpeg'||'png'||'gif')) : ?>									
	                	<a href="<?php $plxShow->artUrl($type='relatif'); ?>" rel="bookmark" title="Lien vers <?php $plxShow->artTitle(''); ?>">        
	                	<img src="<?php $plxShow->template(); ?>/timthumb.php?src=<?php echo $resultats[2]; ?>&amp;w=100&amp;h=100&amp;zc=1&amp;q=90" alt="<?php $plxShow->artTitle(''); ?>" width="100px" height="100px" class="main-image thumb alignleft border" /></a>
	                	<?php endif; ?>
	                	
	                	<?php $text = preg_replace('/<img(.*?)>/', '', $content, 1);
	                	echo smarty_modifier_truncate($text, 200, $etc = ' Lire la suite',false,false,$link); ?>
						
					</div><!-- /.entry -->
					
					<div class="tags">
						<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?>

					</div><!-- /.tags -->
				</div><!-- /.post -->

			<?php endwhile; ?>

			<div class="Nav">
				<?php $plxShow->pagination(); ?>				

			</div>

	</div><!-- /#content -->

	<?php include(dirname(__FILE__).'/sidebar.php'); ?>
	
<?php include(dirname(__FILE__).'/footer.php'); ?>


