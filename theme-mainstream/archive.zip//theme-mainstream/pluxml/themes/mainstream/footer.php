<?php if(!defined('PLX_ROOT')) exit; ?>

		</div><!-- /#inside -->
	</div><!-- /#main -->
	<div id="footer">

		<p>&copy; <?php $plxShow->mainTitle('link'); ?> -
			<?php $plxShow->lang('POWERED_BY') ?> <a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
			<?php $plxShow->lang('IN') ?> <?php $plxShow->chrono(); ?>
			<?php $plxShow->httpEncoding() ?> - 
			<span><a class="admin" rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>" onclick="window.open(this.href);return false;"><img src="<?php $plxShow->template(); ?>/img/option-icon-general.png" alt="Administration" /></a></span>
		</p>
		<p><a href="http://woothemes.com" title="WooThemes"><img src="<?php $plxShow->template(); ?>/img/woothemes.png" alt="WooThemes Logo" /></a></p>

	</div><!-- /#footer -->
</div><!-- /#container -->

</body>
</html>
