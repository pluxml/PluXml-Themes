<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="content">

		<h2><?php $plxShow->lang('ERROR') ?> :</h2>
		<div class="error-content"><?php $plxShow->erreurMessage(); ?></div>

	</div><!-- /#content -->

	<?php include(dirname(__FILE__).'/sidebar.php'); ?>
	
<?php include(dirname(__FILE__).'/footer.php'); ?>
