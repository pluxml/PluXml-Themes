<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php $plxShow->defaultLang() ?>" lang="<?php $plxShow->defaultLang() ?>">

<head>

	<title><?php $plxShow->pageTitle(); ?></title>

	<meta http-equiv="Content-Type" content="text/html; charset=<?php $plxShow->charset(); ?>" />
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>

	<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/styles/reset.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/style.css" media="screen" />
	
    <!--[if IE 6]>
		<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/pngfix.js"></script>
		<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/menu.js"></script>
		<link rel="stylesheet" type="text/css" media="all" href="<?php $plxShow->template(); ?>/styles/ie6.css" />
    <![endif]-->	
	
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php $plxShow->template(); ?>/styles/ie7.css" />
	<![endif]-->

    <script type="text/javascript" src="<?php $plxShow->template(); ?>/js/jquery-min.js"></script>
    
	<?php $plxShow->templateCss() ?>

	<!-- Alt Stylesheet -->
	<link href="<?php $plxShow->template(); ?>/styles/default.css" rel="stylesheet" type="text/css" />
	<!-- 
	<link href="<?php $plxShow->template(); ?>/styles/blue.css" rel="stylesheet" type="text/css" />
	<link href="<?php $plxShow->template(); ?>/styles/khaki.css" rel="stylesheet" type="text/css" />
	<link href="<?php $plxShow->template(); ?>/styles/minimal.css" rel="stylesheet" type="text/css" />
	<link href="<?php $plxShow->template(); ?>/styles/violet.css" rel="stylesheet" type="text/css" />
	-->

	<!-- Custom Stylesheet -->
	<link href="<?php $plxShow->template(); ?>/styles/custom.css" rel="stylesheet" type="text/css" />
	

	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />

</head>

<body id="top">
<div id="skip">
	<a href="<?php $plxShow->urlRewrite('#nav') ?>" title="<?php $plxShow->lang('GOTO_MENU') ?>"><?php $plxShow->lang('GOTO_MENU') ?></a>&nbsp;<a href="<?php $plxShow->urlRewrite('#content') ?>" title="<?php $plxShow->lang('GOTO_CONTENT') ?>"><?php $plxShow->lang('GOTO_CONTENT') ?></a>
</div>
<div id="container">       
	<div id="header">
		<div id="logo">
		<h1><?php $plxShow->mainTitle('link'); ?></h1>
		<h2><?php $plxShow->subTitle(); ?></h2>
			<a href="<?php $plxShow->racine(); ?>" title="<?php $plxShow->subTitle(); ?>">
				<img src="<?php $plxShow->template(); ?>/img/logo.png" alt="WP Logo" />
			</a>
		</div><!-- /#logo -->

        <div id="top-ad">
	                </div><!-- /#top-ad -->      		
		
		<div class="clear"></div>
		<div id="navigation">
			<ul id="nav">

			<?php 
			$plxShow->catList($plxShow->getLang('HOME'),array('<li class="#cat_status page_item"><a href="#cat_url" title="#cat_name">#cat_name</a></li>'."\n\t\t",15));
			$plxShow->staticList('','<li id="#static_id" class="#static_status page_item"><a href="#static_url" title="#static_name">#static_name</a></li>');
			$plxShow->pageBlog('<li class="#page_status page_item" ><a href="#page_url" title="#page_name">#page_name</a></li>'); 
			?>

			</ul><!-- /#pagenav -->
		</div><!-- /#navigation -->
		
		<div class="clear"></div>

	</div><!-- /#header -->

	<div id="main">
		<div id="inside">
