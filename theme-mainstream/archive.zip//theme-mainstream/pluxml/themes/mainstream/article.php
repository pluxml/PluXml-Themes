<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="content">
				<div class="post">
				
					<p class="meta"><span class="date"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></span> ~ <span class="comments"><?php $plxShow->artNbCom(); ?></span></p>
			
					<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
					
					<div class="categories">
						<?php $plxShow->artCat(); ?>

					</div><!-- /.categories -->
					
					<div class="entry">
						<?php $plxShow->artContent(); ?>
						
					</div><!-- /.entry -->
					
					<div class="tags">
						<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?>

					</div><!-- /.tags -->
				</div><!-- /.post -->
			<?php include(dirname(__FILE__).'/commentaires.php'); ?>
		
	</div><!-- /#content -->

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>    
<?php include(dirname(__FILE__).'/footer.php'); ?>