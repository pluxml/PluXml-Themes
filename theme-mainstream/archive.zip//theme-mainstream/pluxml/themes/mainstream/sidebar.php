<?php if(!defined('PLX_ROOT')) exit; ?>
	<div id="sidebar">

	<div id="search_main" class="widget"><h3><?php $plxMotor->plxPlugins->getInstance('plxMySearch')->lang('L_PAGE_TITLE');?><span class="fold">&nbsp;</span></h3>
		<?php eval($plxShow->callHook('MySearchForm')) ?>

	</div>
		
	<div class="widget widget_calendar"><h3>Calendrier<span class="fold">&nbsp;</span></h3>
		<div id="calendar_wrap">
			<?php eval($plxShow->callHook('CalInSidebar')); ?>

		</div>
	</div>
	<div class="widget widget_categories"><h3><?php $plxShow->lang('CATEGORIES') ?><span class="fold">&nbsp;</span></h3>		
		<ul>
			<?php $plxShow->catList('','<li id="#cat_id" class="#cat_status"><a href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>

		</ul>
	</div>
	<div id="ads" class="widget"><h3>Sponsors<span class="fold">&nbsp;</span></h3>
			<?php eval($plxShow->callHook('see',array('<a href="#extLink" title="#description"><img src="#url" alt="#alt" width="#width" height="#height"/></a>','<img src="#url" alt="#alt" width="#width" height="#height" title="#description"/>'))) ;?>
	
	<div class="clear"></div>
	</div><!-- /#ads -->
	<div class="widget widget_links"><h3>Blogroll<span class="fold">&nbsp;</span></h3>
		<ul class='xoxo blogroll'>
			<?php eval($plxShow->callHook('showBlogroll')); ?>

		</ul>
	</div>
	<div class="widget widget_archive"><h3><?php $plxShow->lang('ARCHIVES') ?><span class="fold">&nbsp;</span></h3>		
		<ul>
			<?php $plxShow->archList('<li id="#archives_id" class="#archives_status"><a href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>

		</ul>
	</div>	
	<div class="widget widget_tags"><h3><?php $plxShow->lang('TAGS') ?><span class="fold">&nbsp;</span></h3>		
		<div class="tagcloud">
			<?php $plxShow->tagList('<a href="#tag_url" class="#tag_link" title="#tag_name">#tag_name</a>'."\n", 20);?>

		</div>
	</div>	
	<div class="widget widget_articles"><h3><?php $plxShow->lang('LAST_ARTICLES') ?><span class="fold">&nbsp;</span></h3>		
		<ul>
			<?php $plxShow->lastArtList('<li class="#art_status"><a href="#art_url" title="#art_title">#art_title</a></li>'); ?>

		</ul>
	</div>	
	<div class="widget widget_comments"><h3><?php $plxShow->lang('LAST_COMMENTS') ?><span class="fold">&nbsp;</span></h3>		
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>');?>

		</ul>
	</div>
</div><!-- /#sidebar -->		
<div class="clear"></div>