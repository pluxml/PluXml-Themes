</div>

<div id="footer">

	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | 
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a><br />
		
		 Graphics and design by <a href="http://www.ischiahotel.info" title="hotel ischia">hotel ischia</a>|<a href="http://www.ischiaexplorer.it" title="alberghi ischia">alberghi ischia</a>
      </p>

</div>

</body>
</html>