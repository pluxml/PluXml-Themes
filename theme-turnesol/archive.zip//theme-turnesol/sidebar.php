<div id="sidebar">
	 <div class="top"></div>
	 
		 <h1><?php $plxShow->mainTitle('link'); ?></h1>
		<p><?php $plxShow->subTitle(); ?></p>
		
	<div class="top"></div>
		
		
		<h3>Cat&eacute;gories</h3>
		<ul>
			<?php $plxShow->catList('Accueil','#cat_name'); ?>
		</ul>
	

		<h3>Syndication</h3>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
	
</div>
<div class="clearer"></div>