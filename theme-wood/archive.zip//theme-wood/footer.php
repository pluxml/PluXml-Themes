<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer"> <!--ne pas supprimer cette section , merci :) -->
   &copy;  2011  -  CSS Cr&eacute;ation:  <a href="http://www.unesourisetmoi.info" title="fonds d'écran">fonds d'écran</a> 
     | &copy; <?php $plxShow->mainTitle('link'); ?> - 
		<?php $plxShow->lang('POWERED_BY') ?> <a href="http://pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a> 
		<?php $plxShow->lang('IN') ?> <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?><br />
Partenaires & SEO:  <a href="http://www.unesourisetmoi.info" title="fonds d'écran">fonds d'écran</a>  | <a href="http://blog.unesourisetmoi.info/"> blog et cms xml sans bdd</a><!--fin-->
  <p class="right">
		<a class="top" href="<?php echo $plxShow->urlRewrite('#top') ?>" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a>
	</p>
	<p>Quelques liens ... à mettre dans le fichier footer.php</p>
	<p>&nbsp;</p>


	<p class="right">
		<a class="admin" rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
	</p>
</div>

</body>
</html>