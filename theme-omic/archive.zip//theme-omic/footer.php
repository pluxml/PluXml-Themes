<?php if(!defined('PLX_ROOT')) exit; ?>
</div><!-- /Content-->

<!-- Footer --> 
<div id="footer">

<!-- Footer Toolbar -->
<div id="footer-toolbar">
<!-- Footer Navigation -->
<div id="footer-toolbar-nav">
<ul>
	<?php $plxShow->staticList('Accueil','<li class="page_item" id="#static_id"><a href="#static_url" class="#static_status" title="#static_name">#static_name</a></li>'); ?>
	<?php $plxShow->pageBlog('<li class="page_item" id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
</ul>
</div><!-- /Footer Navigation -->
</div><!-- /Footer Toolbar -->

<!-- Footer Text --> 
<div id="footer-text">

<!-- FOOTER CREDITS LINK -->	
<strong>&copy; <?php $plxShow->mainTitle('link'); ?></strong> - 
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a> 
		en <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?><br />
<em><strong><a href="http://www.freethemelayouts.com/" style="color: #61676B;text-decoration: none;" title="Free WordPress Themes">Free WordPress Themes</a> by [i] <a href="http://www.iwebsitetemplate.com" style="color: #61676B;text-decoration: none;" title="Website Templates">Website Templates</a></strong></em>


</div><!-- /Footer Text --> 

<div style="clear:both;"><!--IE6FIX--></div> 

</div><!-- /Footer -->

</body>
</html>