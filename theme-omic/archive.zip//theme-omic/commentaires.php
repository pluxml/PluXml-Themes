<?php if(!defined('PLX_ROOT')) exit; ?>
<!-- You can start editing here. -->

<div id="comments-body">

<?php # Si on a des commentaires ?>
<?php if($plxShow->plxMotor->plxRecord_coms): ?>

<div class="comment-spacer"><!-- Comments Spacer --></div>
<span class="comments-center">Commentaires</span>
<div class="comment-spacer"><!-- Comments Spacer --></div>

		<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
<!-- Comments -->
<div class="comments">

<div class="comment-box black type-<?php $plxShow->comType(); ?>" id="<?php $plxShow->comId(); ?>">
<img src="http://www.gravatar.com/avatar.php?gravatar_id=<?php echo md5( strtolower($plxShow->plxMotor->plxRecord_coms->f('mail')) ) ?>&amp;default=http://www.gravatar.com/avatar/3b3be63a4c2a439b013787725dfce802.jpg&amp;size=48" alt="Avatar Gravatar" class="avatar avatar-48 photo" height="48" width="48" /> 
<div class="comment-info">
<span class="comment-author"><?php $plxShow->comAuthor('link'); ?></span> 
<span class="comment-stat"><a href="<?php $plxShow->ComUrl() ?>" title="#<?php echo $plxShow->plxMotor->plxRecord_coms->i+1 ?>">#<?php echo $plxShow->plxMotor->plxRecord_coms->i+1 ?></a> Le <?php $plxShow->comDate('#num_day #month #num_year(4)'); ?></span>
</div><!-- /Comment-Info -->
<div class="comment-text">
<div style="background:#EEEEEE;margin:0 0 5px;padding:10px 10px 5px;">
<p><?php $plxShow->comContent() ?></p>
</div>
 
</div><!-- /Comment-Text -->

</div><!-- /Comment-Box -->
</div><!-- /Comments -->
		<?php endwhile; # Fin de la boucle sur les commentaires ?>
		<?php # On affiche le fil Atom de cet article ?>
		<div class="feed_article"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>

<?php endif; # Fin du if sur la prescence des commentaires ?>
<?php # Si on autorise les commentaires ?>
<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
<!-- Comment Form -->
<div id="comment-form">
<h2>Ecrire un commentaire</h2>

		<p class="message_com"><?php $plxShow->comMessage(); ?></p>
		<form action="<?php $plxShow->artUrl(); ?>#form" method="post" id="commentform">

					<p><input name="name" type="text" size="20" value="<?php $plxShow->comGet('name','Nom'); ?>" tabindex="1" id="author" /></p>
					<p>
					<input name="site" type="text" size="20" value="<?php $plxShow->comGet('site','Site'); ?>" tabindex="2" id="url" /></p>
					<p>
					<input name="mail" type="text" size="20" value="<?php $plxShow->comGet('mail','@'); ?>" tabindex="3" id="email" /></p>

				<p>
				<textarea name="content" cols="100%" rows="10" tabindex="4"><?php $plxShow->comGet('content','Commentaire'); ?></textarea></p>

					<?php # Affichage du capcha anti-spam
					if($plxShow->plxMotor->aConf['capcha']): ?>
						<p><?php $plxShow->capchaQ(); ?>&nbsp;:&nbsp;<input name="rep" type="text" size="10" tabindex="5" id="rep" />
						<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" /></p>
					<?php endif; # Fin du if sur le capcha anti-spam ?>
					<p><input type="submit" id="submit-comment" tabindex="6" value="Envoyer" /></p>
		</form>


<div style="clear:both;"><!--IE6FIX--></div>

</div><!-- /Comment-Form -->
<?php endif; # Fin du if sur l'autorisation des commentaires ?>
</div><!-- /Comments-Body -->