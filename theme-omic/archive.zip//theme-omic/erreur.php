<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>

<!-- Posts Container -->     
<div id="posts-body">
<div class="post">

<!-- Post Tittle -->
<div class="post-title">
<h2>Une erreur a &eacute;t&eacute; d&eacute;tect&eacute;e :</h2>
</div><!-- /Post Tittle -->

<div style="clear:both;"><!--IE6FIX--></div>

<!-- Post Content Body -->
<div class="post-content-body">

<!-- Post Content -->
<div class="post-article">
			<p><?php $plxShow->erreurMessage(); ?><br />
			<a href="./" title="Accueil du site">Retour page d'accueil</a></p>
</div><!-- /Post Content -->

</div><!-- /Post Content Body -->

<!-- Post Footer -->
<div class="post-footer">
</div><!-- /Post Footer -->

<div style="clear:both;"><!--IE6FIX--></div>

<div style="clear:both;"><!--IE6FIX--></div>

</div><!-- /Posts Machanics -->

<div class="post-spacer"><!-- Spaces Objects --></div>

</div><!-- /Posts Container  -->


	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div><!-- /Content Shrink -->
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>