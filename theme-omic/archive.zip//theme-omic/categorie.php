<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>

<!-- Posts Container -->     
<div id="posts-body">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
<div class="post <?php echo $plxShow->artId() ?>">

<!-- Post Date -->
<div class="post-date">
<?php $plxShow->artDate('<span class="post-date-day">#num_day</span><span class="post-date-month">#month</span>'); ?>
</div><!-- /Post Date -->

<!-- Post Tittle -->
<div class="post-title">
<h2><?php $plxShow->artTitle('link'); ?></h2>
<span class="post-info">R&eacute;dig&eacute; par <?php $plxShow->artAuthor() ?> | Class&eacute; dans : <?php $plxShow->artCat(); ?></span>
</div><!-- /Post Tittle -->

<div style="clear:both;"><!--IE6FIX--></div>

<!-- Post Content Body -->
<div class="post-content-body">

<!-- Post Content -->
<div class="post-article">
<?php $plxShow->artChapo(); ?>
</div><!-- /Post Content -->

</div><!-- /Post Content Body -->

<!-- Post Footer -->
<div class="post-footer">
<span class="post-lower-info"><?php $plxShow->artNbCom(); ?> <span class="info_bottom">Mots cl&eacute;s : <?php $plxShow->artTags(); ?></span></span>
</div><!-- /Post Footer -->

<div style="clear:both;"><!--IE6FIX--></div>

<div style="clear:both;"><!--IE6FIX--></div>

</div><!-- /Posts Machanics -->
		<?php endwhile; # Fin de la boucle sur les articles ?>
		<?php # On affiche le fil Atom de cet article ?>
		<div class="feed_categorie"><?php $plxShow->artFeed('atom',$plxShow->catId()); ?></div>
		<?php # On affiche la pagination ?>
		    
<div class="page-navigation">
<?php $plxShow->pagination(); ?>
</div>
<div class="post-spacer"><!-- Spaces Objects --></div>

</div><!-- /Posts Container  -->


	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div><!-- /Content Shrink -->
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>