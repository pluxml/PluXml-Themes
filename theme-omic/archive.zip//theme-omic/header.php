<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<title><?php $plxShow->pageTitle(); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php $plxShow->charset(); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/style.css" media="screen" />
	<?php $plxShow->templateCss() ?>
	<link rel="alternate" type="application/atom+xml" title="Atom articles" href="<?php $plxShow->urlRewrite('feed.php?atom') ?>" />
	<link rel="alternate" type="application/rss+xml" title="Rss articles" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="<?php $plxShow->urlRewrite('feed.php?atom/commentaires') ?>" />
	<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
<!--[if lt IE 7.]>
<script defer type="text/javascript" src="<?php $plxShow->template(); ?>/pngfix.js"></script>
<![endif]-->
</head>

<body>
<!-- Header -->
<div id="header">
<div id="header-shrink">

<!-- Branding -->
<div id="branding-body">
<div id="logo">
<a href="./"><img src="<?php $plxShow->template(); ?>/images/Header-Logo.png" alt="<?php $plxShow->mainTitle(); ?>" /></a>
</div><!-- /Logo -->
<div id="branding">
<h1><?php $plxShow->mainTitle('link'); ?></h1>
<p><?php $plxShow->subTitle(); ?></p>
</div><!-- /Branding -->
</div><!-- /Branding Body -->

<!-- Banner Ad -->
<div id="banner-ad-body">
<a href="./"><img src="<?php $plxShow->template(); ?>/images/Ad-468X80.jpg" alt="Ad" /></a>
</div><!-- /Banner Ad -->

<!-- Navigation -->
<div id="navigation-bar">
<div id="navigation">
<ul>
	<?php $plxShow->staticList('Accueil','<li><a href="#static_url" class="#static_status" title="#static_name">#static_name</a></li>'); ?>
	<?php $plxShow->pageBlog('<li><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
</ul>
</div><!-- /Navigation -->
</div><!-- /Navigation-bar -->

</div><!-- /Header Shrink -->
</div><!-- /Header -->


<!-- Content -->
<div id="content">
<!-- Content Shrink -->
<div id="content-shrink">


<!-- Toolbar -->
<div id="toolbar-body">

<!-- Toolbar Feeds -->
<div id="toolbar-feeds">
<div class="feeds-body">
<div class="feeds-image"><img src="<?php $plxShow->template(); ?>/images/RSS-Icon.png" alt="Souscrire a <?php $plxShow->mainTitle(); ?>" /></div>
<div class="feeds-link"><a href="<?php $plxShow->urlRewrite('feed.php?atom') ?>" title="Fil Atom des articles">Articles</a></div>
</div>
<div class="feeds-body-alt">
<div class="feeds-image"><img src="<?php $plxShow->template(); ?>/images/RSS-Icon.png" alt="Souscrire a <?php $plxShow->mainTitle(); ?>" /></div>
<div class="feeds-link-alt"><a href="<?php $plxShow->urlRewrite('feed.php?atom/commentaires') ?>" title="Fil Atom des commentaires">Commentaires</a></div>
</div>
<div class="feeds-body-alt-2">
<div class="feeds-image"><img src="<?php $plxShow->template(); ?>/images/RSS-Email-Icon.png" alt="Souscrire a <?php $plxShow->mainTitle(); ?>" /></div>
<div class="feeds-link-alt-2"><a href="#">Souscrire par Mail</a></div>
</div>
</div><!-- /Toolbar Feeds -->

<!-- Toolbar Search -->
<div id="toolbar-search">
<form method="post" id="toolbar-searchform" action="<?php $plxShow->urlRewrite('/static4/recherche') ?>">
<div><input type="hidden" name="search" value="search"  /><input type="text" value="Rechercher..." onblur="if(this.value=='') this.value='Rechercher...';" onfocus="if(this.value=='Rechercher...') this.value='';" name="searchfield" id="toolbar-s" /></div>
<div><input id="toolbar-submit" type="image" src="<?php $plxShow->template(); ?>/images/GoButton.png" value="Go" /></div>
</form>
</div><!-- /Toolbar Search -->

</div><!-- /Toolbar -->