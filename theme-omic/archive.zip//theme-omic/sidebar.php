<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebars">

<!-- Center Sidebar -->
<div id="sidebar-center">

<!-- Sidebar Ads -->
<div id="sidebar-center-ads">
<img src="<?php $plxShow->template(); ?>/images/Ad-125x125.jpg" width="125" height="125" alt="Ad" title="Ad" />
<img src="<?php $plxShow->template(); ?>/images/Ad-125x125.jpg" width="125" height="125" alt="Ad" title="Ad" />
<img src="<?php $plxShow->template(); ?>/images/Ad-125x125.jpg" width="125" height="125" alt="Ad" title="Ad" />
<img src="<?php $plxShow->template(); ?>/images/Ad-125x125.jpg" width="125" height="125" alt="Ad" title="Ad" />
</div><!-- /Sidebar Ads -->

</div><!-- /Center Sidebar -->

<!-- Left Sidebar -->
<div id="sidebar-left">

<div class="sidebar-item-left">
<h2>Profile</h2>
<div class="textwidget">
<img src="<?php $plxShow->template(); ?>/images/Avatar.jpg" title="Avatar" alt="Avatar" width="80" height="80"/>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nunc in nibh. Etiam pellen my risus. Morbi a massa. Integer aliquet nunc ut mauris. Sed ornare turpis a ipsum. Nam in purus Pellentesque lacinia. <a href="#" title="Read More">Read more..</a></p>
</div>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

<div class="sidebar-item-left">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('','<li id="#cat_id" class="#cat_status"><a href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

<div class="sidebar-item-left">
        <h2>Archives</h2>
        <ul>
            <?php $plxShow->archList('<li id="#archives_id" class="#archives_status"><a href="#archives_url" title="#archives_name">#archives_name (#archives_nbart)</a></li>'); ?>
        </ul>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

<div class="sidebar-item-left">
		<h2>Derniers articles</h2>
		<ul>
			<?php $plxShow->lastArtList('<li class="#art_status"><a href="#art_url" title="#art_title">#art_title</a></li>'); ?>
		</ul>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

<div class="sidebar-item-left">
		<h2>Derniers commentaires</h2>
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author a dit : #com_content(34)</a></li>'); ?>
		</ul>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

<div class="sidebar-item-left">
		<h2>Mots cl&eacute;s</h2>
<div class="tag-cloud">
		<ul>
			<?php $plxShow->tagList('<li class="#tag_status"><a href="#tag_url" title="#tag_name">#tag_name</a></li>', 20); ?>
			<li class="last_li">&nbsp;</li>
		</ul>
</div>
<div style="clear:both;"><!--IE6FIX--></div>
</div>

</div><!-- /Left Sidebar -->

<div class="sidebars-spacer"><!-- Spaces Objects --></div>

</div><!-- /Sidebars -->