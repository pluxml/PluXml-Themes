<?php include(dirname(__FILE__).'/header.php'); ?>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="blog-post-area">
						<h2 class="title text-center"><?php $plxShow->catName(); ?></h2>						
						
						<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
							<div class="single-blog-post">
								<h3><?php $plxShow->artTitle('link'); ?></h3>
								<div class="post-meta">
									<ul>
										<li><i class="fa fa-user"></i> <?php $plxShow->artAuthor() ?></li>
										<li><i class="fa fa-clock-o"></i><?php $plxShow->artDate('#hour : #minute'); ?></li>
										<li><i class="fa fa-calendar"></i><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></li>
									</ul>
								</div>
								<a href="<?php $plxShow->artUrl(); ?>">
									<?php $plxShow->artThumbnail(); ?>
								</a>
								<?php $plxShow->artContent(); ?>
								<a  class="btn btn-primary" href="<?php $plxShow->artUrl(); ?>">Lire la suite</a>
							</div>
						<?php endwhile; ?>

						<div class="pagination-area">
							<ul class="pagination">
								<?php $plxGlob_arts = clone $plxShow->plxMotor->plxGlob_arts;
								$aFiles = $plxGlob_arts->query($plxShow->plxMotor->motif,'art','',0,false,'before');
								if($aFiles AND $plxShow->plxMotor->bypage AND sizeof($aFiles)>$plxShow->plxMotor->bypage) {
									$arg_url = $plxShow->plxMotor->get;
									if(preg_match('/(\/?page[0-9]+)$/',$arg_url,$capture)) {
										$arg_url = str_replace($capture[1], '', $arg_url);
									}
									$prev_page = $plxShow->plxMotor->page - 1;
									$next_page = $plxShow->plxMotor->page + 1;
									$last_page = ceil(sizeof($aFiles)/$plxShow->plxMotor->bypage);
									$f_url = $plxShow->plxMotor->urlRewrite('?'.$arg_url); # Premiere page
									$arg = (!empty($arg_url) AND $prev_page>1) ? $arg_url.'/' : $arg_url;
									$p_url = $plxShow->plxMotor->urlRewrite('?'.$arg.($prev_page<=1?'':'page'.$prev_page)); # Page precedente
									$arg = !empty($arg_url) ? $arg_url.'/' : $arg_url;
									$n_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$next_page); # Page suivante
									$l_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$last_page); # Derniere page
									if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowPagination'))) return;

									# On effectue l'affichage
									if($plxShow->plxMotor->page > 2) # Si la page active > 2 on affiche un lien 1ere page
										echo '
										<li>
											<a class="prev page-numbers" href="'.$f_url.'" title="'.L_PAGINATION_FIRST_TITLE.'">
												<i class="fa fa-angle-double-left"></i>
											</a>
										</li>';
									if($plxShow->plxMotor->page > 1) # Si la page active > 1 on affiche un lien page precedente
										echo '
										<li>
											<a class="prev page-numbers" href="'.$p_url.'" title="'.L_PAGINATION_PREVIOUS_TITLE.'">
												<i class="fa fa-angle-left"></i>
											</a>
										</li>';
									for ($i = 1; $i <= $last_page; $i++) {
										if ($i == $plxShow->plxMotor->page) {
											printf('
											<li>
												<a href="'.$plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$i).'" class="page-numbers active" >'.$plxShow->plxMotor->page).'</a>
											</li>';
										}else{
											echo '<li><a href="'.$plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$i).'" class="page-numbers" >'.$i.'</a></li>';
										}
									}
									if($plxShow->plxMotor->page < $last_page) # Si la page active < derniere page on affiche un lien page suivante
										echo '<li><a class="next page-numbers" href="'.$n_url.'" title="'.L_PAGINATION_NEXT_TITLE.'"><i class="fa fa-angle-right"></i></a></li>';
									if(($plxShow->plxMotor->page + 1) < $last_page) # Si la page active++ < derniere page on affiche un lien derniere page
										echo '<li><a class="next page-numbers" href="'.$l_url.'" title="'.L_PAGINATION_LAST_TITLE.'"><i class="fa fa-angle-double-right"></i></a></li>';
								} ?>
							</ul>
		
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
