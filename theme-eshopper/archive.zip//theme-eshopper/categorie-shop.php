<?php include(dirname(__FILE__).'/header.php'); 


function extraire($sujet='shop') {
	$plxMotor = plxMotor::getInstance();
	$contenu = $plxMotor->plxRecord_arts->f('content');
	if(strpos($contenu,'['.$sujet.']')!== false){
		$debut = stripos($contenu , '['.$sujet. ']') + strlen($sujet)+2;
		$fin = stripos($contenu , '[/'.$sujet.']');
		$chaine = substr($contenu,$debut,($fin-$debut));
		switch ($sujet) {
			case 'shop':
				return $chaine;
				break;
			case 'selection':
				$options = explode('||',$chaine);
				return $options;
				break;
			case 'sommaire':
				$lignes = explode('||',$chaine);
				return $lignes;
				break;
			case 'photoextra':
				$photos = explode('|',$chaine);
				return $photos;
				break;
		}
	}else{
		return false;
	}
}


?>
	<section id="advertisement">
		<div class="container">
			<img src="<?php $plxShow->template(); ?>/images/shop/advertisement.jpg" alt="" />
		</div>
	</section>
	<section>
		<div class="container">
			<div class="row">
				<?php include(dirname(__FILE__).'/sidebar-shop.php'); ?>
				<div class="col-sm-9 padding-right">
					<div class="features_items">
						<h2 class="title text-center"><?php $plxShow->catName(); ?></h2>
						<?php 
						while($plxShow->plxMotor->plxRecord_arts->loop()): 
							$currentPrice = $plxShow->plxMotor->plxRecord_arts->f('chapo');
							if(($choixMin <= $currentPrice) && ($currentPrice <= $choixMax)){ 
															$options = extraire('selection');
								if(isset($options[0])) {  ?>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=250&h=250&crop-to-fit" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" />
													<h2><?php $plxShow->artTitle(); ?></h2>
													<p><?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo').' '. $currencySymbol;?></p>
												</div>
												<div class="product-overlay">
													<div class="overlay-content">
														<div class="rating-div">
															<?php  $etoiles = intval($plxShow->plxMotor->plxRecord_arts->f('nb_com')); 
															if ($etoiles > 10) $etoiles = 10;
															$reste = 10 - $etoiles;
															while ($etoiles > 0){
																if ($etoiles == 1){ 
																	echo '<i class="fa fa-star-half-o"></i>';
																	$etoiles = $etoiles - 1;
																	$reste = $reste -1;
																}else{
																	echo '<i class="fa fa-star"></i>';
																	$etoiles = $etoiles - 2;
																}
															}
															while ($reste > 0){
																echo '<i class="fa fa-star-o"></i>';
																$reste = $reste - 2;
															} ?>
														</div>
														<a href="<?php $plxShow->artUrl(); ?>">
															<h2><?php $plxShow->artTitle(); ?></h2>
															<p><?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo').' '. $currencySymbol;?></p>
															<button class="btn btn-default add-to-cart" />Ajouter au panier <i class="fa fa-shopping-cart"></i></button>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>

								<?php }else{ ?>
							
								<form method="post" action="<?php echo $jcart->config['checkoutPath']; ?>" class="jcart">
									<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
									<input type="hidden" name="my-item-id" value="<?php echo $plxShow->artId() . '|option0|' . (float)$plxShow->plxMotor->plxRecord_arts->f('chapo'); ?>" />
									<input type="hidden" name="my-item-name" value="<?php $plxShow->artTitle(); ?>" />
									<input type="hidden" name="my-item-image" value="<?php $plxShow->artThumbnail('#img_url'); ?>" />
									<input type="hidden" name="my-item-price" value="<?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo');?>" />
									<input type="hidden" name="my-item-url" value="<?php echo $plxShow->artUrl(); ?>" />
									<input type="hidden" name="my-item-qty" value="1" />
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=250&h=250&crop-to-fit" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" />
													<h2><?php $plxShow->artTitle(); ?></h2>
													<p><?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo').' '. $currencySymbol;?></p>
												</div>
												<div class="product-overlay">
													<div class="overlay-content">
														<div class="rating-div">
															<?php  $etoiles = intval($plxShow->plxMotor->plxRecord_arts->f('nb_com')); 
															if ($etoiles > 10) $etoiles = 10;
															$reste = 10 - $etoiles;
															while ($etoiles > 0){
																if ($etoiles == 1){ 
																	echo '<i class="fa fa-star-half-o"></i>';
																	$etoiles = $etoiles - 1;
																	$reste = $reste -1;
																}else{
																	echo '<i class="fa fa-star"></i>';
																	$etoiles = $etoiles - 2;
																}
															}
															while ($reste > 0){
																echo '<i class="fa fa-star-o"></i>';
																$reste = $reste - 2;
															} ?>
														</div>
														<a href="<?php $plxShow->artUrl(); ?>">
															<h2><?php $plxShow->artTitle(); ?></h2>
															<p><?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo').' '. $currencySymbol;?></p>
														</a>
														<button type="submit" name="my-add-button" value="Ajouter au panier" class="btn btn-default add-to-cart" />Ajouter au panier <i class="fa fa-shopping-cart"></i></button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</form>
								<?php 
								}
							}
							endwhile; 
							?>
						<div class="pagination-area">
							<ul class="pagination">
								<?php $plxGlob_arts = clone $plxShow->plxMotor->plxGlob_arts;
								$aFiles = $plxGlob_arts->query($plxShow->plxMotor->motif,'art','',0,false,'before');
								if($aFiles AND $plxShow->plxMotor->bypage AND sizeof($aFiles)>$plxShow->plxMotor->bypage) {
									$arg_url = $plxShow->plxMotor->get;
									if(preg_match('/(\/?page[0-9]+)$/',$arg_url,$capture)) {
										$arg_url = str_replace($capture[1], '', $arg_url);
									}
									$prev_page = $plxShow->plxMotor->page - 1;
									$next_page = $plxShow->plxMotor->page + 1;
									$last_page = ceil(sizeof($aFiles)/$plxShow->plxMotor->bypage);
									$f_url = $plxShow->plxMotor->urlRewrite('?'.$arg_url); # Premiere page
									$arg = (!empty($arg_url) AND $prev_page>1) ? $arg_url.'/' : $arg_url;
									$p_url = $plxShow->plxMotor->urlRewrite('?'.$arg.($prev_page<=1?'':'page'.$prev_page)); # Page precedente
									$arg = !empty($arg_url) ? $arg_url.'/' : $arg_url;
									$n_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$next_page); # Page suivante
									$l_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$last_page); # Derniere page
									if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowPagination'))) return;

									# On effectue l'affichage
									if($plxShow->plxMotor->page > 2) # Si la page active > 2 on affiche un lien 1ere page
										echo '
										<li>
											<a class="prev page-numbers" href="'.$f_url.'" title="'.L_PAGINATION_FIRST_TITLE.'">
												<i class="fa fa-angle-double-left"></i>
											</a>
										</li>';
									if($plxShow->plxMotor->page > 1) # Si la page active > 1 on affiche un lien page precedente
										echo '
										<li>
											<a class="prev page-numbers" href="'.$p_url.'" title="'.L_PAGINATION_PREVIOUS_TITLE.'">
												<i class="fa fa-angle-left"></i>
											</a>
										</li>';
									for ($i = 1; $i <= $last_page; $i++) {
										if ($i == $plxShow->plxMotor->page) {
											printf('
											<li>
												<a href="'.$plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$i).'" class="page-numbers active" >'.$plxShow->plxMotor->page).'</a>
											</li>';
										}else{
											echo '<li><a href="'.$plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$i).'" class="page-numbers" >'.$i.'</a></li>';
										}
									}
									if($plxShow->plxMotor->page < $last_page) # Si la page active < derniere page on affiche un lien page suivante
										echo '<li><a class="next page-numbers" href="'.$n_url.'" title="'.L_PAGINATION_NEXT_TITLE.'"><i class="fa fa-angle-right"></i></a></li>';
									if(($plxShow->plxMotor->page + 1) < $last_page) # Si la page active++ < derniere page on affiche un lien derniere page
										echo '<li><a class="next page-numbers" href="'.$l_url.'" title="'.L_PAGINATION_LAST_TITLE.'"><i class="fa fa-angle-double-right"></i></a></li>';
								} ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php include(dirname(__FILE__).'/footer.php'); ?>
