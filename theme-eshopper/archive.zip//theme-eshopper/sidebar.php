<?php if(!defined('PLX_ROOT')) exit; ?>

	<div class="col-sm-3">
		<div class="left-sidebar">
				<h2><?php $plxShow->lang('CATEGORIES'); ?></h2>
				<div class="panel-group category-products">
					<?php $plxShow->catList('','
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a href="#cat_url">#cat_name</a></h4>
						</div>
					</div>',implode('|',$categorieBlogue)); ?>
				</div>

				<div class="brands_products">
					<h2><?php $plxShow->lang('TAGS'); ?></h2>
					<div class="custom-side-box-div" style="color: #696763;">
						<?php 
						$format='<a href="#tag_url" title="#tag_name" style="font-size: #tag_sizeem; color: #696763;"  onMouseOver="this.style.color=\'#FE980F\'" onMouseOut="this.style.color=\'#696763\'">#tag_name</a>';
						$max=''; 
						$order='';
						$datetime = date('YmdHi');
						$array=array();
						$alphasort=array();
						$plxMotor = plxMotor::getInstance();
						$plxPlugin = $plxMotor->plxPlugins->callHook('plxShowTagList');
						if($plxShow->plxMotor->aTags) {
							foreach($plxShow->plxMotor->aTags as $idart => $tag) {
								if(isset($plxShow->plxMotor->activeArts[$idart]) AND $tag['date']<=$datetime AND $tag['active']) {
									if($tags = array_map('trim', explode(',', $tag['tags']))) {
										foreach($tags as $tag) {
											if($tag!='') {
												$t = plxUtils::title2url($tag);
												if(!isset($array['_'.$tag])) {
													$array['_'.$tag]=array('name'=>$tag,'url'=>$t,'count'=>1);
												}
												else
													$array['_'.$tag]['count']++;
												if(!in_array($t, $alphasort))
													$alphasort[] = $t; # pour le tri alpha
											}
										}
									}
								}
							}
							if($max!='') $array=array_slice($array, 0, intval($max), true);
							switch($order) {
								case 'alpha':
									if($alphasort) array_multisort($alphasort, SORT_ASC, $array);
									break;
								case 'random':
									$arr_elem = array();
									$keys = array_keys($array);
									shuffle($keys);
									foreach ($keys as $key) {
										$arr_elem[$key] = $array[$key];
									}
									$array = $arr_elem;
									break;
							}
						}
						$size=0;
						foreach($array as $tagname => $tag) {
							$name = str_replace('#tag_id','tag-'.$size++,$format);
							$name = str_replace('#tag_size',($tag['count']>10?'max':(0.6+$tag['count']/5)),$name);
							$name = str_replace('#tag_count',$tag['count'],$name);
							$name = str_replace('#tag_item',$tag['url'],$name);
							$name = str_replace('#tag_url',$plxShow->plxMotor->urlRewrite('?tag/'.$tag['url']),$name);
							$name = str_replace('#tag_name',plxUtils::strCheck($tag['name']),$name);
							$name = str_replace('#nb_art',$tag['count'],$name);
							$name = str_replace('#tag_status',(($plxShow->plxMotor->mode=='tags' AND $plxShow->plxMotor->cible==$tag['url'])?'active':'noactive'), $name);
							echo $name.' ';
						}	?>
					</div>
				</div>				
				
				<h2>Nos produits</h2>
				<div class="panel-group category-products">
					<?php $plxShow->catList('','
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a href="#cat_url">#cat_name</a></h4>
						</div>
					</div>',implode('|',$categoriesBoutique)); ?>
				</div>
						
				<div class="brands_products">
					<h2>Marques</h2>
					<div class="brands-name">
						<ul class="nav nav-pills nav-stacked">
							<?php $plxShow->catList('','
							<li id="#cat_id">
								<a class="#cat_status" href="#cat_url"> 
									<span class="pull-right">(#art_nb)</span>
									#cat_name
								</a>
							</li>',implode('|',$categoriesMarques)); ?>
						</ul> 
					</div>
				</div>
				<div class="shipping text-center" style="margin-bottom: 40px;">
					<img src="<?php $plxShow->template(); ?>/images/home/shipping.jpg" alt="" />
				</div>
			</div>
		</div>
