<?php if (!defined('PLX_ROOT')) exit; ?>

	<footer id="footer">
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>e</span>-shopper</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						
						<?php $plxShow->lastArtList('
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#art_url">
									<div class="iframe-img">
										<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=129&h=57&crop-to-fit" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>#art_title</p>
								<h2>#num_day #month #num_year(4)</h2>
							</div>
						</div>',4,$categorieBlogue); ?>
						
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="<?php $plxShow->template(); ?>/images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2><?php $plxShow->lang('CATEGORIES'); ?></h2>
							<ul class="nav nav-pills nav-stacked">
								<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a></li>'); ?>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
							<ul class="nav nav-pills nav-stacked">
								<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2><?php $plxShow->lang('LATEST_COMMENTS'); ?></h2>
							<ul class="nav nav-pills nav-stacked">
								<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2><?php $plxShow->lang('ARCHIVES'); ?></h2>
							<ul class="nav nav-pills nav-stacked">
								<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a></li>'); ?>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>À propos de notre boutique</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Votre courriel" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Suivez nos plus récentes nouvelles<br />avec notre infolettre...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">&copy; <?php echo date("Y"); ?> <span><?php $plxShow->mainTitle('link'); ?></span> - 
						<?php $plxShow->subTitle(); ?> - 
						<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<span><a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</span></a>
						<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp;
						<?php $plxShow->httpEncoding() ?>
					</p>
					<p class="pull-right">Design par <span><a target="_blank" href="http://demo.themeum.com/html/eshopper/">Themeum</a></span></p>
				</div>
			</div>
		</div>
		
	</footer>
    <script src="<?php $plxShow->template(); ?>/js/jquery.js"></script>
	<script src="<?php $plxShow->template(); ?>/js/bootstrap.min.js"></script>
	<script src="<?php// $plxShow->template(); ?>/js/jquery.scrollUp.min.js"></script>
	<script src="<?php $plxShow->template(); ?>/js/price-range.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/jquery.prettyPhoto.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/main.js"></script>
</body>
</html>

