<?php include(dirname(__FILE__).'/header.php'); ?>

	<section id="slider">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol>
						<div class="carousel-inner">
							<?php 
							$item = 0;
							while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
								<div class="item <?php if($item == 0) echo ' active'; ?>">
									<div class="col-sm-6">
										<h1><span><?php $plxShow->artTitle(); ?></span></h1>
										<h2>100% Responsive Design</h2>
										<p><?php $plxShow->artContent(); ?></p>
										<button type="button" class="btn btn-default get" onClick="parent.location='<?php $plxShow->artUrl(); ?>'">Voir la page</button>
									</div>
									<div class="col-sm-6">
										<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=484&h=441&crop-to-fit" class="img-responsive" >
										<!--img src="/images/home/pricing.png"  class="pricing" alt="" /-->
									</div>
								</div>
							<?php 
							$item = $item+1;
							endwhile; ?>
						</div>
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev"><i class="fa fa-angle-left"></i></a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next"><i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section>
		<div class="container">
			<div class="row">
			
				<?php include(dirname(__FILE__).'/sidebar.php'); ?>

				<div class="col-sm-9 padding-right">
					<div class="features_items">
						<h2 class="title text-center">Visitez notre boutique</h2>
						<?php $plxShow->lastArtList('
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=255&h=237&crop-to-fit" alt="" />
										<h2>#art_chapo '.$currencySymbol.'</h2>
										<p>#art_title</p>
									</div>
									<div class="product-overlay">
										<div class="overlay-content">
											<h2>#art_chapo</h2>
											<p>#art_title</p>
										</div>
									</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#art_url"><i class="fa fa-plus-square"></i>Voir les détails</a></li>
									</ul>
								</div>
							</div>
						</div>',6,$entreeBoutique[0]); ?>
					</div>
				
					<div class="category-tab">
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<?php 	
								$plxMotor = plxMotor::getInstance();
								$include = implode ('|',$categoriesBoutique);
								$exclude='';
									if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowLastCatList'))) return;
									if($plxShow->plxMotor->aCats) {
										foreach($plxShow->plxMotor->aCats as $k=>$v) {
											$in = (empty($include) OR preg_match('/('.$include.')/', $k));
											$ex = (!empty($exclude) AND preg_match('/('.$exclude.')/', $k));
											if($in AND !$ex) {
												if(($v['articles']>0 OR $plxShow->plxMotor->aConf['display_empty_cat']) AND ($v['menu']=='oui') AND $v['active']) { # On a des articles
													echo '<li'.(intval($k)==$categoriesBoutique[0]? ' class="active"':'') . '>
															<a href="#'.$v['url'].'" data-toggle="tab">'. plxUtils::strCheck($v['name']) . '</a>
														</li>';
												}
											}
										}
										echo '</ul>
										</div>
										<div class="tab-content">';
										foreach($plxShow->plxMotor->aCats as $k=>$v) {
											$in = (empty($include) OR preg_match('/('.$include.')/', $k));
											$ex = (!empty($exclude) AND preg_match('/('.$exclude.')/', $k));
											if($in AND !$ex) {
												if(($v['articles']>0 OR $plxShow->plxMotor->aConf['display_empty_cat']) AND ($v['menu']=='oui') AND $v['active']) { # On a des articles
													echo '<div class="tab-pane fade '.(intval($k)==$categoriesBoutique[0]? ' active ':'') . ' in" id="'.$v['url'].'">';
														$plxShow->lastArtList('
														<div class="col-sm-3">
															<div class="product-image-wrapper">
																<div class="single-products">
																	<div class="productinfo text-center">
																		<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=185&h=162&crop-to-fit" alt="#img_alt" />
																		<h2>#art_chapo '.$currencySymbol.'</h2>
																		<p>#art_title</p>
																		<a href="#art_url" class="btn btn-default add-to-cart">
																			<i class="fa fa-shopping-cart"></i>
																			Ajouter au panier
																		</a>
																	</div>
																</div>
															</div>
														</div>',4,intval($k));	
												echo '</div>';
												}
											}
										}
									}
								?>
							</div>
						</div>
						
						<div class="recommended_items">
							<h2 class="title text-center">Des marques renommées</h2>
							<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
								<div class="carousel-inner">
									<?php 	
									$plxMotor = plxMotor::getInstance();
									$include = implode ('|',$categoriesMarques);
									$exclude='';
										if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowLastCatList'))) return;
										if($plxShow->plxMotor->aCats) {
											foreach($plxShow->plxMotor->aCats as $k=>$v) {
												$in = (empty($include) OR preg_match('/('.$include.')/', $k));
												$ex = (!empty($exclude) AND preg_match('/('.$exclude.')/', $k));
												if($in AND !$ex) {
													if(($v['articles']>0 OR $plxShow->plxMotor->aConf['display_empty_cat']) AND ($v['menu']=='oui') AND $v['active']) { # On a des articles
														echo '<div class="item '.(intval($k)==$categoriesMarques[0]? ' active ':'') . '">';
															$plxShow->lastArtList('
															<div class="col-sm-4">
																<div class="product-image-wrapper">
																	<div class="single-products">
																		<div class="productinfo text-center">
																			<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=255&h=128&crop-to-fit" alt="#img_alt" />
																			<h2>#art_chapo '.$currencySymbol.'</h2>
																			<p>#art_title</p>
																			<a href="#art_url" class="btn btn-default add-to-cart">
																				<i class="fa fa-shopping-cart"></i>
																				Ajouter au panier
																			</a>
																		</div>
																		
																	</div>
																</div>
															</div>',4,intval($k));	
													echo '</div>';
													}
												}
											}
										}
									?>
									</div>
									 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
										<i class="fa fa-angle-left"></i>
									  </a>
									  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
										<i class="fa fa-angle-right"></i>
									  </a>			
								</div>
							</div>
						</div>
					</div>
				</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
