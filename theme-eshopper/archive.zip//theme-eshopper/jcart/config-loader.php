<?php

// jCart v1.3
// http://conceptlogic.com/jcart/

// By default, this file returns the $config array for use with PHP scripts
// If requested via Ajax, the array is encoded as JSON and echoed out to the browser

// Don't edit here, edit config.php
include_once('themes/theme-eshopper/jcart/config.php');

// Use default values for any settings that have been left empty
if (!$config['currencyCode']) $config['currencyCode']                     = 'GBP';
if (!$config['text']['cartTitle']) $config['text']['cartTitle']           = 'Panier d\'achat';
if (!$config['text']['singleItem']) $config['text']['singleItem']         = 'item';
if (!$config['text']['multipleItems']) $config['text']['multipleItems']   = 'items';
if (!$config['text']['subtotal']) $config['text']['subtotal']             = 'Sous-total';
if (!$config['text']['update']) $config['text']['update']                 = 'Rafraîchir';
if (!$config['text']['checkout']) $config['text']['checkout']             = 'Panier';
if (!$config['text']['checkoutPaypal']) $config['text']['checkoutPaypal'] = 'Régler avec PayPal';
if (!$config['text']['removeLink']) $config['text']['removeLink']         = 'Retirer';
if (!$config['text']['emptyButton']) $config['text']['emptyButton']       = 'Vider';
if (!$config['text']['emptyMessage']) $config['text']['emptyMessage']     = 'Votre panier est vide!';
if (!$config['text']['itemAdded']) $config['text']['itemAdded']           = 'Item ajouté!';
if (!$config['text']['priceError']) $config['text']['priceError']         = 'Formar de prix non valide!';
if (!$config['text']['quantityError']) $config['text']['quantityError']   = 'Les quantités doivent être en nombre entier!';
if (!$config['text']['checkoutError']) $config['text']['checkoutError']   = 'Votre commande n\'a pas pu être complétée!';

if ($_GET['ajax'] == 'true') {
	header('Content-type: application/json; charset=utf-8');
	echo json_encode($config);
}
?>