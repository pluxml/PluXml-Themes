<?php if(!defined('PLX_ROOT')) exit; ?>

	<div class="col-sm-3">
		<div class="left-sidebar">
				<h2><?php $plxShow->lang('CATEGORIES'); ?></h2>
				<div class="panel-group category-products">
					<?php $plxShow->catList('','
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a href="#cat_url">#cat_name</a></h4>
						</div>
					</div>',implode('|',$categoriesBoutique)); ?>
				</div>
						
				<div class="brands_products">
					<h2>Marques</h2>
					<div class="brands-name">
						<ul class="nav nav-pills nav-stacked">
							<?php $plxShow->catList('','
							<li id="#cat_id">
								<a class="#cat_status" href="#cat_url"> 
									<span class="pull-right">(#art_nb)</span>
									#cat_name
								</a>
							</li>',implode('|',$categoriesMarques)); ?>
						</ul> 
					</div>
				</div>

				<?php 
				if($plxShow->plxMotor->mode == 'categorie') {
				
				if(isset($_POST['sl2'])) { 
					$choixMinMax = $_POST['sl2'];						
					$choixMin =  intval(substr($choixMinMax, 0, strpos($choixMinMax , ',')));		
					$choixMax =  intval(substr($choixMinMax, strpos($choixMinMax , ',')+1));		
					$absoluteMin = $choixMax;
					$absoluteMax = $choixMin;
				}else{
					$absoluteMin=0;
					$absoluteMax=500;
					$choixMin = 0;
					$choixMax = 500;
				}
				while($plxShow->plxMotor->plxRecord_arts->loop()){ 
					$currentMin=intval($plxShow->plxMotor->plxRecord_arts->f('chapo'));
					if($currentMin < $absoluteMin) { 
						$absoluteMin=$currentMin;
					}
					$currentMax=intval($plxShow->plxMotor->plxRecord_arts->f('chapo'));
					if($currentMax > $absoluteMax) { 
						$absoluteMax=$currentMax;
					}
				}

				$currentCat = $plxShow->catId();?>
				<div class="price-range">
					<h2>Prix</h2>
					<div class="well"> 
						<form method="post" action="<?php echo $plxShow->catUrl(); ?>">
							 <input type="text" class="span2" value="" 
							 data-slider-min="<?php echo $absoluteMin;?>" 
							 data-slider-max="<?php echo $absoluteMax;?>" 
							 data-slider-step="1" 
							 data-slider-value="[<?php echo $choixMin;?>,<?php echo $choixMax;?>]" 
							 id="sl2" name="sl2">
							 <br />
							 <b><?php echo $absoluteMin . ' ' .$currencySymbol; ?></b> 
							 <b class="pull-right"> <?php echo $absoluteMax . ' ' .$currencySymbol; ?></b>
							<br>
							<button type="submit" class="btn btn-default get">Rafraîchir</button>
						</form>
					</div>
				</div>
			<?php
			} ?>			

			<div class="shipping text-center" style="margin-bottom:25px;">
				<img src="<?php $plxShow->template(); ?>/images/home/shipping.jpg" alt="" />
			</div>
			
		</div>
	</div>
