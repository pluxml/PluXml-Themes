<?php include(dirname(__FILE__).'/header.php'); 

function extraire($sujet='shop') {
	$plxMotor = plxMotor::getInstance();
	$contenu = $plxMotor->plxRecord_arts->f('content');
	if(strpos($contenu,'['.$sujet.']')!== false){
		$debut = stripos($contenu , '['.$sujet. ']') + strlen($sujet)+2;
		$fin = stripos($contenu , '[/'.$sujet.']');
		$chaine = substr($contenu,$debut,($fin-$debut));
		switch ($sujet) {
			case 'shop':
				return $chaine;
				break;
			case 'selection':
				$options = explode('||',$chaine);
				return $options;
				break;
			case 'sommaire':
				$lignes = explode('||',$chaine);
				return $lignes;
				break;
			case 'photoextra':
				$photos = explode('|',$chaine);
				return $photos;
				break;
		}
	}else{
		return false;
	}
}

function contenuArticle($sujet='shop') {
	$plxMotor = plxMotor::getInstance();
	$contenu = $plxMotor->plxRecord_arts->f('content');
	if(strpos($contenu,'['.$sujet.']')!== false){
		$debut = stripos($contenu , '['.$sujet. ']') + strlen($sujet)+2;
		$fin = stripos($contenu , '[/'.$sujet.']');
		$chaine = '[shop]'.substr($contenu,$debut,($fin-$debut)).'[/shop]';
		$artContent = str_replace($chaine,'',$contenu); 
		return $artContent;
	}else{
		return false;
	}
} ?>
 
<section>
	<div class="container">
		<div class="row">
			<?php include(dirname(__FILE__).'/sidebar-shop.php'); ?>
			<div class="col-sm-9 padding-right">
				<div class="product-details">
					<div class="col-sm-5">
						<?php 
						$photos = extraire('photoextra');
						if($photos =='') {  // aucune photo supplémentaire, seulement l'image d'accroche
							?>
							<div class="view-product"> 
									<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=329&h=380&crop-to-fit" title="<?php $plxShow->artThumbnail('#img_title'); ?>" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>">
									<h3><?php $plxShow->artThumbnail('#img_title'); ?></h3>
							</div> 
							<?php
						}else {  // au moins une photo supplémentaire est disponible	
							array_unshift($photos,$plxShow->plxMotor->plxRecord_arts->f('thumbnail'));    // on ajoute l'image d'accroche au début de la liste, peu importe sa longueur
							$currentPhotoNumber=0;
							if(isset($_GET['photoextra'])) {  //  nous ne sommes pas à la première image, l'url contient un pointeur vers une autre de la liste 
								$currentPhotoNumber=$_GET['photoextra']; 
							} ?>
							<div class="view-product">
								<img src="<?php $plxShow->template(); ?>/img.php?src=<?php echo $plxShow->plxMotor->racine . $photos[$currentPhotoNumber];?>&w=329&h=380&crop-to-fit" title="<?php $plxShow->artThumbnail('#img_title'); ?>" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>">
								<h3><?php $plxShow->artThumbnail('#img_title'); ?></h3>
							</div> 
							<div id="similar-product" class="carousel slide" data-ride="carousel">
								<div class="carousel-inner">
									<?php 
									$i=0;
									while ($i<= count($photos)-1){
										for ($j = 1; $j <= (count($photos)/3); $j++) {
											if ($i<= count($photos)-1){ ?>
												<div class="item <?php if($i == 0){echo ' active';} ?>">
													<?php 
													for ($k = 1; $k <= 3; $k++) { 
														if ($i<= count($photos)-1){ ?>
															<a href="index.php?article<?php echo $plxShow->artId().'/'. $plxShow->plxMotor->plxRecord_arts->f('url'). '&photoextra='.$i;?>">
																<img src="<?php $plxShow->template(); ?>/img.php?src=<?php echo $plxShow->plxMotor->racine . $photos[$i];?>&w=85&h=85&crop-to-fit" >
															</a>
															<?php 
															$i=$i+1;
														 }
													 } ?>
												</div>
											<?php  
											}	
										}
									} ?>
								</div>
								<?php if (count($photos)>3){ ?>
									<a class="left item-control" href="#similar-product" data-slide="prev">
										<i class="fa fa-angle-left"></i>
									</a>
									<a class="right item-control" href="#similar-product" data-slide="next">
										<i class="fa fa-angle-right"></i>
									</a> 
								<?php } ?>
							</div>
							<?php } ?>
					</div>
					<div class="col-sm-7">
						<div class="product-information">
							<form method="post" action="<?php echo $jcart->config['checkoutPath']; ?>" class="jcart">
								<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
								<?php if(isset($_GET['my-item-option'])){ 
									$optionChoisie = $_GET['my-item-option'];
								}else{
									$optionChoisie = 0;
								} ?>
								<input type="hidden" name="my-item-name" value="<?php $plxShow->artTitle(); ?>" />
								<input type="hidden" name="my-item-image" value="<?php $plxShow->artThumbnail('#img_url'); ?>" />
								<input type="hidden" name="my-item-price" value="<?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo');?>" />
								<input type="hidden" name="my-item-url" value="<?php echo $plxShow->artUrl(); ?>" />

								<img src="<?php $plxShow->template(); ?>/images/product-details/new.jpg" class="newarrival" alt="" />
								<h2><?php $plxShow->artTitle(); ?></h2>
								<p>No de produit: <?php echo $plxShow->artId(); ?></p>
								<div class="rating-div">
									<?php  $etoiles = intval($plxShow->plxMotor->plxRecord_arts->f('nb_com')); 
									if ($etoiles > 10) $etoiles = 10;
									$reste = 10 - $etoiles;
									while ($etoiles > 0){
										if ($etoiles == 1){ 
											echo '<i class="fa fa-star-half-o" style="color:#FE980F;"></i>';
											$etoiles = $etoiles - 1;
											$reste = $reste -1;
										}else{
											echo '<i class="fa fa-star" style="color:#FE980F;"></i>';
											$etoiles = $etoiles - 2;
										}
									}
									while ($reste > 0){
										echo '<i class="fa fa-star-o" style="color:#FE980F;"></i>';
										$reste = $reste - 2;
									} ?>
								</div>
								<span>
									<span><?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo').' '. $currencySymbol;?></span>
									<label>Qté:</label>
									<input type="text" name="my-item-qty" value="1" />
									<button type="submit" name="my-add-button" value="Ajouter au panier" class="btn btn-fefault cart" />
										Ajouter au panier <i class="fa fa-shopping-cart"></i>
									</button>
								</span>

								<?php $options = extraire('selection');
								if(isset($options[0])) {  
									echo '<p>
										<select name="my-item-id">';
											foreach ($options as $option){
												$choix = explode('|',$option);
												echo '<option value="'.$plxShow->artId().'|'.$choix[0].'|'.$jcart->calculate_string((float)$plxShow->plxMotor->plxRecord_arts->f('chapo') . $choix[1]).'">'. $choix[0].'</option>';
											}
										echo '</select>
									</p>';
								}else{
									echo '<input type="hidden" name="my-item-id" value="'.$plxShow->artId() . '|option0|' . $plxShow->plxMotor->plxRecord_arts->f('chapo') . '">';
								}
								$listeSommaire = extraire('sommaire');
								foreach ($listeSommaire as $ligne){
									$items = explode('|',$ligne);
									echo '<p><b>'.$items[0].' :</b> ' . $items[1] .'</p>';
								} ?>
							</form>
							<a href="liens-vers-chacun-des-reseaux-sociaux.html">
								<img src="<?php $plxShow->template(); ?>/images/product-details/share.png" class="share img-responsive"  alt="" />
							</a>
						</div>
					</div>
				</div>
				<div class="category-tab shop-details-tab">
					<div class="col-sm-12">
						<ul class="nav nav-tabs">
							<li class="active"><a href="#details" data-toggle="tab">Détails</a></li>
							<li><a href="#tags" data-toggle="tab"><?php $plxShow->lang('TAGS'); ?></a></li>
							<li><a href="#reviews" data-toggle="tab"><?php $plxShow->artNbCom(); ?></a></li>
						</ul>
					</div>
					<div class="tab-content">
						<div class="tab-pane fade active in" id="details">
							<div class="col-sm-12">
								<ul>
									<li><a href=""><i class="fa fa-user"></i><?php $plxShow->artAuthor() ?></a></li>
									<li><a href=""><i class="fa fa-clock-o"></i><?php $plxShow->artDate('#hour : #minute'); ?></a></li>
									<li><a href=""><i class="fa fa-calendar-o"></i><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></a></li>
								</ul>
								<?php 
								echo contenuArticle(); ?>
							</div>
						</div>
						<div class="tab-pane fade" id="tags">
							<div class="custom-page-box-border-less-div">
								<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
							</div>
						</div>
						<div class="tab-pane fade" id="reviews">
							<div class="col-sm-12">
								<?php include(dirname(__FILE__).'/commentaires.php'); ?>
							</div>
						</div>
					</div>
				</div>				
				<div class="recommended_items">
					<h2 class="title text-center">Vous aimerez aussi</h2>
					<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="item active">	
							<?php $plxShow->lastArtList('
								<div class="col-sm-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<a href="#art_url">
												<img src="#img_url" alt="#img_alt" />
												<h2>#art_chapo '.$currencySymbol.'</h2>
												<p>#art_title</p>
												</a>
											</div>
										</div>
									</div>
								</div>',3,'11'); ?>
							</div>
						</div>
						 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						  </a>
						  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
							<i class="fa fa-angle-right"></i>
						  </a>			
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
