<?php include(dirname(__FILE__).'/header.php'); ?>

<section>
	<div class="container">
		<div class="row">

			<?php include(dirname(__FILE__).'/sidebar.php'); ?>

			<div class="col-sm-9">
				<div class="blog-post-area">
					<h2 class="title text-center"><?php $plxShow->staticTitle(); ?></h2>
					<div class="single-blog-post">
						<?php $plxShow->staticContent(); ?>
					</div>
				</div>
			</div>	
		</div>
	</div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>

