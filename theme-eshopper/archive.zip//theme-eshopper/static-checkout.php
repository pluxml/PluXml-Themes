<?php include(dirname(__FILE__) . '/header.php'); ?>

	<section id="cart_items">
		<div class="container">

			<?php $jcart->display_cart();?>

		</div>
	</section>


<?php include(dirname(__FILE__).'/footer.php'); ?>

