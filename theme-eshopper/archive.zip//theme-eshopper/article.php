<?php include(dirname(__FILE__).'/header.php'); ?>

<section>
	<div class="container">
		<div class="row">

			<?php include(dirname(__FILE__).'/sidebar.php'); ?>

			<div class="col-sm-9">
				<div class="blog-post-area">
					<h2 class="title text-center"><?php $plxShow->artTitle(); ?></h2>
					<div class="single-blog-post">
						<h4><?php $plxShow->artChapo(''); ?></h4>
						<div class="post-meta">
							<ul>
								<li><i class="fa fa-user"></i> <?php $plxShow->artAuthor() ?></li>
								<li><i class="fa fa-clock-o"></i><?php $plxShow->artDate('#hour : #minute'); ?></li>
								<li><i class="fa fa-calendar"></i><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></li>
							</ul>
						</div>

						<img src="<?php $plxShow->artThumbnail('#img_url'); ?>" width="100%" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>">
						
						<?php $plxShow->artContent('false'); ?>
						<div class="rating-area">
							<ul class="tag">
								<li><?php $plxShow->lang('TAGS') ?>:</li>
								<?php $plxShow->artTags($format='<li><a class="color #tag_status" href="#tag_url">#tag_name <span>/</span></a></li>', $separator='/'); ?>
							</ul>
						</div>
					</div>
				</div>

				<div class="col-sm-12">
					<?php include(dirname(__FILE__).'/commentaires.php'); ?>
				</div>
				
			</div>	
		</div>
	</div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
