<?php if(!defined('PLX_ROOT')) exit; ?>

<style>
	.level-0 {
		margin-left: 0;
	}
	.level-1 {
		margin-left: 5%;
		width: 95%;
	}
	.level-2 {
		margin-left: 10%;
		width: 90%;
	}
	.level-3 {
		margin-left: 15%;
		width: 85%;
	}
	.level-4 {
		margin-left: 20%;
		width: 80%;
	}
	.level-5,
	.level-max {
		margin-left: 25%;
		width: 75%;
	}

	.capcha-letter, .capcha-word {
		float: left;
		font-weight: bold;
	}
	.capcha-word {
		float: left;
		border: 1px solid #FE980F;
		background-color: #fff;
		letter-spacing: 0.3em;
		padding: .525rem .7rem;
	}

	.post-meta span{
		float: left;
	}

	.replay-box, .replay-box #form {
		margin-top: 0px;
		margin-bottom: 0px;
	}

	.replay-box span {
		color: #FE980F;
		float: none;
		font-weight: 700;
		margin-top: 21px;
	}

	#reviews form span {
		display: inline;
	}

	.text-area {
		margin-top: 0px;
	}


	#reviews textarea {
		border: 1px solid #F7F7F0;
		color: #ADB2B2;
		background-color: #FFF;
		font-size: 12px;
		margin-top: 0px;
		margin-bottom: 22px;
		padding: 8px;
		width: 100%;
	}

	#reviews textarea:hover {
		border: 1px solid #FE980F;
	}


	.response-area .media img{
	  height: 82px;
	  width: 60px;
	}
</style>

<?php if($plxShow->plxMotor->plxRecord_coms): ?>
	<div class="response-area">
		<h2><?php echo $plxShow->artNbCom(); ?></h2>
		<ul class="media-list">
		<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
			<li class="media <?php $plxShow->comLevel(); ?>">
				<a class="pull-left" href="#">
					<img class="media-object" src="<?php $plxShow->template(); ?>/images/blog/generic-avatar.jpg" alt="">
				</a>
				<div id="<?php $plxShow->comId(); ?>" class="media-body ">
					<div id="com-<?php $plxShow->comIndex(); ?>">
						<ul class="sinlge-post-meta">
							<li><i class="fa fa-user"></i><?php $plxShow->comAuthor(); ?> </li>
							<li><i class="fa fa-clock-o"></i><time datetime="<?php $plxShow->comDate('#num_year(4)-#num_month-#num_day #hour:#minute'); ?>"><?php $plxShow->comDate('#hour:#minute'); ?></time></li>
							<li><i class="fa fa-calendar"></i><time datetime="<?php $plxShow->comDate('#num_year(4)-#num_month-#num_day #hour:#minute'); ?>"><?php $plxShow->comDate('#day #num_day #month #num_year(4)'); ?></time></li>
						</ul>
						<blockquote>
							<p class="content_com type-<?php $plxShow->comType(); ?>"><?php $plxShow->comContent(); ?></p>
						</blockquote>
					</div>
				<a class="btn btn-primary" rel="nofollow" href="<?php $plxShow->artUrl(); ?>#form" onclick="replyCom('<?php $plxShow->comIndex() ?>')"><?php $plxShow->lang('REPLY'); ?></a>
				</div>
			</li>
		<?php endwhile; # Fin de la boucle sur les commentaires ?>

		<p><?php $plxShow->comFeed('rss',$plxShow->artId()); ?></p>
	</div>
<?php endif; ?>

<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>

	<div class="replay-box">
		<h2>
			<?php $plxShow->lang('WRITE_A_COMMENT') ?>
		</h2>
		<form id="form" style="margin-bottom: 0px;" action="<?php $plxShow->artUrl(); ?>#form" method="post" style="margin-top: 0;">
			<div class="row">
				<div class="col-sm-4">
					<div class="blank-arrow">
						<label for="id_name"><?php $plxShow->lang('NAME') ?></label>
						<input id="id_name" name="name" type="text" size="20" value="<?php $plxShow->comGet('name',''); ?>" maxlength="30" />
					</div>

					<div class="blank-arrow">
						<label for="id_mail"><?php $plxShow->lang('EMAIL') ?></label>
						<input id="id_mail" name="mail" type="text" size="20" value="<?php $plxShow->comGet('mail',''); ?>" />
					</div>

					<div class="blank-arrow">
						<label for="id_site"><?php $plxShow->lang('WEBSITE') ?></label>
						<input id="id_site" name="site" type="text" size="20" value="<?php $plxShow->comGet('site',''); ?>" />
					</div>
				</div>
				<div class="col-sm-8">
					<div class="text-area">
						<div class="blank-arrow">
							<label for="id_content"><?php $plxShow->lang('COMMENT') ?></label>
							<textarea id="id_content"  rows="5" name="content"><?php $plxShow->comGet('content',''); ?></textarea>
						</div>
					</div>
					<div class="text-area" >
						<div class="blank-arrow" style="float: left; width:340px; position: relative;">
							<?php $plxShow->comMessage('<p id="com_message" class="text-red"><strong>#com_message</strong></p>'); ?>

							<?php if($plxShow->plxMotor->aConf['capcha']): ?>
								<label for="id_rep"><?php echo $plxShow->lang('ANTISPAM_WARNING') ?></label>
								<br><br><br>
								<?php 		
								if(!eval($plxShow->plxMotor->plxPlugins->callHook('plxShowCapchaQ'))) {;
									echo $plxShow->plxMotor->plxCapcha->q();
									echo '<input type="hidden" name="capcha_token" value="'.$_SESSION['capcha_token'].'" />';
								} ?>
								<input id="id_rep" name="rep" type="text" size="2" maxlength="1" style="width: auto; display: inline;" />
							<?php endif; ?>
							<input type="hidden" id="id_parent" name="parent" value="<?php $plxShow->comGet('parent',''); ?>" />
							<input class="btn btn-primary" type="submit" value="<?php $plxShow->lang('SEND') ?>" />
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>

	<script>
		function replyCom(idCom) {
			document.getElementById('id_answer').innerHTML='<?php $plxShow->lang('REPLY_TO'); ?> :';
			document.getElementById('id_answer').innerHTML+=document.getElementById('com-'+idCom).innerHTML;
			document.getElementById('id_answer').innerHTML+='<a rel="nofollow" href="<?php $plxShow->artUrl(); ?>#form" onclick="cancelCom()"><?php $plxShow->lang('CANCEL'); ?></a>';
			document.getElementById('id_answer').style.display='inline-block';
			document.getElementById('id_parent').value=idCom;
			document.getElementById('id_content').focus();
		}
		function cancelCom() {
			document.getElementById('id_answer').style.display='none';
			document.getElementById('id_parent').value='';
			document.getElementById('com_message').innerHTML='';
		}
		var parent = document.getElementById('id_parent').value;
		if(parent!='') { replyCom(parent) }
	</script>

<?php else: ?>
	<p><?php $plxShow->lang('COMMENTS_CLOSED') ?></p>
<?php endif; ?>