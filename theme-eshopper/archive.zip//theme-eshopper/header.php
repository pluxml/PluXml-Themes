<?php if (!defined('PLX_ROOT')) exit; 
$categorieBlogue = 1;						// la catégorie de nouvelles, les articles qui ne font pas partie de la boutique
$entreeBoutique = array(2);					// c'est une matrice mais doit être unique
$categoriesBoutique = array(3,4,5);			// catégories de produits triés dans la boutique, leurs articles ont une structure spéciale (par exemple le prix dans le chapô)
$categoriesMarques = array(6,7);			// classement supplémentaire de catégories sous forme de marques, le comportement est identique à une catégorie de boutique
?>

<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php $plxShow->pageTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>
    <link rel="shortcut icon" href="<?php $plxShow->template(); ?>/images/favicon.ico">
    <link href="<?php $plxShow->template(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php $plxShow->template(); ?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php $plxShow->template(); ?>/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php $plxShow->template(); ?>/css/price-range.css" rel="stylesheet">
    <link href="<?php $plxShow->template(); ?>/css/animate.css" rel="stylesheet">
	<link href="<?php $plxShow->template(); ?>/css/main.css" rel="stylesheet">
	<link href="<?php $plxShow->template(); ?>/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="<?php $plxShow->template(); ?>/js/html5shiv.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/respond.min.js"></script>
    <![endif]-->       
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
</head><!--/head-->

<style>
mainmenu ul li { padding-right: 15px; padding-left: 15px; }

@media (max-width:768px) {
    .mainmenu ul li a { color: #FFFFFF; font-family: 'Roboto', sans-serif; font-size: 17px; font-weight: 300; padding: 0; padding-bottom: 10px; }
    .navbar-collapse { max-height: 2000px; }
}

@media (min-width:768px) {
    .mainmenu ul li a { color: #696763; font-family: 'Roboto', sans-serif; font-size: 17px; font-weight: 300; padding: 0; padding-bottom: 10px; }
    .mainmenu ul li:first-child { padding-left: 0px; }
}


.mainmenu ul li a:hover, .mainmenu ul li a.active, .shop-menu ul li a.active { background: none;background-color: transparent; }

.search_box input { background: #F0F0E9; border: medium none; color: #B2B2B2; font-family: 'roboto'; font-size: 12px; font-weight: 300; height: 35px; outline: medium none; padding-left: 10px; width: 155px; background-image: url(../css/images/home/searchicon.png); background-repeat: no-repeat; background-position: 130px; }


/*  Dropdown menu*/

.navbar-header .navbar-toggle .icon-bar { background-color: #fff; }
.nav > li > a:hover, .nav > li > a:focus{ background-color: transparent;}
.mainmenu .nav .open > a, .mainmenu .nav .open > a:hover, .mainmenu .nav .open > a:focus, .mainmenu .nav .open > a:active { background: none; }
ul.sub-menu { position: absolute; top: 30px; left: 0; background: rgba(0, 0, 0, 0.6); list-style: none; padding: 0; margin: 0; width: 220px; -webkit-box-shadow: 0 3px 3px rgba(0, 0, 0, 0.1); box-shadow: 0 3px 3px rgba(0, 0, 0, 0.1); display: none; z-index: 999; border-radius: 0px; }
.dropdown.open>a{background-color: #ffffff}
.dropdown>a:after{background-color: #ffffff}

@media (max-width: 767px)
.navbar-nav .open .dropdown-menu>li>a {
    line-height: 20px;
}

@media (min-width:768px) {
    .dropdown ul.sub-menu li .active { padding-left: 0; }
    .navbar-nav li ul.sub-menu li { padding: 10px 20px 0; }
    .navbar-nav li ul.sub-menu li:last-child { padding-bottom: 20px; }
    .navbar-nav li ul.sub-menu li a { color: #fff; padding-bottom: 0px; }
    .navbar-nav li ul.sub-menu li a:hover { }
}

@media (min-width:1024px) {
    .dropdown:hover .dropdown-menu { display: block; -webkit-animation: fadeInUp 400ms; -moz-animation: fadeInUp 400ms; -ms-animation: fadeInUp 400ms; -o-animation: fadeInUp 400ms; animation: fadeInUp 400ms; }
}

.fa-angle-down { padding-left: 5px; }

@-webkit-keyframes fadeInUp {
    0% { opacity: 0; -webkit-transform: translateY(20px); transform: translateY(20px); }
    100% { opacity: 1; -webkit-transform: translateY(0); transform: translateY(0); }
}

.shop-menu ul li a:hover { color: #fe980f; }
.shop-menu ul li a.active { color: #fdb45e; }

.shop-menu ul li { display: inline-block; padding-left: 15px; padding-right: 15px; }
    .shop-menu ul li:last-child { padding-right: 0; }
    .shop-menu ul li a { background: #FFFFFF; color: #696763; font-family: 'Roboto', sans-serif; font-size: 14px; font-weight: 300; padding: 0; padding-right: 0; margin-top: 10px; }
    .shop-menu ul li a i { margin-right: 3px; }
	.shop-menu ul li a:hover { background: #fff; }

ul.minicart-dropdown-menu { color: #ffffff; }

#topcartlink:hover > ul.minicart-dropdown-menu { display: block; -webkit-animation: fadeInUp 400ms; -moz-animation: fadeInUp 400ms; -ms-animation: fadeInUp 400ms; -o-animation: fadeInUp 400ms; animation: fadeInUp 400ms; }
#topcartlink ul.minicart-dropdown-menu { position: absolute; top: 30px; left: -50%; background: rgba(0, 0, 0, 0.6); list-style: none; padding: 0; margin: 0; width: 300px; height: 400px; overflow-y: hidden; -webkit-box-shadow: 0 3px 3px rgba(0, 0, 0, 0.1); box-shadow: 0 3px 3px rgba(0, 0, 0, 0.1); display: none; z-index: 999; }
    #topcartlink ul.minicart-dropdown-menu li .active { padding-left: 0; }
    #topcartlink ul.minicart-dropdown-menu li { padding: 10px 20px 0; }
    #topcartlink ul.minicart-dropdown-menu li:last-child { padding-bottom: 20px; }
    #topcartlink ul.minicart-dropdown-menu li a { color: #fff; background: none; }
    #topcartlink ul.minicart-dropdown-menu li a:hover { }
    #topcartlink ul.minicart-dropdown-menu .item { padding: 0px; }

.fa-angle-down { padding-left: 5px; }

@-webkit-keyframes fadeInUp {
    0% { opacity: 0; -webkit-transform: translateY(20px); transform: translateY(20px); }
    100% { opacity: 1; -webkit-transform: translateY(0); transform: translateY(0); }
}

.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.428571429;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;
}

.overlay-content .rating-div {
    color: #ffffff;
}

.btn.btn-primary {
    border: 0 none;
    border-radius: 0;
    margin-top: 16px;
}
.btn.btn-primary {
	color: #fff;
    background: #FE980F;
}

#details ul {
  background: #FFFFFF;
  border: 0 none;
  list-style: none outside none;
  margin: 0 0 20px;
  padding: 0;
}

#details  ul  li {
	display:inline-block;
}

#details ul li a {
  color: #696763;
  display: block;
  font-family: 'Roboto', sans-serif;
  font-size: 14px;
  padding-right: 15px;
}

#details ul li a i{
	color:#FE980F;
	padding-right:8px;
}

#details ul li a:hover{
	background:#fff;
	color:#FE980F;
}

#details p{
	color:#363432;
}

.post-meta span{
    float: left;
}

.replay-box span {
    color: #FE980F;
    float: none;
    font-weight: 700;
    margin-top: 21px;
}
.custom-side-box-div {
    border: 1px solid #F7F7F0;
    padding: 15px;
    margin-bottom: 35px;
}



.row {
    margin-right: -15px;
    margin-left: -15px;
}
dl {
    margin-top: 0;
    margin-bottom: 20px;
}
*, *:before, *:after {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
user agent stylesheet
dl {
    display: block;
    -webkit-margin-before: 1em;
    -webkit-margin-after: 1em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
}

</style>
<?php

$config = $jcart->config; 
$currencyCode = trim(strtoupper($config['currencyCode']));
switch($currencyCode) {
	case 'EUR':
		$currencySymbol = '&#128;';
		break;
	case 'GBP':
		$currencySymbol = '&#163;';
		break;
	case 'JPY':
		$currencySymbol = '&#165;';
		break;
	case 'CHF':
		$currencySymbol = 'CHF&nbsp;';
		break;
	case 'SEK':
	case 'DKK':
	case 'NOK':
		$currencySymbol = 'Kr&nbsp;';
		break;
	case 'PLN':
		$currencySymbol = 'z&#322;&nbsp;';
		break;
	case 'HUF':
		$currencySymbol = 'Ft&nbsp;';
		break;
	case 'CZK':
		$currencySymbol = 'K&#269;&nbsp;';
		break;
	case 'ILS':
		$currencySymbol = '&#8362;&nbsp;';
		break;
	case 'TWD':
		$currencySymbol = 'NT$';
		break;
	case 'THB':
		$currencySymbol = '&#3647;';
		break;
	case 'MYR':
		$currencySymbol = 'RM';
		break;
	case 'PHP':
		$currencySymbol = 'Php';
		break;
	case 'BRL':
		$currencySymbol = 'R$';
		break;
	case 'USD':
	default:
		$currencySymbol = '$';
		break;
}
?>

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +2 95 01 88 821</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@domain.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="header-middle">
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="./"><img src="<?php $plxShow->template(); ?>/images/home/logo.png" alt="" /></a>
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
								<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>

								<?php if (count($jcart->get_contents())!==0){ ?>
									<li id="topcartlink" class="dropdown">
									<a href="<?php echo $jcart->config['checkoutPath'];?>" class="ico-cart dropdown-toggle visible-md visible-lg minicart-anchor" data-hover="dropdown">
										<span class="cart-label">
											<i class="fa fa-shopping-cart"></i> Panier</span>
											<?  
											$fullCount = 0;
											foreach ($jcart->get_contents() as $item) {
												$fullCount = $fullCount+ $item['qty'];
											} ?>
											<span class="cart-qty">(<?php echo $fullCount; ?>)</span> 
										
										<i class="fa fa-angle-down"></i>
									</a>
									<ul class="minicart-dropdown-menu">
										<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 400px;">
										<li style="overflow: hidden; width: auto; height: 400px;">
											<div id="flyout-cart" class="flyout-cart">
												<div class="mini-shopping-cart">
													<div class="count">
														Votre panier contient <a href="/cart" class="items"><?php echo $fullCount; ?> article(s)</a> 
													</div>
													<legend></legend>
													<?
													$count = 1;
													$grandtotal = 0;
													foreach ($jcart->get_contents() as $item) {
														$choix = explode('|',$item['id']);
														echo '
														<div class="items ">
															<div class="item first row">
																<div class="col-md-4">
																	<div class="picture">
																		<a href="'.$item['url'].'" title="'.$item['name'].'">
																		<img width="45px" alt="'.$item['name'].'" src="'.$item['image'].'" title="'.$item['name'].'">
																		</a>
																	</div>
																</div>
																<div class="col-md-8">
																	<div class="product">
																	<div class="name">
																	<a href="'.$item['url'].'">'.$item['name'];
																		if($choix[1] !== 'option0') echo " (".$choix[1].")";
																	echo '</a>
																	</div>
																	<div class="price">Prix: <span>'.$choix[2].' '.$currencySymbol.'</span></div>
																	<div class="quantity">
																		Quantité: 
																		<span>'.$item['qty'].'</span>
																	</div>
																	</div>
																</div>
															</div>
															<br>
														</div>';
														$grandtotal = $grandtotal + ($item['qty']*$choix[2]); 
														++$count;
													} ?>

													<div class="totals">
														Total: <strong><?php echo $grandtotal.' '.$currencySymbol;?></strong>
													</div>
													<div class="buttons">
														<input type="button" value="Voir le panier" class="btn btn-primary" onclick="window.location.href='<?php echo $jcart->config['checkoutPath'];?>'">
													</div>
													</div>
												</div>
											</li>
											<div class="slimScrollBar" style="width: 10px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 400px; background: rgb(254, 152, 15);">
											</div>
											<div class="slimScrollRail" style="width: 10px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; opacity: 0.2; z-index: 90; right: 1px; background: rgb(51, 51, 51);">
											</div>
											</div>
											</ul>
										</li>
										<?php
										}
										?>
										<li><a href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><i class="fa fa-lock"></i> <?php $plxShow->lang('ADMINISTRATION') ?></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	
		<div class="header-bottom">
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
							
								<li><a href="./"><span class="glyphicon glyphicon-home"></a></span></li>
								<?php $plxShow->staticList('','<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
								<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
								<li class="dropdown">
									<a href="index.php?categorie<?php echo $entreeBoutique[0]; ?>">Boutique</a>
                                </li> 
								<li class="dropdown"><a href="#"><?php $plxShow->lang('CATEGORIES'); ?><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
										<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a></li>'); ?>
                                    </ul>
                                </li> 
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<?php	
							$plxMotor = plxMotor::getInstance();
							$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
							$searchword = '';
							if(!empty($_POST['searchfield'])) {
								$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
							}
							?>
							<div class="searchform">
								<form action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>" method="post">
									<input type="text" placeholder="Rechercher"  name="searchfield" value="<?php echo $searchword ?>" style="background-image: url(<?php $plxShow->template(); ?>//images/home/searchicon.png);">
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
