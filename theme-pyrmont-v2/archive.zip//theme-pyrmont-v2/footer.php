<?php if(!defined('PLX_ROOT')) exit; ?>
</div><!-- end page_wrap -->
<div id="footer">
	<div class="footer_wrapper">
		<div class="footer_left">
			&copy;&nbsp;<?php $plxShow->mainTitle(); ?>.&nbsp;G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a>&nbsp;et&nbsp;<a href="http://imotta.cn/" title="Pyrmont V2 theme">Pyrmont V2</a>.&nbsp;<a href="core/admin/">Administration</a> | <a href="#page_wrap">Haut de page</a>
		</div>
	</div>
</div><!-- end footer -->

</body>
</html>