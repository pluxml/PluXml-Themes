<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
		
		<li>
			<h2>Derniers articles</h2>
			<ul class="latest_post">
				<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
			</ul>
		</li>
		
		<li>
			<h2>Derniers commentaires</h2>
			<ul class="recentcomment">
				<?php $plxShow->lastComList('<a href="#com_url">#com_author</a> : #com_content(15)'); ?>
			</ul>
		</li>
		
		<li>
			<h2>Cat&eacute;gories</h2>
			<ul>
				<?php $plxShow->catList(); ?>
			</ul>
		</li>
		
		<?php endif; ?>
	</ul><!-- end ul -->
</div><!-- end sidebar -->