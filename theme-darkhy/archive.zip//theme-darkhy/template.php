<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
 <title><?php __('pagetitle'); ?></title>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <link rel="stylesheet" type="text/css" href="<?php __('template'); ?>/style.css" media="screen" />
 <link rel="alternate" type="application/rss+xml" title="Rss" href="core/rss.php" />
 <link rel="alternate" type="application/atom+xml" title="Atom" href="core/atom.php" />
</head>
<body>

<div id="wrapper">

<div id="header">

	<!-- Pour la recherche<div class="search">
		<form method="get" action="/Web/Wordpress/wordpress/index.php">
<p>
<input type="text" value="" name="s" id="s" />&nbsp;
</p>
</form> 
	</div> -->

	<ul class="navmenu">
		<li><a href="index.php">Accueil</a></li>
	</ul>

	<h1>
		<?php __('maintitle', 'link'); ?>
		<small><?php __('subtitle'); ?></small>
		<!-- img class="logo" src="http://localhost/Web/Wordpress/wordpress/wp-content/themes/dark/images/logo.gif" alt="" / -->
	</h1>


</div><!-- End of #header -->

<div id="content">

<?php # En mode 'home' ou 'catégorie' # ?>
<?php if($pluxml->mode == 'home' || $pluxml->mode =='cat') : ?>
<?php # Liste d'articles # ?>
<?php while($pluxml->result->loop()):?>
		
		<div class="post">

			<div class="post-meta">
				<span class="post-date"><?php __('date'); ?></span>
				<span class="post-cmts"><?php __('categorie'); ?><br />
				<?php __('nb_com'); ?></span>
			</div>
			<div class="post-main">
				<h2 class="post-title">
					<?php __('title', 'link'); ?>
				</h2>
				<div class="post-entry">
					<?php __('chapo'); ?>
				</div>



			</div><!-- End of .post-main -->

		</div><!-- End of .post -->

<?php endwhile; ?>
<div class="pages"><?php __('pagination'); ?></div>
<?php endif; ?>
<?php # Fin mode 'home'/'catégorie' # ?>

<?php # En mode 'article' # ?>
<?php if($pluxml->mode == 'article') : ?>		
<?php # Liste d'articles # ?>
<?php while($pluxml->result->loop()):?>

		<div class="post">

			<div class="post-meta">
				<span class="post-date"><?php __('date'); ?><br />
				&agrave; <?php __('hour'); ?></span>
				<span class="post-cmts">
					Par <?php __('author'); ?><br />
					Dans <?php __('categorie'); ?><br />
				</span>
			</div>
			<div class="post-main">
				<h2 class="post-title">
					<?php __('title', 'link'); ?>
				</h2>
				<div class="post-entry">
					<?php __('content'); ?>
				</div>
			</div><!-- End of .post-main -->
		</div><!-- End of .post -->

	<div class="cmt-form">
	<h2 id="comments">
		<?php __('nb_com'); ?>
	</div>
	
<?php endwhile; ?>

<?php if($pluxml->coms):?>

	<ol id="commentlist">

<?php while($pluxml->coms->loop()):?>

		<li class="alt">
			<div class="cmt-meta">
				<span class="cmt-author"><?php __('com_author', 'link'); ?></span>
				<span class="cmt-date"><?php __('com_date'); ?></span>
			</div>
			<div class="cmt-main">
				
				<div class="cmt-text">

					<p><?php __('com_content'); ?></p>

				</div>
			</div>
		</li>

<?php endwhile; ?>	

	</ol>

<?php endif; ?>	

<?php if($pluxml->config['allow_com'] == 1 && $pluxml->result->f('allow_com') == 1) : ?>

<div class="cmt-form">
	<h2 id="postcomment">Laisser <span>un commentaire</span></h2>
	<p class="cmt-info">
		Restez polis s'il vous plaît. Votre email ne sera jamais publié.</p>
	
		<form 
				action="index.php?<?php echo $pluxml->get; ?>" 
				method="post" id="commentform">
		
			<p>
			<label for="name">Nom&nbsp;:</label>
			<input type="text" name="name" id="author" value="" tabindex="1" />
			</p>
			<p>
			<label for="mail">E-mail&nbsp;:</label>
			<input type="text" name="mail" id="email" value="" tabindex="2" />
			</p>
			<p>
			<label for="site">Site web&nbsp;:</label>
			<input type="text" name="site" id="url" value="" tabindex="3" />
			</p>
		
		<p>
			<label for="message">Commentaire&nbsp;:</label>
			<textarea name="message" id="comment" cols="" rows="" tabindex="4"></textarea>
		</p>  
		<?php # affichage du capcha anti-spam
   			if($pluxml->config['capcha'] == 1){
    		echo '<p><label><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label><br /></p>';
    		echo '<p>'.$capcha->q().'<input name="rep" type="text" size="10" /></p>';
    		echo '<input name="rep2" type="hidden" value="'.$capcha->r().'" />';
    } ?>
		<p>
			<input 
					name="submit" 
					type="submit" 
					id="submit" 
					tabindex="5" 
					value="DITES LE!" />
		</p>
		
		</form>
	
</div>

<?php endif; ?>
<?php endif; ?>
<?php # Fin mode 'article' # ?>	



</div><!-- End of #content -->

<div id="sidebar">

<div id="sidebar1">

<div class="sb1">
	<h2>RSS Feeds</h2>
	<div class="rssfeeds">
			<img class="rss-logo" src="<?php __('template'); ?>/dark/images/rss_badge.gif" alt="RSS" />
			<p class="rss-entries"><?php __('rss'); ?><br />RSS</p>
			<p class="rss-comments"><?php __('atom'); ?><br/>Atom</p>
	</div>

</div>
</div><!-- End of #sidebar1 -->

<div id="sidebar2">
<div class="sb2">

<ul>

	<!-- Categories -->
	<li id="sb-cates">
		<h2>Cat&eacute;gories</h2>
			<?php __('catlist'); ?>
	</li>

	<!-- Misc -->
	<li id="sb-misc">
		<h2>Misc</h2>
		<ul>
			<li><a href="core/admin">Admin. du Site</a></li>			
		</ul>

	</li>

</ul>
</div>
</div><!-- End of #sidebar2 -->

</div><!-- End of #sidebar -->
<div id="bottom">
<div class="bottom">
	<!--<div class="bottom-mid">
		<h2>Blogoliste</h2>
		<ul>
			<li></li>
		</ul>		
	</div>-->

	<div class="bottom-right">

		
		<div class="clear">
			



		</div>

	</div>

</div>
</div>
<div id="footer">
<p>
&copy; <?php __('maintitle'); ?>

 | <a href="http://www.ilemoned.com/wordpress/wptheme-dark" title="WordPress theme: Dark">le th&egrave;me "dark"</a>
<br/>
<a href="http://www.bartelme.at" class="credit" title="Designed par Wolfgang Bartelme">Bartelme Design</a>
<a href="http://antalmir.net" class="credit" title="Adaptation par eolhyte">Adaptation par eolhyte</a>
<a href="http://pluxml.org" class="credit" title="Pluxml">Pluxml</a>
</p>
</div><!-- End of #footer -->

</div><!-- End of #wrapper -->

</body>
</html>

<!-- bye ;) -->
