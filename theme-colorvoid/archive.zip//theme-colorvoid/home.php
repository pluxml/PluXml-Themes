<?php include('header.php'); # On insere le header ?>
	<div id="main">
			<div class="left" id="main_left">
			<div id="main_left_content">
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
			<div class="post">
				<div class="post_title"><h1><?php $plxShow->artTitle('link'); ?></h1>
				<div class="right"><div id="infocon"><?php $plxShow->artDate(); ?></div></div>
				</div>
				<div class="post_body">
				<?php $plxShow->artChapo(); ?>
				<br /><br /><div class="right"><?php $plxShow->artNbCom('link'); ?></div><br /><br />
			</div></div>
		<?php endwhile; # Fin de la boucle sur les articles ?>
		<?php # On affiche la pagination ?>
		<div class="tcenter"><?php $plxShow->pagination(); ?></div>
	</div>
		</div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
<?php include('footer.php'); # On insere le footer ?>