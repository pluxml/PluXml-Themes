		<div class="right" id="main_right">
	<div id="sidebar">
		<div class="box"><div class="box_title">Cat&eacute;gories</div>
		<div class="box_body"><ul>
			<?php $plxShow->catList('Accueil','#cat_name'); ?></ul>
		</div>
		<div class="box_bottom"></div>
	</div></div>
	<div class="box">
		<div class="box_title">Syndication</div>
		<div class="box_body"><ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li></ul>
		</div>
		<div class="box_bottom"></div>
	</div></div>
</div>