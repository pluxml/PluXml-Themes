<?php include('header.php'); # On insere le header ?>
	<div id="main">
			<div class="left" id="main_left">
			<div id="main_left_content">
			<div class="post">
				<div class="post_title"><h1><?php $plxShow->staticTitle(); ?></h1</div>
		<div class="post_body"><?php $plxShow->staticContent(); ?></div>
	</div>
		</div></div>
	<?php include('sidebar.php'); # On insere la sidebar ?>
<?php include('footer.php'); # On insere le footer ?>
