	</div>
	
	<div id="footer">
		<p>
			G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a>.
			Th&egrave;me par <a href="http://deniart.ru">deniart</a>. 
			<!--<a href="#top">Haut de page</a> | 
			<a href="core/admin/">Administration</a>. -->
		</p>
	</div>
</div>

</body>
</html>