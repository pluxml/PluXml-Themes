<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute;  par <a href="http://pluxml.org">Pluxml</a> | <a href="http://randal.hebfree.org">Randal</a> | <a href="http://www.ineversay.com/">Delacro</a></p>
	<p class="right"><a href="core/admin/">Administration</a> | <a href="#top" title="">Haut</a></p>
</div>
</body>
</html>
