<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <title><?php $plxShow->mainTitle(); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">
    <!-- 
    Circle Template
    http://www.templatemo.com/tm-410-circle
    -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet">

    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/normalize.min.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/animate.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/templatemo_misc.css">
    <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/templatemo_style.css">

    <script src="<?php $plxShow->template(); ?>/js/vendor/modernizr-2.6.2.min.js"></script>
	<!-- templatemo 410 circle -->
	
	
</head>
<body>
    <!--[if lt IE 7]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <div class="bg-overlay"></div>

     <div class="container-fluid">
        <div class="row">
           
            <div class="col-md-4 col-sm-12">
                <div class="sidebar-menu">
                    
                    <div class="logo-wrapper">
                        <h1 class="logo">
                            <a href="#"><img src="<?php $plxShow->template(); ?>/images/logo.png" alt="Circle Template">
                            <span><?php $plxShow->subTitle(); ?></span></a>
                        </h1>
                    </div> <!-- /.logo-wrapper -->
                    
                    <div class="menu-wrapper">
                        <ul style="display: block;" class="menu">
							<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
							<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
                        </ul> <!-- /.menu -->
                        <a href="#" class="toggle-menu"><i class="fa fa-bars"></i></a>
                    </div> <!-- /.menu-wrapper -->

                    <!--Arrow Navigation-->
                    <a style="display: block;" id="prevslide" class="load-item"><i class="fa fa-angle-left"></i></a>
                    <a style="display: block;" id="nextslide" class="load-item"><i class="fa fa-angle-right"></i></a>

                </div> <!-- /.sidebar-menu -->
            </div> <!-- /.col-md-4 -->

            <div class="col-md-8 col-sm-12">
 