<?php if(!defined('PLX_ROOT')) exit; ?>

<div class="row" role="complementary">
		<div class="col-md-4 col-sm-4">
			<div class="member-item">
				<h3>
					<?php $plxShow->lang('CATEGORIES'); ?>
				</h3>

				<ul class="cat-list unstyled-list">
					<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
				</ul>
			</div> <!-- /.member-item -->
		</div> <!-- /.col-md-4 -->
		<div class="col-md-4 col-sm-4">
			<div class="member-item">
				<h3>
					<?php $plxShow->lang('LATEST_ARTICLES'); ?>
				</h3>

				<ul class="lastart-list unstyled-list">
					<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
				</ul>
			</div> <!-- /.member-item -->
		</div> <!-- /.col-md-4 -->
		<div class="col-md-4 col-sm-4">
			<div class="member-item">
				<h3>
					<?php $plxShow->lang('LATEST_COMMENTS'); ?>
				</h3>

				<ul class="lastcom-list unstyled-list">
					<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
				</ul>
			</div> <!-- /.member-item -->
		</div> <!-- /.col-md-4 -->
</div> <!-- /.row -->

