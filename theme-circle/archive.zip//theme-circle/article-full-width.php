<?php include(dirname(__FILE__).'/header.php'); ?>

               
                <div id="menu-container">
                    <div style="display: block;" role="article" id="post-<?php echo $plxShow->artId(); ?>" class="content animated fadeInDown">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="toggle-content text-center spacing">
									<div class="g-item">
										<img src="img.php?src=<?php eval($plxShow->callHook("showVignette", "true")); ?>&w=350&h=75&crop-to-fit" alt="<?php $plxShow->artTitle(); ?>">
										<a data-rel="lightbox" class="overlay" href="<?php eval($plxShow->callHook("showVignette", "true")); ?>" alt="<?php $plxShow->artTitle(); ?>">">
											<span>+</span>
										</a>
									</div>
                                    <h1><?php $plxShow->artTitle(); ?></h1>
									<?php $plxShow->artContent(); ?>
                                </div>
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->
						
						<?php include(dirname(__FILE__).'/commentaires.php'); ?>
						
						<?php include(dirname(__FILE__).'/sidebar.php'); ?>

                    </div> 
                </div> <!-- /#menu-container -->

            </div> <!-- /.col-md-8 -->

        </div> <!-- /.row -->
    </div> <!-- /.container-fluid -->
    
  <script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="<?php $plxShow->template(); ?>/js/jquery.easing-1.3.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/bootstrap.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/plugins.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/main.js"></script>
    <script type="text/javascript">
 			jQuery(function ($) {
                $.supersized({
                    // Functionality
                    slide_interval: 3000, // Length between transitions
                    transition: 0, // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
                    transition_speed: 700, // Speed of transition

                    // Components                           
                    slide_links: 'blank', // Individual links for each slide (Options: false, 'num', 'name', 'blank')
                    slides: [ { image: 'img.php?src=<?php eval($plxShow->callHook("showVignette", "true")); ?>&w=1920&h=1280&crop-to-fit'} ]
                });
            });
    </script>


<?php include(dirname(__FILE__).'/footer.php'); ?>
