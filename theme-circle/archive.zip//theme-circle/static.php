<?php include(dirname(__FILE__).'/header.php'); ?>


            <div class="col-md-8 col-sm-12">
                <div id="menu-container">
                    <div style="display: block;" class="content animated fadeInDown">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="toggle-content text-center spacing">
                                    <h1><?php $plxShow->staticTitle(); ?></h1>
									<?php $plxShow->staticContent(); ?>
                                </div>
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->

						<?php include(dirname(__FILE__).'/sidebar.php'); ?>

					</div>
                </div> <!-- /#menu-container -->
            </div> <!-- /.col-md-8 -->
        </div> <!-- /.row -->
   </div> <!-- /.container-fluid -->


   <script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="<?php $plxShow->template(); ?>/js/jquery.easing-1.3.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/bootstrap.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/plugins.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/main.js"></script>
    <script type="text/javascript">
 			jQuery(function ($) {
                $.supersized({
                    // Functionality
                    slide_interval: 3000, // Length between transitions
                    transition: 1, // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
                    transition_speed: 700, // Speed of transition

                    // Components                           
                    slide_links: 'blank', // Individual links for each slide (Options: false, 'num', 'name', 'blank')
                    slides: [ 
					<?php eval($plxShow->callHook("vignetteArtList", 
					array("{ image: 'img.php?src=#art_vignette&w=1920&h=1280&crop-to-fit' },",99, "1","...", "random"))); ?>	
                    ]
                });
            });
    </script>

 

<?php include(dirname(__FILE__).'/footer.php'); ?>
