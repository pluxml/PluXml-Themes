<?php include(dirname(__FILE__).'/header.php'); ?>

            <div class="col-md-8 col-sm-12">
                <div id="menu-container">
                    <div style="display: block;" class="content animated fadeInDown">
                        <div class="row">
                            <ul class="tabs">
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab1" class="icon-item">
                                        <i class="fa fa-umbrella"></i>
                                    </a> <!-- /.icon-item -->
                                </li>
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab2" class="icon-item">
                                        <i class="fa fa-camera"></i>
                                    </a> <!-- /.icon-item -->
                                </li>
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab3" class="icon-item">
                                        <i class="fa fa-coffee"></i>
                                    </a> <!-- /.icon-item -->
                                </li>
                            </ul> <!-- /.tabs -->
                        </div> <!-- /.row -->
						<div class="row">
                            <div class="col-md-12">
                                <div class="toggle-content text-center spacing">
                                    <h3>Quelque chose à dire</h3>
                                    <p>Donec mattis enim sit amet nisl faucibus, eu pulvinar nibh facilisis. Aliquam erat volutpat. Vivamus tempus, nisi varius imperdiet molestie, velit mi feugiat felis, sit amet fringilla mi massa sit amet arcu. Mauris dictum nisl id felis lacinia congue. Aliquam lectus nisi, sodales in lacinia quis, lobortis vel sem.
                                    <br><br><strong>Address:</strong> 123 Thamine Street, Digital Estate, Yangon 10620, Myanmar
                                    <br><strong>Email:</strong> info@company.com | <strong>Tel:</strong> 010-020-0340</p>
                                </div>
                            </div> <!-- /.col-md-12 -->
                        <div class="row">
							<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
								<div class="col-md-4 col-sm-4" role="article" id="post-<?php echo $plxShow->artId(); ?>">
									<div class="member-item">
										<div class="thumb">
											<a href="<?php $plxShow->artUrl(); ?>">
												<img src="img.php?src=<?php eval($plxShow->callHook("showVignette", "true")); ?>&w=500&h=500&crop-to-fit" alt="<?php $plxShow->artTitle(); ?>">
											</a>
										</div>
										<h4><?php $plxShow->artTitle(); ?></h4>
										<span><?php $plxShow->artChapo(''); ?></span>
									</div> <!-- /.member-item -->
								</div> <!-- /.col-md-4 -->
							<?php endwhile; ?>
                        </div> <!-- /.row -->
                    </div>
                </div> <!-- /#menu-container -->
            </div> <!-- /.col-md-8 -->
        </div> <!-- /.row -->
    </div> <!-- /.container-fluid -->
	
   
   <script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php $plxShow->template(); ?>/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="<?php $plxShow->template(); ?>/js/jquery.easing-1.3.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/bootstrap.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/plugins.js"></script>
    <script src="<?php $plxShow->template(); ?>/js/main.js"></script>
    <script type="text/javascript">
            
			jQuery(function ($) {

                $.supersized({

                    // Functionality
                    slide_interval: 3000, // Length between transitions
                    transition: 1, // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
                    transition_speed: 700, // Speed of transition

                    // Components                           
                    slide_links: 'blank', // Individual links for each slide (Options: false, 'num', 'name', 'blank')
                    slides: [ 
						<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
							{ image: 'img.php?src=<?php eval($plxShow->callHook("showVignette", "false")); ?>&w=1920&h=1280&crop-to-fit' },
							<?php endwhile; ?>
                    ]

                });
            });
            
    </script>
    
<?php include(dirname(__FILE__).'/footer.php'); ?>
