<?php if (!defined('PLX_ROOT')) exit(); ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head itemscope itemtype="http://schema.org/WebSite">
  <meta charset="<?php $plxShow->charset('min'); ?>">
  <meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">
  <title><?php $plxShow->pageTitle(); ?></title>
  <?php $plxShow->meta('description') ?>
  <link rel="icon" sizes="" href="<?php $plxShow->template(); ?>/img/favicon.png" />
  <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/knacss.css" media="screen"/>
  <link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/styles.css" media="screen"/>
  <?php $plxShow->templateCss() ?>
  <link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
  <link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
  <meta itemprop="name" content="<?php $plxShow->pageTitle(); ?>">
  <meta itemprop="url" content="<?php $plxShow->racine() ?>">
</head>
<body class="site site-<?php echo $plxShow->staticId(); ?>" itemscope itemtype="http://schema.org/WebPage">



<!-- BEGIN SITE HEADER -->
<div class="site-header-wrapper">

  <div class="site-branding-wrapper">
    <header class="site-header" itemscope itemtype="http://schema.org/WPHeader">

      <!-- logo -->
      <div class="site-logo" itemscope itemtype="http://schema.org/Organization">
        <img alt="<?php $plxShow->lang('SITE_LOGO') ?>" itemprop="logo" src="<?php $plxShow->template(); ?>/img/logo.png" width="60" height="60" title="<?php $plxShow->lang('SITE_LOGO') ?>"/>
      </div>

      <!-- titre -->
      <h1 class="site-title" itemprop="headline">    
        <?php $plxShow->mainTitle('link'); ?>
      </h1>

      <!-- cf http://nemesisdesign.net/blog/accessibility/nice-css-skip-links-appearing-focus/ -->
      <div class="skip-links">
        <a href="#skip-to-main-menu"><?php $plxShow->lang('GO_TO_MAIN_MENU') ?></a>
        <a href="#skip-to-main-content"><?php $plxShow->lang('GO_TO_MAIN_CONTENT') ?></a>
      </div>

    </header><!-- /.site-header -->
  </div><!-- /.site-branding-wrapper -->

  <div class="site-navigation-wrapper">
    <nav class="site-navigation" itemscope itemtype="http://schema.org/SiteNavigationelement">
      <ul id="skip-to-main-menu" class="site-navigation-list">
        <?php $plxShow->staticList($plxShow->getLang(),'<li class="site-navigation-item #static_status"><a rel="dns-prefetch" href="#static_url" itemprop="url"><span itemprop="name">#static_name</span></a></li>'); ?>
      </ul>
    </nav>
  </div><!-- /.site-navigation-wrapper -->

</div><!-- /.site-header-wrapper -->
<!-- END SITE HEADER -->



<!-- BEGIN SITE MAIN -->
<div class="site-main-wrapper">
  <main id="skip-to-main-content" class="site-main">
  
