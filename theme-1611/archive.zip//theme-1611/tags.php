<?php include(dirname(__FILE__).'/header.php'); ?>

  <p class="site-arcatag-headline">
    <?php $plxShow->lang('ARCHIVES_TAGS'); ?>&nbsp;: <?php $plxShow->tagName(); ?>
  </p>

  <?php include(dirname(__FILE__).'/post.php'); ?>

  <span class="site-feed"><?php $plxShow->tagFeed() ?></span>

<?php include(dirname(__FILE__).'/footer.php'); ?>
