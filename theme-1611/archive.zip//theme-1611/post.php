<?php if (!defined('PLX_ROOT')) exit; ?>

  <div class="site-post-wrapper">
  <?php while($plxShow->plxMotor->plxRecord_arts->loop()):
    ob_start();
    $plxShow->artContent();
    $c = ob_get_clean();
  ?>

    <article class="site-post" id="post-<?php echo $plxShow->artId(); ?>" itemscope itemtype="http://schema.org/CreativeWork">

      <header class="site-post-header">
        <h1 class="site-post-title" itemprop="headline"><?php $plxShow->artTitle('link'); ?></h1>
      </header>

      <footer class="site-post-footer">
        <time class="site-post-date" datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>" itemprop="datePublished"><?php $plxShow->artDate('#day #num_day #month #num_year(4)'); ?></time> <?php $plxShow->lang('POST_AT'); ?> <time class="site-post-time" datetime="<?php $plxShow->artDate('#hour:#minute'); ?>"><?php $plxShow->artDate('#hour:#minute'); ?></time> - <span class="site-post-comm"><?php $plxShow->artNbCom(); ?></span><br />
        <?php $plxShow->lang('POST_CATS') ?> <?php $plxShow->artCat() ?> - <?php $plxShow->lang('POST_TAGS') ?> <?php $plxShow->artTags() ?>
      </footer>

      <div class="site-post-content">
        <div class="site-post-thumbnail">
          <?php $plxShow->artThumbnail(); ?>
        </div>
        <div class="site-post-main" itemprop="text">
          <?php $plxShow->artChapo(''); ?>
          <?php $plxShow->artReadMore('<p class="site-post-more"><a href="#art_url" title="#art_title">'.$plxShow->getlang('POST_READ').'</a></p>'); ?>
        </div>
      </div>

      <hr class="sep" />

    </article>

  <?php endwhile; ?>
  </div>
