<?php //français

$LANG = array(

# header.php
'SITE_LOGO'            =>  'Logo du site',
'GO_TO_MAIN_MENU'      =>  'Aller au menu principal',
'GO_TO_MAIN_CONTENT'   =>  'Aller au contenu principal',
'SITE_HOME'            =>  'Accueil',

# post.php
'POST_BY'              =>  'Écrit par',
'POST_ON'              =>  'le',
'POST_AT'              =>  'à',
'POST_CATS'            =>  'Catégorie(s)&nbsp;:',
'POST_TAGS'            =>  'Mot(s)-Clé(s)&nbsp;:',
'POST_READ'            =>  'Lire la suite de cet article',

# commentaires.php
'BY'                   =>  'Par',
'ON'                   =>  'le',
'AT'                   =>  'à',
'REPLY'                =>  'Répondre',
'FORM_TITLE'           =>  'Écrire un commentaire',
'FORM_INFOS'           =>  'Coordonnées',
'FORM_NAME'            =>  'Nom (ou pseudo)',
'FORM_MAIL'            =>  'Courriel',
'FORM_SITE'            =>  'Site internet',
'FORM_TEXT'            =>  'Message',
'FORM_VALID'           =>  'Précaution anti-spam',
'FORM_SPAM'            =>  'Prouvez que vous n\'êtes pas un robot en répondant à la question suivante.',
'FORM_VERIF'           =>  'Vérifiez bien vos informations puis cliquez sur le bouton «&nbsp;Envoyer&nbsp;».',
'FORM_SEND'            =>  'Envoyer',
'FORM_REPLY'           =>  'Répondre à ce commentaire', 
'FORM_CANCEL'          =>  'Annuler cette action',
'FORM_CLOSED'          =>  'Les commentaires sont fermés.',

# erreur.php
'ERROR'                =>  'Page non trouvée&nbsp;!',
'ERROR_MESSAGE'        =>  'La page ou l\'article que vous cherchez n\'existe pas ou n\'existe plus.',

# archives.php
'ARCHIVES_DATE'        =>  'Tous les articles de',

# categories.php
'ARCHIVES_CATS'        =>  'Tous les articles classés dans',

# tags.php
'ARCHIVES_TAGS'        =>  'Tous les articles ayant pour mot-clé',

# aside.php
'LATEST_COMMENTS'      =>  'Commentaires récents',
'LATEST_ARTICLES'      =>  'Articles récents',
'CATE'                 =>  'Catégories',
'TAGS'                 =>  'Mots clés',
'ARCHIVES'             =>  'Archives',
'RSS_FEEDS'            =>  'Abonnements RSS',
'ARTICLES_RSS_FEEDS'   =>  'Fil RSS des articles',
'COMMENTS_RSS_FEEDS'   =>  'Fil RSS des commentaires',

# footer.php
'MOTOR'                =>  'Site réalisé avec',
'BYY'                  =>  'par',
'PLUXML_DESCRIPTION'   =>  'Blog ou CMS sans base SQL',
'DESIGN'               =>  'Thème',
'SITE_HOME'            =>  'Accueil',
'GO_TO_HOME'           =>  'Retour en page d\'accueil',
'GO_TO_TOP'            =>  'Retour en haut de page',
'TOP'                  =>  'Haut de page',
'GO_TO_SITE_ADMIN'     =>  'Aller à l\'administration',
'SITE_ADMIN'           =>  'Administration',

);

?>
