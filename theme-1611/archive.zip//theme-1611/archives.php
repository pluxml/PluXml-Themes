<?php include(dirname(__FILE__).'/header.php'); ?>

  <p class="site-arcatag-headline">
    <?php echo plxDate::formatDate($plxShow->plxMotor->cible, $plxShow->lang('ARCHIVES_DATE').' #month #num_year(4)') ?>
  </p>

  <?php include(dirname(__FILE__).'/post.php'); ?>

<?php include(dirname(__FILE__).'/footer.php'); ?>
