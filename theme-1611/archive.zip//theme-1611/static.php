<?php include(dirname(__FILE__).'/header.php'); ?>

  <article class="site-page" id="page-<?php echo $plxShow->staticId(); ?>" itemscope itemtype="http://schema.org/CreativeWork">

    <header class="site-page-header">
      <h1 class="site-page-title" itemprop="headline"><?php $plxShow->staticTitle(); ?></h1>
    </header>

    <div class="site-page-content" itemprop="text">
      <?php $plxShow->staticContent(); ?>
    </div>

    <hr class="sepsep" />

  </article>

<?php include(dirname(__FILE__).'/footer.php'); ?>
