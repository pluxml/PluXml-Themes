<?php if(!defined('PLX_ROOT')) exit; ?>

<?php if($plxShow->plxMotor->plxRecord_coms): ?>
<!-- BEGIN COMMENTS LIST -->
<div class="site-comments-wrapper">
<section class="site-comments">
	
	<header class="site-comments-header">
		<h1 class="site-comments-title" id="comments"><?php echo $plxShow->artNbCom(); ?></h1>
	</header>

	<ol class="site-comments-list">
	<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>

		<li class="site-comments-item <?php $plxShow->comLevel(); ?>" id="<?php $plxShow->comId(); ?>">

			<article class="site-comment" id="com-<?php $plxShow->comIndex(); ?>" itemscope itemtype="http://schema.org/UserComments">
				<div class="site-comment-info">
					<header class="site-comment-header">
						<h1 class="site-comment-order" itemprop="headline">
	            <a href="<?php $plxShow->ComUrl(); ?>" title="#<?php echo $plxShow->plxMotor->plxRecord_coms->i+1 ?>">#<?php echo $plxShow->plxMotor->plxRecord_coms->i+1 ?></a>
	          </h1>
					</header>
					<footer class="site-comment-footer">
	          <?php $plxShow->lang('BY'); ?> 
	          <span class="site-comment-author" itemprop="author" itemscope itemtype="http://schema.org/Person"><?php $plxShow->comAuthor('link'); ?></span> 
	          <?php $plxShow->lang('ON'); ?> 
	          <time class="site-comment-date" datetime="<?php $plxShow->comDate('#num_year(4)-#num_month-#num_day'); ?>" itemtype="commentTime"><?php $plxShow->comDate('#day #num_day #month #num_year(4)'); ?></time> 
	          <?php $plxShow->lang('AT'); ?> 
	          <time class="site-comment-time" datetime="<?php $plxShow->comDate('#hour:#minute'); ?>" itemtype="commentTime""><?php $plxShow->comDate('#hour:#minute'); ?></time>
					</footer>
				</div>
				<p class="site-comment-content content_com type-<?php $plxShow->comType(); ?>" itemtype="commentText">
					<?php $plxShow->comContent(); ?>
				</p>
				<aside class="site-comment-aside">
					<span class="site-comment-reply"><a rel="nofollow" href="<?php $plxShow->artUrl(); ?>#form" onclick="replyCom('<?php $plxShow->comIndex() ?>')"><?php $plxShow->lang('REPLY'); ?></a></span>
				</aside>
			</article>

		</li>

	<?php endwhile; # Fin de la boucle sur les commentaires ?>
	</ol>

	<p class="site-feed"><?php $plxShow->comFeed('rss',$plxShow->artId()); ?></p>

	<hr class="sep" />

</section>
</div><!-- /.site-comments-wrapper -->
<!-- END COMMENTS LIST -->
<?php endif; ?>





<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
<!-- BEGIN FORM COMMENT -->
<section class="site-form">

	<header class="site-form-header">
		<h1 class="site-form-title"><?php $plxShow->lang('FORM_TITLE') ?></h1>
	</header>

	<!-- cf https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Formulaires/Comment_structurer_un_formulaire_HTML -->
	<form class="site-form-content" id="form" action="<?php $plxShow->artUrl(); ?>#form" method="post">

		<!-- <p class="site-form-required"><small><?php //$plxShow->lang('FORM_REQUIRED'); ?></small></p> -->

		<div class="site-form-fieldset-container-if-reply">
		
			<div class="site-form-block-if-reply" id="id_answer"></div>
		
		</div><!-- /.site-form-fieldset-container-if-reply -->

		<div class="site-form-fieldset-flex">

			<div class="site-form-fieldset-container">

				<fieldset class="site-form-fieldset">

					<div class="site-form-block site-form-block-area">
						<!-- <div class="site-form-block-if-reply" id="id_answer"></div> -->
						<label class="site-form-label h4-like" for="id_content" class="lab_com"><?php $plxShow->lang('FORM_TEXT'); ?></label>
						<textarea class="site-form-area" id="id_content" name="content"><?php $plxShow->comGet('content',''); ?></textarea>
					</div> 

				</fieldset>

			</div><!-- /.site-form-fieldset-container -->

			<div class="site-form-fieldset-container">

				<fieldset class="site-form-fieldset">

					<div class="site-form-block">
						<label class="site-form-label h4-like" for="id_name"><?php $plxShow->lang('FORM_NAME') ?></label>
						<input class="site-form-input" id="id_name" name="name" type="text" value="<?php $plxShow->comGet('name',''); ?>" maxlength="30" required />
					</div><!-- /.site-form-block-->

					<div class="site-form-block">
						<label class="site-form-label h4-like" for="id_mail"><?php $plxShow->lang('FORM_MAIL') ?></label>
						<input class="site-form-input" id="id_mail" name="mail" type="email" value="<?php $plxShow->comGet('mail',''); ?>" />
					</div><!-- /.site-form-block-->

					<div class="site-form-block">
						<label class="site-form-label h4-like" for="id_site"><?php $plxShow->lang('FORM_SITE') ?></label>
						<input class="site-form-input" id="id_site" name="site" type="url" value="<?php $plxShow->comGet('site',''); ?>" />
					</div><!-- /.site-form-block-->

				</fieldset>

				<?php if($plxShow->plxMotor->aConf['capcha']): ?>
				<fieldset class="site-form-fieldset site-form-capcha">
				
					<span class="site-form-legend h3-like"><?php $plxShow->lang('FORM_VALID'); ?></span><br />
					<label class="site-form-label" for="id_rep"><?php $plxShow->capchaQ(); ?></label>&nbsp;	
					<!-- note pour l'intégrateur : class="capcha-letter" sur le rang de la lettre et class="capcha-word" sur  le groupe de lettres aléatoires. -->
					<input class="site-form-input" id="id_rep" name="rep" type="text" size="2" maxlength="1" /><br />
					<span class="site-form-message h2-like" id="com_message"><?php //$plxShow->comMessage('#com_message'); ?><?php $plxShow->comMessage('La vérification a échoué&nbsp;!') ?></span>

				</fieldset>
				<?php endif; ?>

				<fieldset class="site-form-fieldset site-form-valid">

					<p class="site-form-verification"><?php //$plxShow->lang('FORM_VERIF'); ?></p>
					<input type="hidden" id="id_parent" name="parent" value="<?php $plxShow->comGet('parent',''); ?>" />
					<button class="site-form-button" type="submit"><?php $plxShow->lang('FORM_SEND') ?></button>

				</fieldset>
			
			</div><!-- /.site-form-fieldset-container -->

		</div><!-- /.site-form-fieldset-flex -->

	</form>

	<hr class="sepsep" />

	<script>
	function replyCom(idCom) {
		document.getElementById('id_answer').innerHTML='<?php $plxShow->lang('FORM_REPLY'); ?> :';
		document.getElementById('id_answer').innerHTML+=document.getElementById('com-'+idCom).innerHTML;
		document.getElementById('id_answer').innerHTML+='<a rel="nofollow" href="<?php $plxShow->artUrl(); ?>#form" onclick="cancelCom()"><?php $plxShow->lang('FORM_CANCEL'); ?></a>';
		document.getElementById('id_answer').style.display='inline-block';
		document.getElementById('id_parent').value=idCom;
		document.getElementById('id_content').focus();
	}
	function cancelCom() {
		document.getElementById('id_answer').style.display='none';
		document.getElementById('id_parent').value='';
		document.getElementById('com_message').innerHTML='';
	}
	var parent = document.getElementById('id_parent').value;
	if(parent!='') { replyCom(parent) }
	</script>

<?php else: ?>

	<p class="site-comments-closed"><?php $plxShow->lang('COMMENTS_CLOSED') ?>.</p>

</section>
<!-- END FORM COMMENT -->
<?php endif; # Fin du if sur l'autorisation des commentaires ?>
