<?php if(!defined('PLX_ROOT')) exit; ?>

<!-- BEGIN SITE ASIDE -->
<div class="site-aside-wrapper">
	<aside class="site-aside">

    <figure class="site-aside-figure" role="group">
      <figcaption class="site-aside-figcaption"><?php $plxShow->lang('LATEST_COMMENTS'); ?></figcaption>
      <ul class="site-aside-list">
        <?php $plxShow->lastComList('<li class="site-aside-item">#com_date par #com_author<br /><a class="site-aside-link" href="#com_url">#com_content(55)</a></li>', '6'); ?>
      </ul>
    </figure>

    <figure class="site-aside-figure" role="group">
      <figcaption class="site-aside-figcaption"><?php $plxShow->lang('LATEST_ARTICLES'); ?></figcaption>
      <ul class="lsite-aside-list">
        <?php $plxShow->lastArtList('<li>#art_date<br /><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>', '6'); ?>
      </ul>
    </figure>

    <figure class="site-aside-figure" role="group">
      <figcaption class="site-aside-figcaption"><?php $plxShow->lang('RSS_FEEDS'); ?></figcaption>
      <ul class="site-aside-list">
        <li class="site-aside-item"><a class="site-aside-link" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?></a></li>
        <li class="site-aside-item"><a class="site-aside-link" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS_RSS_FEEDS'); ?></a></li>
      </ul>
    </figure>

    <figure class="site-aside-figure" role="group">
      <figcaption class="site-aside-figcaption"><?php $plxShow->lang('ARCHIVES'); ?></figcaption>
      <ul class="site-aside-list">
        <?php $plxShow->archList('<li class="site-aside-item" id="#archives_id"><a class="site-aside-link #archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
      </ul>
    </figure>

	</aside>
</div><!-- /.site-aside-wrapper -->
<!-- END SITE ASIDE -->