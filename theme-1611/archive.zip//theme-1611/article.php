<?php include(dirname(__FILE__).'/header.php'); ?>

<?php
  ob_start();
  $plxShow->artContent();
  $c = ob_get_clean();
?>

<div class="site-single-wrapper">
  <article  class="site-single" id="post-<?php echo $plxShow->artId(); ?>" itemscope itemtype="http://schema.org/CreativeWork">

    <header class="site-single-header">
      <h1 class="site-single-title" itemprop="headline"><?php $plxShow->artTitle(); ?></h1>
    </header>

    <footer class="site-single-footer">
      <time class="site-single-date" datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>" itemprop="datePublished"><?php $plxShow->artDate('#day #num_day #month #num_year(4)'); ?></time> <?php $plxShow->lang('POST_AT'); ?> <time class="site-single-time" datetime="<?php $plxShow->artDate('#hour:#minute'); ?>"><?php $plxShow->artDate('#hour:#minute'); ?></time> - <span class="site-single-nbcomm"><?php $plxShow->artNbCom(); ?></span>
    </footer>

    <div class="site-single-content" itemprop="text">
      <?php $plxShow->artContent(); ?>
    </div>

  </article>

  <hr class="sepsep">

  <?php include(dirname(__FILE__).'/commentaires.php'); ?>
</div><!-- /.site-single-wrapper -->

<?php include(dirname(__FILE__).'/footer.php'); ?>
