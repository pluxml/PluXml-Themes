<?php include(dirname(__FILE__).'/header.php'); ?>

  <p class="site-arcatag-headline">
    <?php $plxShow->lang('ARCHIVES_CATS'); ?> <?php $plxShow->catName(); ?><br />
    <span class="site-categorie-description"><?php $plxShow->catDescription('#cat_description'); ?></span>
  </p>

  <?php include(dirname(__FILE__).'/post.php'); ?>

  <span class="site-feed"><?php $plxShow->artFeed('rss',$plxShow->catId()); ?></span>

<?php include(dirname(__FILE__).'/footer.php'); ?>
