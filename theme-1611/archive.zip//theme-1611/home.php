<?php include(dirname(__FILE__).'/header.php'); ?>

<?php include(dirname(__FILE__).'/post.php'); ?>

<nav class="site-pagination" itemscope itemtype="http://schema.org/SiteNavigationelement">
  <?php $plxShow->pagination(); ?>
</nav>

<?php include(dirname(__FILE__).'/footer.php'); ?>
