<?php if (!defined('PLX_ROOT')) exit; ?>

  </main><!-- /.site-main -->
</div><!-- /.site-main-wrapper -->
<!-- END SITE MAIN -->



<?php include(dirname(__FILE__).'/aside.php'); ?>



<!-- BEGIN SITE FOOTER -->
<div class="site-footer-wrapper">
	<footer class="site-footer" itemscope itemtype="http://shema.org/WPFooter">

    <div class="site-illustration">
      <img alt="Détail d'une peinture par Eugène Galien-Laloue." src="<?php $plxShow->template(); ?>/img/theme-footer.jpg" />
    </div><!-- /.site-illustration -->

    <div class="site-footer-info">
      &copy; <?php echo date('Y'); ?> <?php $plxShow->mainTitle('link'); ?>
    </div><!-- /.site-footer-info -->

	</footer><!-- /.site-footer -->
</div><!-- /.site-footer-wrapper -->
<!-- END SITE FOOTER -->



<!-- BEGIN SCRIPTS -->
  
<!-- ENDING SCRIPTS -->



</body><!-- END PAGE -->
</html><!-- END DOCUMENT -->
