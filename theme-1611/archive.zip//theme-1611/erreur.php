<?php include(dirname(__FILE__).'/header.php'); ?>

  <article class="site-page">

    <header class="site-page-header">
      <h1 class="site-page-title"><?php $plxShow->lang('ERROR'); ?></h1>
    </header>

    <div class="site-page-content">
      <p class="site-page-error"><?php $plxShow->lang('ERROR_MESSAGE'); ?></p>
    </div>

  </article>

<?php include(dirname(__FILE__).'/footer.php'); ?>
