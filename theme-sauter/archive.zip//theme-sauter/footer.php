<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="pieds">
<p>Merci <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> | <?php $plxShow->version(); ?> | <a href="core/admin/">Administration</a> | <a href="#top">Haut de page</a></p>
</div>

</body>
</html>
