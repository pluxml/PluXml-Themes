<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="colonne">
<h2>Programme</h2>
<ul>
<?php $plxShow->catList(); ?>
</ul>
<h2>Syndication</h2>
<ul>
<li><?php $plxShow->artFeed('atom'); ?></li>
<li><?php $plxShow->comFeed('atom'); ?></li>
</ul>

</div>
<div class="claire"></div>
