		<!-- Hide script from older browsers
function toggleMenu(currMenu) {
			if (document.getElementById) {
				thisMenu = document.getElementById(currMenu).style
				if (thisMenu.display == "block") {
					thisMenu.display = "none"
				}
				else {
					thisMenu.display = "block"
				}
				return false
			}
			else {
				return true
			}
		}
		// End hiding script -->