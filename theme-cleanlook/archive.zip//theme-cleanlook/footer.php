<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<div class="left">
    &copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?>
  </div>
	<div class="right">
    <a href="core/admin/">Administration</a> | <a href="#top" title="">Haut de page</a>
  </div>
</div>
</body>
</html>
