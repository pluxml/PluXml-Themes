<div id="commentside">

	<ul>                
		<li><a href="#"><img src="<?php $plxShow->template(); ?>/images/ads_200x200.gif" /></a></li>
    </ul>

</div>