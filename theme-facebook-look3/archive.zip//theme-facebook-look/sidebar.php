<?php if(!defined('PLX_ROOT')) exit; ?>
		<ul>
			<li><h2>Cat&eacute;gories</h2>
				<ul>
				<?php $plxShow->catList('Accueil','#cat_name'); ?>
				</ul>
			</li>
            
             <li><h2>Derniers articles</h2>
				<ul>
					<?php $plxShow->lastArtList('<a href="#art_url" title="#art_title">#art_title</a>'); ?>
				</ul>
			</li>
			<li><h2>Derniers commentaires</h2>
				<ul>
				<?php $plxShow->lastComList('<a href="#com_url">#com_author a dit :</a><br/>#com_content(70)'); ?>
				</ul>
			</li>
                      
</ul>