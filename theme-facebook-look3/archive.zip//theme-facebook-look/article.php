<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>

	<div id="content">
    
    	<div id="leftcolumn" class="singlepost">

			<div class="post" id="post-<?php echo $plxShow->plxMotor->plxRecord_arts->f('url') ?>">
            
                <div class="postdata">
                	<div class="title"><?php $plxShow->artTitle(); ?></div>Le <?php $plxShow->artDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?> &nbsp;|&nbsp; Par <?php $plxShow->artAuthor(); ?> &nbsp;|&nbsp; Dans <?php $plxShow->artCat(); ?></div>
            
            	<div class="entry">
		<?php $plxShow->artContent(); ?>
		</div>
                                
                <div class="tags"></div>
                                        
		</div>
<!-- You can start editing here. -->

<div id="commentscontainer">
		<?php # Si on a des commentaires ?>
		<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
        
        <?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
		<div id="comment-<?php $plxShow->comId(); ?>" class="commentlist">
            
			<div class="roundedavatar">
<img alt='' src='http://www.gravatar.com/avatar.php?gravatar_id=<?php echo md5( strtolower($plxShow->plxMotor->plxRecord_coms->f('mail')) ) ?>&default=<?php $plxShow->template(); ?>/images/roundedavatar.png' class='avatar avatar-32 photo' height='32' width='32' /><img src="<?php $plxShow->template(); ?>/images/roundedavatar.png" class="toplayer"/>
                        </div>
            
			<div class="commenttext">

				<div class="title">
					Par <?php $plxShow->comAuthor('link'); ?>
                    <small> le <?php $plxShow->comDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?></small>
                                </div>

				<div class="comment-text">
				<?php $plxShow->comContent() ?>
            	                </div>
                
			</div>
        
        </div>       
        <?php endwhile; # Fin de la boucle sur les commentaires ?>
	<?php # On affiche le fil Atom de cet article ?>   
        <p><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></p> 
    
        <?php endif; # Fin du if sur la prescence des commentaires ?>
		<?php # Si on autorise les commentaires ?>
		<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?> 
        
        
<form action="<?php $plxShow->artUrl(); ?>#form" method="post" id="commentform">

<div class="commentlist">

<?php $plxShow->comMessage(); ?>

<?php # Affichage du capcha anti-spam
if($plxShow->plxMotor->aConf['capcha']): ?>
<?php $plxShow->capchaQ(); ?>&nbsp;:<p><input name="rep" type="text" class="field auto-clear" title="V&eacute;rification anti-spam"/></p>
<input style="display:none" name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
<?php endif; # Fin du if sur le capcha anti-spam ?>                            
<textarea name="content" id="comment" class="un auto-clear" rows="1" tabindex="4" title="Laisser un Commentaire..."></textarea>
<input type="text" name="name" id="name" value="<?php $plxShow->comGet('name',''); ?>" tabindex="1" class="field auto-clear" title="Votre Nom"/>
<input type="text" name="mail" id="mail" value="<?php $plxShow->comGet('mail',''); ?>" tabindex="2" class="field auto-clear" title="Votre E-mail"/>
<input type="text" name="site" id="site" value="<?php $plxShow->comGet('site','http://'); ?>" tabindex="3" class="field auto-clear" title="Votre Site"/>
<input name="submit" class="un" type="submit" id="submit" tabindex="5" value="Envoyer" />

</div>

</form> 

</div>         
		<?php endif; # Fin du if sur l'autorisation des commentaires ?>  
          
    <?php include(dirname(__FILE__).'/commentside.php'); # On insere les pub sur les comms ?>

		</div>
    
    	<div id="centercolumn" class="singlepost">
			<div id="sidebar"><?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar de droite ?></div>
	</div>

		<div id="rightcolumn" class="singlepost">
			<?php include(dirname(__FILE__).'/adside.php'); # On insere les pubs ?>
		</div>

<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>