<div id="sidebarL">
	<ul>
    	<!-- Home & RSS links -->
		<li class="top selected"><?php $plxShow->mainTitle('link'); ?></li>
	        <li><?php $plxShow->artFeed('atom'); ?></li>
	        <li><?php $plxShow->comFeed('atom'); ?></li> 
	</ul>
</div>