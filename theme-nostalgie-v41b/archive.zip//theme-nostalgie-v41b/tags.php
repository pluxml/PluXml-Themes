<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="section">

		<div id="content">
        <div id="breadcrumbs">		
					<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> <?php $plxShow->pageBlog('<a class="#page_status" href="#page_url" title="#page_name">#page_name</a>'); ?>					
            </div>

			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
                        <div class="article">
                              
				<h2 class="art-title"><?php $plxShow->artTitle('link'); ?></h2>
                                <div class="art-topinfos">                              
<p class="art-cat">
<?php $plxShow->artDate('le #num_day #month #num_year(4)'); ?> 
<?php $plxShow->lang('WRITTEN_BY') ?> <?php $plxShow->artAuthor() ?>
,
<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat(); ?>
 [ <?php $plxShow->artNbCom('#nb'); ?> ]
</div>
				<div class="art-chapo"><?php $plxShow->artChapo(); ?>
			<hr />
                                    <span class="art-tags"><?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?></span>
                                    <span class="art-ncomments"><?php $plxShow->artNbCom(); ?></span>
                                </div>
                        </div>			
			<?php endwhile; ?>

			<p id="pagination"><?php $plxShow->pagination(); ?></p>

		</div>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>