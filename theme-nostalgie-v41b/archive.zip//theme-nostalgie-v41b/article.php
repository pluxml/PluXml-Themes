<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="section">

		<div id="content">
        <div id="breadcrumbs">		
<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> Blog <span class="sep">&#9658;</span> <?php $plxShow->artCat(); ?>  <span class="sep">&#9658;</span> 	<?php $plxShow->artTitle(''); ?>				
                        </div> 
                        <div class="article">
                               
				<h2 class="art-title"><?php $plxShow->artTitle(''); ?></h2>
                                <div class="art-topinfos">                              
<p class="art-cat">
<?php $plxShow->artDate('le #num_day #month #num_year(4)'); ?> 
<?php $plxShow->lang('WRITTEN_BY') ?> <?php $plxShow->artAuthor() ?>
,
<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat(); ?>
 [ <?php $plxShow->artNbCom('#nb'); ?> ]
</div>                              
				<div class="art-chapo"><?php $plxShow->artContent(); ?>
				<hr />
                                    <span class="art-tags"><?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?></span>
                             <hr />
							                      		<h2>&agrave; voir aussi :</h2>
    <ul>
    <?php include(dirname(__FILE__).'/suggestion.php'); ?>
    </ul>
							   
							   
				<div class="author-infos"><?php $plxShow->artAuthorInfos('#art_authorinfos'); ?></div>
				</div>
     </div>
    
			<?php include(dirname(__FILE__).'/commentaires.php'); ?>
		</div>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>