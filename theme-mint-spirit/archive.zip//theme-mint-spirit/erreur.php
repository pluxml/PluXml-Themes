<?php include('header.php'); ?>

<div id="article">
	<h2><a href="#">Erreur 404</a></h2>
	
	<p><?php $plxShow->erreurMessage(); ?></p>
</div>

<?php include('sidebar.php'); ?>
<?php include('footer.php'); ?>
