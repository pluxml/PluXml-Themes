<?php if(!defined('PLX_ROOT')) exit; ?>

<p id="copyright">
	Généré par <a href="http://pluxml.org">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> | <a href="core/admin/">Administration</a><br />Thème par Dig, adapté par Randal
</p>

</div>
</body>
</html>