<?php include('header.php'); ?>

<div id="article">
	<h2><a href="#"><?php $plxShow->staticTitle(); ?></a></h2>
	
	<p><?php $plxShow->staticContent(); ?></p>
</div>

<?php include('sidebar.php'); ?>
<?php include('footer.php'); ?>
