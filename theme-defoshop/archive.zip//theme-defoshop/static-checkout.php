<?php include(dirname(__FILE__).'/header.php'); ?>

	<main class="main grid" role="main">

		<section class="col sml-12 med-8">
			<ul class="repertory menu breadcrumb">
				<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
				<li><?php $plxShow->staticTitle(); ?></li>	
			</ul>
					<br>

			<article class="article static" role="article" id="static-page-<?php echo $plxShow->staticId(); ?>">

				<header>
					<h1>
						<?php $plxShow->staticTitle(); ?>
					</h1>
				</header>

				<section>
					<div id="content">
						<div id="jcart">
							<?php $jcart->display_cart();?>
						</div>

						<p><a href="index.php">&larr; Retourner à la boutique</a></p>

						<?php
							//echo '<pre>';
							//var_dump($_SESSION['jcart']);
							//echo '</pre>';
						?>
					</div>

					<div class="clear"></div>
				</section>

			</article>

		</section>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
