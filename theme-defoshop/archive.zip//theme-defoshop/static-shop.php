<?php include(dirname(__FILE__).'/header.php'); 

$plxMotor = plxMotor::getInstance(); ?>

<main class="main grid" role="main">
	<section class="col sml-12 med-8">
		<ul class="repertory menu breadcrumb">
			<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
			<li><?php $plxShow->staticTitle(); ?></li>	
		</ul>
		<br>
		<?php $plxShow->lastArtList('
		<form method="post" action="" class="jcart">
			<img src="#img_url" width="125px">
			<fieldset>
				<input type="hidden" name="jcartToken" value="'. $_SESSION['jcartToken'].'" />
				<input type="hidden" name="my-item-id" value="#art_id" />
				<input type="hidden" name="my-item-name" value="#art_title" />
				<input type="hidden" name="my-item-price" value="#art_chapo" />
				<input type="hidden" name="my-item-url" value="#art_id" />
				
				<ul>
					<li><strong>#art_title</strong></li>
					<li>Prix: #art_chapo
					</li>
					<li>
						<label>Qté: <input type="text" name="my-item-qty" value="1" size="3" /></label>
					</li>
				</ul>

				<input type="submit" name="my-add-button" value="Ajouter au panier" class="button" />
			</fieldset>
		</form>',99,'11'); ?>
	</section>
	<?php include(dirname(__FILE__).'/sidebar.php'); ?>
</main>
<?php include(dirname(__FILE__).'/footer.php'); ?>
<?php include(dirname(__FILE__).'/header.php'); 

$plxMotor = plxMotor::getInstance(); ?>

<main class="main grid" role="main">
	<section class="col sml-12 med-8">
		<ul class="repertory menu breadcrumb">
			<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
			<li><?php $plxShow->staticTitle(); ?></li>	
		</ul>
		<br>
		<?php $plxShow->lastArtList('
		<form method="post" action="" class="jcart">
			<img src="#img_url" width="125px">
			<fieldset>
				<input type="hidden" name="jcartToken" value="'. $_SESSION['jcartToken'].'" />
				<input type="hidden" name="my-item-id" value="#art_id" />
				<input type="hidden" name="my-item-name" value="#art_title" />
				<input type="hidden" name="my-item-price" value="#art_chapo" />
				<input type="hidden" name="my-item-url" value="#art_id" />
				
				<ul>
					<li><strong>#art_title</strong></li>
					<li>Prix: #art_chapo
					</li>
					<li>
						<label>Qté: <input type="text" name="my-item-qty" value="1" size="3" /></label>
					</li>
				</ul>

				<input type="submit" name="my-add-button" value="Ajouter au panier" class="button" />
			</fieldset>
		</form>',99,'11'); ?>
	</section>
	<?php include(dirname(__FILE__).'/sidebar.php'); ?>
</main>
<?php include(dirname(__FILE__).'/footer.php'); ?>
