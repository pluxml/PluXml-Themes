<?php include(dirname(__FILE__).'/header.php'); ?>

	<main class="main grid" role="main">

		<section class="col sml-12 med-8">

			<ul class="repertory menu breadcrumb">
				<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
				<li><?php $plxShow->catName(); ?>
				<?php $plxShow->catDescription(' : #cat_description'); ?></li>	
			</ul>
			<br>
			<div id="content">
				<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
					<form method="post" action="" class="jcart">
						<img src="<?php $plxShow->artThumbnail('#img_url'); ?>" width="125px">
						<fieldset>
							<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
							<input type="hidden" name="my-item-id" value="<?php echo $plxShow->artId(); ?>" />
							<input type="hidden" name="my-item-name" value="<?php $plxShow->artTitle(); ?>" />
							<input type="hidden" name="my-item-price" value="<?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo') ?>" />
							<input type="hidden" name="my-item-url" value="<?php echo $plxShow->artUrl(); ?>" />
							
							<ul>
								<li><strong><?php $plxShow->artTitle('link'); ?></strong></li>
								<li>Prix: <?php 
									if($plxShow->plxMotor->plxRecord_arts->f('chapo') != '') {
										echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo');
									} else { 
										echo 'Appelez-nous';
									} ?>
								</li>
								<li>
									<label>Qté: <input type="text" name="my-item-qty" value="1" size="3" /></label>
								</li>
							</ul>

							<input type="submit" name="my-add-button" value="Ajouter au panier" class="button" />
						</fieldset>
					</form>
				<?php endwhile; ?>
				<div class="clear"></div>

				<!--p><small>Having trouble? <a href="jcart/server-test.php">Test your server settings.</a></small></p-->

				<?php
//					echo '<pre>';
//					var_dump($_SESSION['jcart']);
//					echo '</pre>';
				?>
			</div>

		</section>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
