<?php include(dirname(__FILE__).'/header.php'); ?>

	<main class="main grid" role="main">

		<section class="col sml-12 med-8">
			<ul class="repertory menu breadcrumb">
				<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
				<li><?php $plxShow->artTitle(); ?></li>	
			</ul>
					<br>

			<article class="article" role="article" id="post-<?php echo $plxShow->artId(); ?>">
				<div id="content">
						<form method="post" action="index.php" class="jcart">
							<img src="<?php $plxShow->artThumbnail('#img_url'); ?>" width="125px">
							<fieldset>
								<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
								<input type="hidden" name="my-item-id" value="<?php echo $plxShow->artId(); ?>" />
								<input type="hidden" name="my-item-name" value="<?php $plxShow->artTitle(); ?>" />
								<input type="hidden" name="my-item-price" value="<?php echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo') ?>" />
								<input type="hidden" name="my-item-url" value="<?php echo $plxShow->artUrl(); ?>" />
								
								<ul>
									<li><strong><?php $plxShow->artTitle(); ?></strong></li>
									<li>Prix: <?php 
										if($plxShow->plxMotor->plxRecord_arts->f('chapo') != '') {
											echo (float)$plxShow->plxMotor->plxRecord_arts->f('chapo');
										} else { 
											echo 'Appelez-nous';
										} ?>
									</li>
									<li>
										<label>Qté: <input type="text" name="my-item-qty" value="1" size="3" /></label>
									</li>
								</ul>

								<input type="submit" name="my-add-button" value="Ajouter au panier" class="button" />
							</fieldset>
						</form>
					<div class="clear"></div>

					<!--p><small>Having trouble? <a href="jcart/server-test.php">Test your server settings.</a></small></p-->

					<?php /*
						echo '<pre>';
						var_dump($_SESSION['jcart']);
						echo '</pre>';
				*/	?>
				</div>
			</article>
		</section>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
