<?php if(!defined('PLX_ROOT')) exit;
/*
* Thème Splash!v2 par Harfangdesneiges sous licence CC-BY
* Il est construit sur une base du thème Defaut copyright PluXml
* Ce thème contient le plugin "Partager la page" de Loup-des-Neiges avec la contribution de gaiusb et antistress (http://wiki.pluxml.org/?page=partager_ses_articles_avec_les_reseaux_sociaux) Merci à eux !
* La police utilisée est Droid Sans par Steve Matteson, sous licence Apache v2 (visitez : http://code.google.com/webfonts/designer?designer=Steve+Matteson). Cette police est hébergée par Google.
* Pour finir, visitez mon blog, http://www.harfangdesneiges.free.fr/ !
*/
?>
<div id="footer">
	<ul class="left">
		<li><?php $plxShow->mainTitle('link'); ?></li>
		<li>G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou CMS sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?></li>
	</ul>
	<ul class="right">
		<li>Thème Splash!v2 par <a href="http://www.harfangdesneiges.free.fr/">Harfangdesneiges</a></li>
		<li><a href="#top">Haut de page</a></li>
	</ul>
</div>
</body>
</html>
