<?php include(dirname(__FILE__).'/header.php'); # On insere le header
/*
* Thème Splash!v2 par Harfangdesneiges sous licence CC-BY
* Il est construit sur une base du thème Defaut copyright PluXml
* Ce thème contient le plugin "Partager la page" de Loup-des-Neiges avec la contribution de gaiusb et antistress (http://wiki.pluxml.org/?page=partager_ses_articles_avec_les_reseaux_sociaux) Merci à eux !
* La police utilisée est Droid Sans par Steve Matteson, sous licence Apache v2 (visitez : http://code.google.com/webfonts/designer?designer=Steve+Matteson). Cette police est hébergée par Google.
* Pour finir, visitez mon blog, http://www.harfangdesneiges.free.fr/ !
*/
?>
<div id="page">
	<div id="content">
		<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
		<div class="post"><?php $plxShow->staticContent(); ?></div>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
