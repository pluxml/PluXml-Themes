<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
* Thème Splash!v2 par Harfangdesneiges sous licence CC-BY
* Il est construit sur une base du thème Defaut copyright PluXml
* Ce thème contient le plugin "Partager la page" de Loup-des-Neiges avec la contribution de gaiusb et antistress (http://wiki.pluxml.org/?page=partager_ses_articles_avec_les_reseaux_sociaux) Merci à eux !
* La police utilisée est Droid Sans par Steve Matteson, sous licence Apache v2 (visitez : http://code.google.com/webfonts/designer?designer=Steve+Matteson). Cette police est hébergée par Google.
* Pour finir, visitez mon blog, http://www.harfangdesneiges.free.fr/ !
-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<title><?php $plxShow->pageTitle(); ?></title>
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=<?php $plxShow->charset(); ?>" />
	<?php
	switch($plxShow->mode()) {
	        case 'home': ?>
	        <meta name="description" content="<?php $plxShow->subTitle(); ?>" />
	<?php   break;
	        case 'article':
	        $chapo = strip_tags($plxShow->plxMotor->plxRecord_arts->f('chapo'));
	        ?>
	        <meta name="description" content="<?php echo plxUtils::strCut($chapo, 50, 'word', ''); ?>" />
	<?php   break;
	        case 'static': ?>
	        <meta name="description" content="<?php $plxShow->subTitle(); ?>" />
	<?php   break;
	        case 'categorie': ?>
	        <meta name="description" content="<?php $plxShow->subTitle(); ?>" />
	<?php   break;
	        default: ?>
	        <meta name="description" content="<?php $plxShow->subTitle(); ?>" />
	<?php   break;
	}
	?>
	<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/style.css" media="screen" />
	<link rel="alternate" type="application/atom+xml" title="Flux Atom des articles" href="./feed.php?atom" />
	<link rel="alternate" type="application/rss+xml" title="Flux RSS des articles" href="./feed.php?rss" />
	<link rel="alternate" type="application/atom+xml" title="Flux Atom des commentaires" href="./feed.php?atom/commentaires" />
	<link rel="alternate" type="application/rss+xml" title="Flux RSS des commentaires" href="./feed.php?rss/commentaires" />
</head>
<body>
<div id="top">
	<ul id="access">
		<li><a href="#content" title="Aller au contenu">Aller au contenu</a></li>
		<li><a href="#menu" title="Aller au menu">Aller au menu</a></li>
	</ul>
	<div id="header">
		<h1><?php $plxShow->mainTitle('link'); ?></h1>
		<p><?php $plxShow->subTitle(); ?></p>
	</div>
	<div id="menu">
		<ul class="left">
			<?php $plxShow->staticList('Accueil','<li id="#static_id"><a href="#static_url" class="#static_status">#static_name</a></li>'); ?>
		</ul>
		<ul class="right">
			<li><a href="./feed.php?atom/commentaires" title="Fil Atom des commentaires">Commentaires</a></li>
			<li><a href="./feed.php?atom" title="Fil Atom des articles">Articles</a></li>
		</ul>
		
		<div class="clearer"></div>
	</div>
</div>
