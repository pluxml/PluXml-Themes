<?php include(dirname(__FILE__).'/header.php'); # On insere le header 
/*
* Thème Splash!v2 par Harfangdesneiges sous licence CC-BY
* Il est construit sur une base du thème Defaut copyright PluXml
* Ce thème contient le plugin "Partager la page" de Loup-des-Neiges avec la contribution de gaiusb et antistress (http://wiki.pluxml.org/?page=partager_ses_articles_avec_les_reseaux_sociaux) Merci à eux !
* La police utilisée est Droid Sans par Steve Matteson, sous licence Apache v2 (visitez : http://code.google.com/webfonts/designer?designer=Steve+Matteson). Cette police est hébergée par Google.
* Pour finir, visitez mon blog, http://www.harfangdesneiges.free.fr/ !
*/
?>
<div id="page">
	<div id="content">
		<h2 class="title"><?php $plxShow->artTitle('link'); ?></h2>
		<p class="cat">Class&eacute; dans : <?php $plxShow->artCat(); ?> | <span><?php $plxShow->artNbCom(); ?></span></p>
		<p class="date">Publié le <?php $plxShow->artDate('#day #num_day #month #num_year(4) &agrave; #hour:#minute'); ?></p>
		<div class="post"><?php $plxShow->artContent(); ?></div>
		<div class="social">
			<h2>Partager cet article</h2>
			<a title="Identi.ca" href="http://identi.ca//index.php?action=bookmarklet&amp;status_textarea=<?php $plxShow->artTitle(); ?> <?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/identi_ca.png" style="border:0;" alt="Identi.ca" /> Identi.ca</a> | 
			<a title="Twitter" href="http://twitter.com/home?status=<?php $plxShow->artTitle(); ?> <?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/twitter.png" style="border:0;" alt="Twitter" /> Twitter</a> | 
			<a title="Digg" href="http://digg.com/submit?url=<?php $plxShow->artUrl('absolu'); ?>&amp;title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/digg.png" style="border:0;" alt="Digg" /> Digg</a> | 
			<a title="StumbleUpon" href="http://www.stumbleupon.com/submit?url=<?php $plxShow->artUrl('absolu'); ?>&amp;title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/stumble.png" style="border:0;" alt="Stumble" /> StumbleUpon</a> | 
			<a title="Delicious" href="http://del.icio.us/post?url=<?php $plxShow->artUrl('absolu'); ?>&amp;title=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/delicious.png" style="border:0;" alt="Delicious" /> Del.icio.us</a> | 
			<a title="Technorati" href="http://technorati.com/faves?add=<?php $plxShow->artUrl('absolu'); ?>"><img src="<?php $plxShow->template(); ?>/img/social/technorati.png" style="border:0;" alt="Technorati" /> Technorati</a> | 
			<a title="Facebook" href="http://www.facebook.com/sharer.php?u=<?php $plxShow->artUrl('absolu'); ?>&amp;t=<?php $plxShow->artTitle(); ?>"><img src="<?php $plxShow->template(); ?>/img/social/facebook.png" style="border:0;" alt="Facebook" /> Facebook</a>
		</div>
		<?php include(dirname(__FILE__).'/commentaires.php'); # On insere les commentaires ?>
	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
</div>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
