<?php
if(!defined('PLX_ROOT')) exit;
/*
* Thème Splash!v2 par Harfangdesneiges sous licence CC-BY
* Il est construit sur une base du thème Defaut copyright PluXml
* Ce thème contient le plugin "Partager la page" de Loup-des-Neiges avec la contribution de gaiusb et antistress (http://wiki.pluxml.org/?page=partager_ses_articles_avec_les_reseaux_sociaux) Merci à eux !
* La police utilisée est Droid Sans par Steve Matteson, sous licence Apache v2 (visitez : http://code.google.com/webfonts/designer?designer=Steve+Matteson). Cette police est hébergée par Google.
* Pour finir, visitez mon blog, http://www.harfangdesneiges.free.fr/ !
*/
/*
Vous pouvez utiliser les classes CSS item-1, item-2, item-3, item-4 pour les menus de la sidebar
Ainsi que la classe CSS div-content si vous voulez mettre du texte entouré d'une bordure dans votre sidebar
*/?>
<div id="sidebar">
	<div class="item-2">
		<h2>Derniers articles</h2>
		<ul><?php $plxShow->lastArtList('<li><a href="#art_url" class="#art_status">#art_title</a></li>'); ?></ul>
	</div>
	<div class="item-1">
		<h2>Cat&eacute;gories</h2>
		<ul><?php $plxShow->catList('','<li id="#cat_id"><a href="#cat_url" class="#cat_status">#cat_name ∞ #art_nb article(s)</a></li>'); ?></ul>
	</div>
	<div class="item-3">
		<h2>Derniers commentaires</h2>
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author a dit&nbsp;:</a> #com_content(40)</li>'); ?>
		</ul>
	</div>
</div>
<div class="clearer"></div>
