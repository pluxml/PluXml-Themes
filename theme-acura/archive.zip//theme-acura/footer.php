<?php if (!defined('PLX_ROOT')) exit; ?>


	<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-sm-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>Bootstrap company Inc</strong><br>
					JC Main Road, Near Silnile tower<br>
					 Pin-21542 NewYork US.</address>
					<p>
						<i class="icon-phone"></i> (123) 456-789 - 1255-12584 <br>
						<i class="icon-envelope-alt"></i> email@domainname.com
					</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="widget">
					<h5 class="widgetheading"><?php $plxShow->lang('LATEST_ARTICLES'); ?></h5>
					<ul class="link-list">
						<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>',3); ?>
					</ul>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="widget">
					<h5 class="widgetheading"><?php $plxShow->lang('CATEGORIES'); ?></h5>
					<ul class="link-list">
						<?php $plxShow->catList('','<li><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
					</ul>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="widget">
					<h5 class="widgetheading"><?php $plxShow->lang('LATEST_COMMENTS'); ?></h5>
					<ul class="link-list">
						<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							 &copy; 2017 - <?php $plxShow->mainTitle('link'); ?> -  
							<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a> - 
							Design par <a target="_blank" href="http://webthemez.com/free-bootstrap-templates/" target="_blank">WebThemez</a> - 
							<a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
						</p>
		
						<p>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php $plxShow->template(); ?>/js/jquery.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.easing.1.3.js"></script>
<script src="<?php $plxShow->template(); ?>/js/bootstrap.min.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.fancybox.pack.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.fancybox-media.js"></script>  
<script src="<?php $plxShow->template(); ?>/js/jquery.flexslider.js"></script>
<script src="<?php $plxShow->template(); ?>/js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="<?php $plxShow->template(); ?>/js/modernizr.custom.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.isotope.min.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.magnific-popup.min.js"></script>
<script src="<?php $plxShow->template(); ?>/js/animate.js"></script>
<script src="<?php $plxShow->template(); ?>/js/custom.js"></script> 
</body>
</html>