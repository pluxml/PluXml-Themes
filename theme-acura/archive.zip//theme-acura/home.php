<?php include(dirname(__FILE__).'/header.php'); ?>

	<section id="banner">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
				<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
					<li>
						<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=1920&h=700&crop-to-fit" />
						<div class="flex-caption">
							<h3><?php $plxShow->artTitle('link'); ?></h3> 
							<p><?php $plxShow->artChapo(''); ?></p> 
						</div>
					</li>
			 	<?php endwhile; ?>
            </ul>
        </div>
	<!-- end slider -->
 
	</section> 
	<section id="call-to-action-2">
		<div class="container">
			<div class="row">
				<?php $plxShow->lastArtList('
				<div class="col-md-10 col-sm-9">
					<h3>#art_title</h3>
					<p>#art_content</p>
				</div>
				<div class="col-md-2 col-sm-3">
					<a href="#art_url" class="btn btn-primary">Lire la suite</a>
				</div>',1,'1'); ?>
			</div>
		</div>
	</section>
	
	<section id="content">
		
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="aligncenter">
						<?php $plxShow->lastArtList('
						<h2 class="#art_title</h2>
						#art_content',1,'1'); ?>
					</div>
					<br/>
				</div>
			</div>

			 <div class="row">
				<?php $plxShow->lastArtList('
					<div class="col-sm-4 info-blocks">
						<i class="icon-info-blocks fa fa-#art_chapo"></i>
						<div class="info-blocks-in">
							<h3>#art_title</h3>
							<p>#art_content</p>
						</div>
					</div>',6,'1'); ?>
			</div>
		</div>
	</section>
	
	<section class="section-padding gray-bg">
		<div class="container">
			<?php $plxShow->lastArtList('
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>#art_title</h2>
						<p>#art_chapo</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="about-text">
						<p>#art_content</p>
						<a href="#art_url" class="btn btn-primary">Lire la suite</a>
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<div class="about-image">
						<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src='.$plxMotor->aConf['racine'].$tmp['thumbnail'].'&w=500&h=272&crop-to-fit" alt="#img_alt">
					</div>
				</div>
			</div>',1,'1'); ?>
		</div>
	</section>	  
	
	
	<div class="about home-about">
		<div class="container">
			<div class="row">
				<?php $plxShow->lastArtList('
				<div class="col-md-4">
					<!-- Heading and para -->
					<div class="block-heading-two">
						<h3><span>#art_title</span></h3>
					</div>
					<p>#art_content</p>
				</div>',1,'1'); ?>

				<div class="col-md-4">
					<div class="block-heading-two">
						<h3><span><?php $plxShow->lang('LATEST_ARTICLES'); ?></span></h3>
					</div>		
					<!-- Accordion starts -->
					<div class="panel-group" id="accordion-alt3">
					 <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
						<?php $plxShow->lastArtList('
					  <div class="panel">	
						<!-- Panel heading -->
						 <div class="panel-heading">
							<h4 class="panel-title">
							  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
								<i class="fa fa-angle-right"></i> #art_title
							  </a>
							</h4>
						 </div>
						 <div id="collapseOne-alt3" class="panel-collapse collapse">
							<!-- Panel body -->
							<div class="panel-body">
								#art_content
							</div>
						 </div>
					  </div>',4,'1'); ?>
					</div>
					<!-- Accordion ends -->
				</div>
				
				<div class="col-md-4">
					<?php $plxShow->lastArtList('
					<div class="block-heading-two">
						<h3><span>#art_title</span></h3>
					</div>	
					 <div class="testimonials">
						<div class="active item">
						  <blockquote><p>#art_content</p></blockquote>
						  <div class="carousel-info">
							<img alt="" src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src='.$plxMotor->aConf['racine'].$tmp['thumbnail'].'&w=400&h=400&crop-to-fit" class="pull-left">
							<div class="pull-left">
							  <span class="testimonials-name">#art_author</span>
							  <span class="testimonials-post">#art_chapo</span>
							</div>
						  </div>
						</div>
					</div>',1,'1'); ?>
				</div>
			</div>
		</div>
	</div>
<?php include(dirname(__FILE__).'/footer.php'); ?>
