<?php include(dirname(__FILE__).'/header.php'); ?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle"><?php $plxShow->lang('ERROR'); ?></h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">		
			<div class="row"> 
				<div class="col-md-12">
					<div class="about-logo">
						<p><?php $plxShow->erreurMessage(); ?></p>
					</div>  
				</div>
			</div>
		</div>
	</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
