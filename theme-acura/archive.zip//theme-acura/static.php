<?php include(dirname(__FILE__).'/header.php'); ?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle"><?php $plxShow->staticTitle(); ?></h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">		

			<header>
				<h2>
					<?php $plxShow->staticTitle(); ?>
				</h2>
			</header>

			<?php $plxShow->staticContent(); ?>

    </div>
    </section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
