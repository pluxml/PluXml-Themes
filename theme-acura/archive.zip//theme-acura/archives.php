<?php include(dirname(__FILE__).'/header.php'); ?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle"><?php $plxShow->lang('ARCHIVES');?></h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">		
			<div class="row"> 
				<div class="col-md-12">
					<div class="about-logo">
						<p><?php echo plxDate::formatDate($plxShow->plxMotor->cible, ' #month #num_year(4)'); ?></p>
					</div>  
				</div>
			</div>
			<div class="row service-v1 margin-bottom-40">
				<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
					<div class="col-md-4">
						<img class="img-responsive" src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=828&h=550&crop-to-fit" alt="">            
						<h3>Heart Consultant</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus temporibus perferendis nesciunt quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus</p>        
					</div>
				<?php endwhile; ?>

				<nav class="pagination text-center">
					<?php $plxShow->pagination(); ?>
				</nav>
			</div>
		</div>
	</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
