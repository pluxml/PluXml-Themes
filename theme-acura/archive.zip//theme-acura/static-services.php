<?php include(dirname(__FILE__).'/header.php'); ?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle"><?php $plxShow->staticTitle(); ?></h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">		
        <!-- Service Blcoks -->
			<div class="row"> 
				<div class="col-md-12">
					<div class="about-logo">
						<h3>Titre codé en dur</h3> 
						<p>Il serait sans doute préférable de créer un article dont le titre et le contenu pourrait être affiché ici.</p>
						<p>Ça rendrait le contenu accessible par l'écran d'administration pour modification future</p>
					</div>  
				</div>
			</div>
		<div class="row">
			<div class="skill-home"> 
				<div class="skill-home-solid clearfix"> 
					<?php $plxShow->lastArtList('
					<div class="col-md-3 text-center">
						<span class="icons c1"><i class="fa fa-#art_chapo"></i></span> 
						<div class="box-area">
							<h3><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></h3> 
							<p>#art_content</p>
						</div>
					</div>',4); ?>
				</div>
			</div>
		</div> 
		<!-- Info Blcoks -->
        
		<div class="row">
			<?php $plxShow->lastArtList('
            <div class="col-sm-4 info-blocks">
                <i class="icon-info-blocks fa fa-#art_chapo"></i>
                <div class="info-blocks-in">
                    <h3><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></h3>
                    <p>#art_content</p>
                </div>
            </div>',6); ?>
        </div>
        <!-- End Info Blcoks -->

       
        <div class="row service-v1 margin-bottom-40">
			<?php $plxShow->lastArtList('
            <div class="col-md-4">
                <img class="img-responsive" src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=828&h=550&crop-to-fit" alt="">            
                <h3><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></h3>
                <p>#art_chapo</p>
            </div>',3); ?>
        </div>
        <!-- End Service Blcoks -->
         
    </div>
    </section>


<?php include(dirname(__FILE__).'/footer.php'); ?>
