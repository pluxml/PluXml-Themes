<?php include(dirname(__FILE__).'/header.php'); ?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Portfolio</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
		<div class="row"> 
			<div class="col-md-12">
				<div class="about-logo">
					<h3>Titre codé en dur</h3> 
					<p>Il serait sans doute préférable de créer un article dont le titre et le contenu pourrait être affiché ici.</p>
					<p>Ça rendrait le contenu accessible par l'écran d'administration pour modification future</p>
				</div>  
			</div>
		</div> 
	</div>
	</section>	
	
	<!-- Start Gallery 1-2 -->
    <section id="gallery-1" class="content-block section-wrapper gallery-1"> 
   	 	<div class="container">
		
			<div class="editContent">
	            <ul class="filter">
	                <li class="active"><a href="#" data-filter="*">All</a></li>
					<?php $plxShow->catList('','
					<li><a href="#" data-filter=".#cat_id">#cat_name</a></li>'); ?>
				</ul>
			</div>
            <!-- /.gallery-filter -->
			
            <div class="row">
                <div id="isotope-gallery-container">
					<?php $plxMotor = plxMotor::getInstance();
					$plxGlob_arts = clone $plxMotor->plxGlob_arts;
					if($files = $plxGlob_arts->query('/^[0-9]{4}.[home|'.$plxMotor->activeCats.',]*.[0-9]{3}.[0-9]{12}.[a-z0-9-]+.xml$/','art','rsort',0,false,'before')) {
						foreach($files as $filename) {
							$tmp = $plxMotor->parseArticle(PLX_ROOT.$plxMotor->aConf['racine_articles'].$filename);
							$art = array(
								'id'		=> $tmp['numero'],
								'url' 		=> $plxMotor->urlRewrite('?article'.intval($tmp['numero']).'/'.$tmp['url']),
								'title' 	=> $tmp['title'],
								'chapo' 	=> $tmp['chapo'],
								'thumbnail' => $tmp['thumbnail'],
								'cats' 		=> explode(",", $tmp['categorie']),
								'date'		=> $tmp['date'],
								'author'	=> $plxMotor->aUsers[$tmp['author']]['name'],
							);
							$showCat = true;
							$artCat ='';
							$catNames ='';
							foreach(explode(",", $tmp['categorie']) as $item) {
								$catArray = $plxMotor->aCats[$item];
								$artCat .= ' cat-'.ltrim($item, '0');
								$catNames .= ' '.$catArray['name'];
								if($catArray['homepage'] == 0){
									$showCat = false;
								}
							} 
							echo '
							<div class="col-md-4 col-sm-6 col-xs-12 gallery-item-wrapper '.$artCat.'">
								<div class="gallery-item">
									<div class="gallery-thumb">
										<img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src='.$plxMotor->aConf['racine'].$tmp['thumbnail'].'&w=400&h=270&crop-to-fit" class="img-responsive" alt="3rd gallery Thumb">
										<div class="image-overlay"></div>
										<a href="'.$plxMotor->aConf['racine'].$tmp['thumbnail'].'" class="gallery-zoom"><i class="fa fa-eye"></i></a>
										<a href="index.php?article'.$tmp['numero'].'" class="gallery-link"><i class="fa fa-link"></i></a>
									</div>
									<div class="gallery-details">
										<div class="editContent">
											<h5>'.$tmp['title'].'</h5>
										</div>
										<div class="editContent">
											<p>'.$tmp['chapo'].'</p>
										</div>
									</div>
								</div>
							</div>';
						}
					} ?>
                </div>
                <!-- /.isotope-gallery-container -->
            </div>
            <!-- /.row --> 
        <!-- /.container -->
		</div>
    </section>
    <!--// End Gallery 1-2 -->  
	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>
