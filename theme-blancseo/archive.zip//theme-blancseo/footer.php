<?php if (!defined('PLX_ROOT')) exit; ?>
<hr>
	<nav class="enbas">
		<ul>
		<!-- à personnaliser selon votre config -->
<li><a href="index.php" class="active" title="Accueil">Accueil</a></li>
<li><a href="index.php?contact" title="Contact">Contact</a></li>
<li><a href="index.php?static2/geolocalisation"   title="Géolocalisation">Géolocalisation</a></li>
<li><a href="index.php?allarchive"   title="Archives">Archives</a></li>
<li><a href="index.php?static3/tags-cloud"   title="Tags Cloud">Tags Cloud</a></li>
<li><a href="sitemap.php" title="Sitemap">Sitemap</a></li>
<li><a href="<?php $plxShow->urlRewrite('#top') ?>" class="active" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a></li>
		</ul>
	</nav>
		<footer class="footer">

				<p>
					&copy; 2015 <?php $plxShow->mainTitle('link'); ?> - 
					<?php $plxShow->subTitle(); ?> - 
					<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a rel="nofollow" href="http://www.pluxml.org" onclick="window.open(this.href);return false;" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
					<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp;
					<?php $plxShow->httpEncoding() ?>
				</p>

		</footer>

</div>

</body>

</html>
