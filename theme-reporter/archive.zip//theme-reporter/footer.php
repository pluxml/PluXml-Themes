<div id="footer">
	<p><a href="../poozat" title=""> Revenir à l'accueil</a> | <a href="../" title=""> Revenir en haut de la page</a><br />G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> | Design By <a href="http://poozat.net" title="">Poozat</a></p>
</div>
</body>
</html>