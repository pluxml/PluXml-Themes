<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php $plxShow->pageTitle(); ?></title>
	<?php $plxShow->meta('description') ?>
	<?php $plxShow->meta('keywords') ?>
	<?php $plxShow->meta('author') ?>  	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/style.css" media="screen" charset="utf-8" />
  	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/layout.css" media="screen" charset="utf-8" />
  	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/typo.css" media="screen" charset="utf-8" />
  	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/mobile.css" media="screen" charset="utf-8" />
  	<style type="text/css">
		a:link,
		a:active,
		a:visited {
			color: #3cb5c7;
		}

		a:hover {
			color: #80c3cd;
		}	

		.submit {
			background-color: #3cb5c7;
			border: 1px solid #3cb5c7;

		}
		
		.submit:hover {
			background-color: #80c3cd;
			border: 1px solid #80c3cd;
		}


		ol.wp-paginate li a {
			background-color: #3cb5c7;
		}
		
		ol.wp-paginate li a:hover {
			background-color: #80c3cd;
		}
		
		::-moz-selection {
			background: #bedfe1;
		}

		::selection {
			background: #bedfe1;
		}
	</style>    
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/2-lines.css" media="screen" charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/css/2-lines_mobile.css" media="screen" charset="utf-8" />  
	<script src="<?php $plxShow->template(); ?>/js/modernizr.custom.37797.js"></script> 
	<script src="<?php $plxShow->template(); ?>/jquery/1.6.1/jquery.min.js"></script> 
	<script>!window.jQuery && document.write('<script src="<?php $plxShow->template(); ?>/js/jquery_1.6.1.min.js"><\/script>')</script>
	<script src="<?php $plxShow->template(); ?>/js/parallax.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
</head>

<body>
	<div id="wrapper">
		<div id="container">
			<div id="header">
				<div class="content">
					<div id="navigation">
						<div class="menu-main-container">
							<ul id="menu-main" class="menu">
								<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-#static_id  #static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
								<?php $plxShow->pageBlog('<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-#static_id  #static_status" id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
							</ul>
						</div>		
					</div> <!-- end #navigation -->
   					<h1><?php $plxShow->mainTitle('link'); ?></h1>
				</div> <!-- end .content -->
			</div> <!-- end #header -->

