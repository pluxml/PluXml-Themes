<?php include(dirname(__FILE__).'/header.php'); ?>
	<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
		<article class="article" role="article" id="post-<?php echo $plxShow->artId(); ?>">
			<div class="entry">
				<h2><?php $plxShow->artTitle('link'); ?></h2>
				<div class="meta">
					<?php $plxShow->artDate('#num_year(4).#num_month.#num_day'); ?>
					<br />
					<?php $plxShow->artTags() ?>
				</div>
				<p><?php $plxShow->artChapo(); ?></p>
				<p class="meta">
					<?php $plxShow->artNbCom(); ?> 
				</p>			    		
			</div> <!-- end .entry -->
		</article>
	<?php endwhile; ?>

<?php include(dirname(__FILE__).'/footer.php'); ?>
