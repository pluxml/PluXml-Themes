<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<div id="footer-inner">
		<div class="col1">
			<h2>A propos</h2>
			<div class="content">
				<div class="text">
					<div class="textwidget">
						<i>Balloons</i> is a one-column layout with parallax-scrolling effect. It comes with a color switcher and a three-column widgetized footer. It is responsive to your visitor�s screen size (computer / tablet / mobile phone) and a stylesheet for the WP-Pagenavi plugin is included; available in English and German.
					</div>
				</div>
			</div>
		</div>
		<div class="col1">
			<h2><?php $plxShow->lang('CATEGORIES'); ?></h2>
			<div class="content">
				<div class="text">	
					<ul>
						<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
					</ul>
				</div>
			</div>
		</div>
		<div class="col1"><h2><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
			<div class="content">
				<div class="text">
					<ul>
						<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div> <!-- end #footer -->	
