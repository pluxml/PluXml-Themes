$(document).ready(function() {      
     
//Ex�cute le diaporama
slideShow();
 
});
 
function slideShow() {
 
//opacit� des images � 0
$('#gallery a').css({opacity: 0.0});
     
//afficher la premi�re image (opacit� 1)
$('#gallery a:first').css({opacity: 1.0});
     
//fond d'�cran semi-transparent pour la l�gende
$('#gallery .caption').css({opacity: 0.7});
 
//Redimensionnement de la l�gende � la taille de l'image
$('#gallery .caption').css({width: $('#gallery a').find('img').css('width')});
     
//afficher la l�gende de la premi�re image
$('#gallery .content').html($('#gallery a:first').find('img').attr('rel'))
.animate({opacity: 0.7}, 400);
     
//lancer le diaporama, 5000 = image suivante apr�s 5 secondes (6 par defaut : 6000)
setInterval('gallery()',5000);
     
}
 
function gallery() {
     
//s'il n'y a pas d'image saisir la premi�re
var current = ($('#gallery a.show')?  $('#gallery a.show') : $('#gallery a:first'));
 
//obtenir l'image suivante, si fin du diaporama, retour au d�but
var next = ((current.next().length) ? ((current.next().hasClass('caption'))? 
     $('#gallery a:first') :current.next()) : $('#gallery a:first'));   
     
//obtenir la l�gende de l'image suivante
var caption = next.find('img').attr('rel'); 
     
//fixer la disparition graduelle pour l'image suivante, exposition plus �lev�e
next.css({opacity: 0.0})
.addClass('show')
.animate({opacity: 1.0}, 1000);
 
//masquer l'image actuelle
current.animate({opacity: 0.0}, 1000)
.removeClass('show');
     
//fixer l'opacit� �  0 et  la hauteur � 1px
$('#gallery .caption').animate({opacity: 0.0}, 
     { queue:false, duration:0 }).animate({height: '1px'}, { queue:true, duration:300 }); 
     
//animer la l�gende, opacit� � 0.7 et hauteur � 100px, avec un effet de glissement
$('#gallery .caption').animate({opacity: 0.7},100 ) .animate({height: '50px'},500 );
     
//affichage du contenu
$('#gallery .content').html(caption);
         
}