<?php if (!defined('PLX_ROOT')) exit; ?>

		<footer class="footer" role="contentinfo">
				<div class="sml-show med-hide lrg-hide">
					<span class="h5 text-left"><i><?php $plxShow->subTitle(); ?></i></span>
					<h3>
						<?php $plxShow->lang('CATEGORIES'); ?>
					</h3>

					<ul class="cat-list unstyled-list">
						<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
					</ul>

					<h3>
						<?php $plxShow->lang('LATEST_ARTICLES'); ?>
					</h3>

					<ul class="lastart-list unstyled-list">
						<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
					</ul>

					<h3>Rechercher</h3>
					<div class="searchform">
						<form action="http://test.yeuxdelibad.net/index.php?search" method="post">
							<div class="searchfields">
								<input type="text" class="searchfield" name="searchfield" value="" />
								<input type="submit" class="searchbutton" name="searchbutton" value="Ok" />
								</p>
							</div>
						</form>
					</div>
					
					<h3>
						RSS
					</h3>
					<ul class="arch-list unstyled-list">
						<?php $plxShow->artFeed('rss',$plxShow->catId()); ?>
					</ul>
					<hr>
				</div>
				<p>
					&copy; 2016 <?php $plxShow->mainTitle('link'); ?> - 
					Site optimisé pour firefox : 
					<a href="https://www.mozilla.org/fr/firefox/new/" title="Navigateur qui vous respecte même si vous ne lui donnez pas de sous ou votre vie privée">
						<img src="<?php $plxShow->template(); ?>/img/ffox.jpg" alt="Logo firefox" style="vertical-align:middle;"/>
					</a> - 
					<a href="https://hd.unsplash.com/photo-1457696791109-fb5db9791f6c" title="Image de fond">Image de fond</a> - 
					<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
					<?php $plxShow->lang('IN') ?>&nbsp;<?php $plxShow->chrono(); ?>&nbsp; 
				</p>
				<ul class="menu">
					<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
					<li><a href="<?php $plxShow->urlRewrite('#top') ?>" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a></li>
					<li><a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a></li>
				</ul>

		</footer>

</div>

</body>

</html>
