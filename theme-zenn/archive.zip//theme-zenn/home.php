<?php include(dirname(__FILE__).'/header.php'); ?>

	<main class="main grid" role="main">
	
		<?php include(dirname(__FILE__).'/sidebar.php'); ?>
	
		<section class="col sml-12 med-10 lrg-10">
			
			<div class="home_articles_container">
				
				<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
				
				<article class="home_article" role="article" id="post-<?php echo $plxShow->artId(); ?>">

					<section>
						<div class="home_article_img">
							<a href="<?php $plxShow->artUrl(); ?>"> 
								<?php $plxShow->artThumbnail(); ?>
							</a>
						</div>
					</section>
					<footer>
						<h1 class="home_article_title">
							<?php $plxShow->artTitle('link'); ?>
						</h1>
					</footer>

				</article>
				

				<?php endwhile; ?>
			</div>

			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>


		</section>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
