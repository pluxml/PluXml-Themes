<?php if(!defined('PLX_ROOT')) exit; ?>
	<div class="clear"></div>
    
    <div id="footer">

		<div class="alignleft">
			<p><?php $plxShow->mainTitle('link'); ?>  &copy; 2009</p>    
		</div>

<!-- Please keep this link, to support Wordpress and this theme. Thank you. -->

		<div class="alignright">
   			<p>G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a> 
		en <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?> &nbsp;&bull;&nbsp; Facebook Look 2 by <a href="http://diameter.web.id/">Diameter</a>&nbsp;&bull;&nbsp; <a href="<?php $plxShow->urlRewrite('#header') ?>">Haut de page</a></p>
		</div>
    
	</div>

</div>
        
</body>
</html>