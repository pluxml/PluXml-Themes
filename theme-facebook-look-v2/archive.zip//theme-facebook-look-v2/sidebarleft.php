<div id="sidebarL">
	<ul>
    	<!-- Home & RSS links -->
		<li class="top selected"><a href="#">Nos Flux</a></li>
			<li><a href="<?php $plxShow->urlRewrite('feed.php?atom/commentaires') ?>" title="Fil Atom des commentaires">Commentaires</a></li>
			<li><a href="<?php $plxShow->urlRewrite('feed.php?atom') ?>" title="Fil Atom des articles">Articles</a></li> 
	</ul>
</div>