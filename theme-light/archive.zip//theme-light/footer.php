<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		| Templates par <a href="http://uberpxl.dixkey.com" title="�berPXL - templates, ressources graphiques, int�gration.">�berPXL</a>
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
	</p>
</div>

</body>
</html>