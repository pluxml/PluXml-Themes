<div id="sidebar">

<div id="static"><h2><?php $plxShow->staticList('Accueil'); ?></h2></div>
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList(''); ?>
		</ul>
	</div>
	<div id="syndication">
		<h2>Syndication</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
	</div>
</div>
<div class="clearer"></div>