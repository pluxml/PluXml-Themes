<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<title><?php __('pagetitle'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" type="text/css" href="<?php __('template'); ?>/style.css" media="screen" />
	<link rel="icon" type="image/gif" href="<?php __('template'); ?>/imagenes_qwilm/favicon.gif" />
	<link rel="alternate" type="application/rss+xml" title="Rss" href="core/rss.php" />
	<link rel="alternate" type="application/atom+xml" title="Atom" href="core/atom.php" />
</head>

<body>
<div id="mini-nav">
	<a href="<?php echo $pluxml->config['racine']; ?>"><img src="<?php __('template'); ?>/imagenes_qwilm/home_icon.gif" alt="Accueil" title="Accueil" /></a>
	<a href="mailto:votre_mail@mail.fr"><img src="<?php __('template'); ?>/imagenes_qwilm/email_icon.gif" alt="Contact" title="Contact" /></a>
	<a href="core/rss.php"><img src="<?php __('template'); ?>/imagenes_qwilm/rss_icon.gif" alt="syndication" title="syndication" /></a>	
</div>

<div id="wrapper">
	<div id="content">
		
	  <?php # En mode 'home' ou 'cat�gorie' # ?>
	  <?php if($pluxml->mode == 'home' || $pluxml->mode =='cat') : ?>
		 <?php # Liste d'articles # ?>
		 <?php while($pluxml->result->loop()):?>
		<div class="post">
			<h2 class="post-titulo"><?php __('title', 'link'); ?></h2>
			<p class="postmeta">Par <?php __('author'); ?>, le <?php __('date'); ?> &#183; dans <?php __('categorie'); ?></p>
			<?php __('chapo'); ?>
			<p class="comentarios-link"><?php __('nb_com'); ?></p>
		</div>
		 <?php endwhile; ?>

		<div style="text-align: center;"><?php __('pagination'); ?></div>
	  <?php endif; ?>
	  <?php # Fin mode 'home'/'cat�gorie' # ?>
	  
	  <?php # En mode 'article' # ?>
	  <?php if($pluxml->mode == 'article') : ?>
		<div class="post">
	  <?php # Liste d'articles # ?>
	  <?php while($pluxml->result->loop()):?>
			<h2 class="post-titulo"><?php __('title'); ?></h2>
			<p class="postmeta">Par <?php __('author'); ?>, le <?php __('date'); ?> &#183; dans <?php __('categorie'); ?></p>
			<?php __('content'); ?>
	  <?php endwhile; ?>
		
	  <?php if($pluxml->coms):?>	
			<div id="comments">
				<h2>Commentaires</h2>
	  <?php while($pluxml->coms->loop()):?>
				<div class="comment <?php echo 'ligne'.$pluxml->coms->i%2 ?>">
					<p>Par <?php __('com_author', 'link'); ?> le <?php __('com_date'); ?></p>
					<blockquote><p><?php __('com_content'); ?></p></blockquote>
				</div>
	  <?php endwhile; ?>
			</div>
	  <?php endif; ?>
	
	  <?php if($pluxml->config['allow_com'] == 1 && $pluxml->result->f('allow_com') == 1) : ?>
			<div id="form">
				<h2>Ecrire un commentaire</h2>
				<form action="index.php?<?php echo $pluxml->get; ?>" method="post">
					<fieldset>
						<label>Nom&nbsp;:</label>
						<input name="name" type="text" size="30" value="" /><br />
						<label>Site (facultatif)&nbsp;:</label>
						<input name="site" type="text" size="30" value="http://" /><br />
						<label>E-mail (facultatif)&nbsp;:</label>
						<input name="mail" type="text" size="30" value="" /><br />
						<label>Commentaire&nbsp;:</label>
						<textarea name="message" cols="35" rows="8"></textarea>
				
				<?php # affichage du capcha anti-spam
				if($pluxml->config['capcha'] == 1){
					echo '<label><strong>V�rification anti-spam</strong>&nbsp;:</label>';
					echo '<p>'.$capcha->q().'&nbsp;<input name="rep" type="text" size="10" /></p>';
					echo '<input name="rep2" type="hidden" value="'.$capcha->r().'" />';
				} ?>
				
						<p><input type="submit" value="Envoyer" /></p>
					</fieldset>
				</form>
			</div>
	  <?php endif; ?>
		</div>
	  <?php endif; ?>
	  <?php # Fin mode 'article' # ?>
	</div>

	<div id="sidebar-1" class="sidebar">
	<ul>
	  <li>
	  <li>
		<h2>Cat&eacute;gories</h2>
		  <?php __('catlist'); ?>
	  </li>
	  <li id="linkcat-9" class="linkcat">
	    <h2>Liens</h2>
		  <ul>
			<li><a href="http://blogotheme.free.fr">BlogoTh�me</a></li>
			<li><a href="http://pluxml.org/">Pluxml</a></li>
			<li><a href="http://pluxgins.tuxfamily.org/">PluxGins</a></li>
		  </ul>
	  </li>
	</ul>
	</div>

	<div id="sidebar-2" class="sidebar">
	<ul>
 	  <li>
		<h2>A propos</h2>
		  <p><?php __('subtitle'); ?></p>
	  </li>
	  <li>
	    <h2>Meta</h2>
		  <ul>
			<li><?php __('rss'); ?></li>
			<li><?php __('atom'); ?></li>
			<li><a href="core/admin/">Administration</a></li>
		  </ul>
	  </li>
	  <li>
		<h2>Cr�dits</h2>
		<p>G�n�r� par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn�es">Pluxml</a> et th�me par <a href="http://oriol.f2o.org" title="Qwilm!">Qwilm!</a>.</p><!-- please dont remove, or if u remove link oriol.f2o.org in another part of your site -->
	  </li>
    </ul>
	</div>

	<div id="logo" class="sidebar">
	  <div style="text-align: center;">
		<a href="<?php echo $pluxml->config['racine']; ?>"><img src="<?php __('template'); ?>/imagenes_qwilm/logo.gif" alt="<?php __('maintitle'); ?>" /></a>
	  </div>
	</div>

</div>
</body>
</html>
