<?php if(!defined('PLX_ROOT')) exit; ?>

	<div class="abs footer_lower chrome_light">
		<a href="<?php $plxShow->urlRewrite('core/admin/') ?>" class="icon icon_gear2 float_left"></a>
		<span class="float_right gutter_right">Administration</span>
	</div>
</div>
</body>
</html>
