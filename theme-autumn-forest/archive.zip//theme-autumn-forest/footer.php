<?php if(!defined('PLX_ROOT')) exit; ?>
	</div><!-- #container -->
</div></div></div><!-- #universe -->

<hr class="hide" />

<div id="footer-a">
	<div id="footer-b">
		<p>Adaptation sous <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> de <a href="http://wordpress.org/extend/themes/autumn-forest">Autumn Forest</a> par <a href="http://www.flox-arts.net">Flox-arts.net</a> |
		<a href="core/admin/">Admin</a> | 
		<a href="#top">Remonter</a></p>
   	</div>
</div><!-- #footer -->

</body>
</html>