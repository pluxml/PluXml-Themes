<?php if(!defined('PLX_ROOT')) exit; ?>
</div><!-- /contentwrap -->

</div><!-- /wrap -->

<div class="footer">
<!-- FOOTER CREDITS LINK -->	
<big><strong>&copy; <?php $plxShow->mainTitle('link'); ?></strong></big> |  
		G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a> 
		en <?php $plxShow->chrono(); ?>  
		<?php $plxShow->httpEncoding() ?> | <a href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="Administration">Administration</a> | <a href="<?php echo $plxShow->urlRewrite('#top') ?>" title="Remonter en haut de page">Haut de page</a>
<br /><br />
<small><strong><a href="http://www.freethemelayouts.com/" style="color: #6C6C6C;text-decoration: none;" title="Free WordPress Themes">Free WordPress Themes</a> by [i] <a href="http://www.iwebsitetemplate.com" style="color: #6C6C6C;text-decoration: none;" title="Website Templates">Website Templates</a></strong></small>

</div>

</body>
</html>