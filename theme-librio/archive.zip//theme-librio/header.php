<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="content-type" content="text/html charset=<?php $plxShow->charset(); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/style.css" media="screen" />
	<!--[if IE]><link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/ie.css" media="screen" /><![endif]-->
	<link rel="alternate" type="application/atom+xml" title="Atom articles" href="./feed.php?atom" />
	<link rel="alternate" type="application/rss+xml" title="Rss articles" href="./feed.php?rss" />
	<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="./feed.php?atom/commentaires" />
	<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="./feed.php?rss/commentaires" />
	<meta name="robots" content="follow,index" />
	<meta name="description" content="<?php $plxShow->subTitle(); ?>" />
	<meta name="generator" content="Pluxml <?php $plxShow->version(); ?>" />
	<title><?php $plxShow->pageTitle(); ?></title>
</head>
<body>
<div id="container">
	<div id="header">
		<h1><?php $plxShow->mainTitle('link'); ?><span><?php $plxShow->subTitle(); ?></span></h1>
	</div>
	<div id="nav">
		<ul>
			<?php $plxShow->staticList('Accueil'); ?>
		</ul>
		<a href="./feed.php?atom" id="feed">Fil des articles</a>
	</div>
	<div id="wrapper">