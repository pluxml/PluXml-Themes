<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div class="block">
		<h3>Derniers articles</h3>
		<ul>
			<?php $plxShow->lastArtList(); ?>
		</ul>
	</div>
	<div class="block">
		<h3>Cat&eacute;gories</h3>
		<ul>
			<?php $plxShow->catList('', '<li><a href="#cat_url" title="#cat_name">#cat_name (#art_nb)</a></li>'); ?>
		</ul>
	</div>
</div>
