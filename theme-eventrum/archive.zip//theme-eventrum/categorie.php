<?php include(dirname(__FILE__).'/header.php'); ?>

<section id="content">
	<div class="container">
		<div class="row">
			<div class="grid_12">
				<h4><?php $plxShow->catName(); ?></h4>
			</div>
			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
				  <div class="grid_4" role="article" id="post-<?php echo $plxShow->artId(); ?>">
					<div class="box">
					  <div class="maxheight">
						<img src="<?php eval($plxShow->callHook("showVignette", "true")); ?>" alt="">
						<div class="box_bot">
						  <p class="text1 offset__1"><?php $plxShow->artTitle('link'); ?></p>
						  <?php $plxShow->artChapo(''); ?> <br>
						  <a href="<?php $plxShow->artUrl(); ?>" class="link1">Lire</a>
						</div>
					  </div>
					</div>
				  </div>
			<?php endwhile; ?>
		</div>
	</div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
