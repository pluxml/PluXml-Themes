<?php include(dirname(__FILE__).'/header.php'); ?>

<section id="content">
  <div class="container" role="article" id="static-page-<?php echo $plxShow->staticId(); ?>">
    <div class="row">
      <div class="grid_9">
        <h4><?php $plxShow->staticTitle(); ?></h4>
        <div class="row">
          <div class="grid_8">
			<?php $plxShow->staticContent(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
