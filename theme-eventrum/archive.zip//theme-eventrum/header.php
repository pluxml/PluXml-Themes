<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php $plxShow->pageTitle(); ?></title>
<?php $plxShow->meta('description') ?>
<?php $plxShow->meta('keywords') ?>
<?php $plxShow->meta('author') ?>
<link rel="icon" href="<?php $plxShow->template(); ?>/images/favicon.ico">
<link rel="shortcut icon" href="<?php $plxShow->template(); ?>/images/favicon.ico" />
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/touchTouch.css">
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/contact-form.css">
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/style.css">
<script src="<?php $plxShow->template(); ?>/js/jquery.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery-migrate-1.1.1.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.easing.1.3.js"></script>
<script src="<?php $plxShow->template(); ?>/js/script.js"></script> 
<script src="<?php $plxShow->template(); ?>/js/superfish.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.equalheights.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.mobilemenu.js"></script>
<script src="<?php $plxShow->template(); ?>/js/tmStickUp.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.ui.totop.js"></script>
<script src="<?php $plxShow->template(); ?>/js/touchTouch.jquery.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.shuffle-images.js"></script>

<script>
  $(window).load(function(){
    $().UItoTop({ easingType: 'easeOutQuart' });
    $('.gallery .info').touchTouch();
  }); 

   $(document).ready(function(){
       $(".shuffle-me").shuffleImages({
         target: ".images > img"
       });
    });
</script>
<!--[if lt IE 8]>
 <div style=' clear: both; text-align:center; position: relative;'>
   <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
     <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
   </a>
</div>
<![endif]-->
<!--[if lt IE 9]>
<script src="<?php $plxShow->template(); ?>/js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="<?php $plxShow->template(); ?>/css/ie.css">
<![endif]-->
</head>

<body class="page1" id="top">
  <div class="main">
<!--==============================
              header
=================================-->
<header>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h1>
          <a href="index.html">
            <img src="<?php $plxShow->template(); ?>/images/logo.png" alt="Logo alt">
          </a>
        </h1>
        <div class="socials">
          <a href="#" class="fa fa-twitter"></a>
          <a href="#" class="fa fa-facebook"></a>
          <a href="#" class="fa fa-google-plus"></a>
        </div>
        <div class="navigation ">
          <nav>
            <ul class="sf-menu">
				<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
				<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
           </ul>
          </nav>
          <div class="clear"></div>
        </div>       
      </div>
    </div>
  </div>
</header>
