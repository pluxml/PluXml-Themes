<?php include(dirname(__FILE__).'/header.php'); ?>

<!--=====================
          Content
======================-->
<section id="content">
  
	<div class="shuffle-group">
		<div class="container">
			<div class="row">
				<div class="grid_8">
				   <div data-si-mousemove-trigger="100" class="shuffle-me">
						<a href="/categorie1/" class="info">	
							<div class="shuffle_title">Première catégorie<span>ouvrir</span></div>
						</a>
						<div class="images">
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '1','', "sort"))); ?>
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '1','', "sort"))); ?>
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '1','', "sort"))); ?>
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '1','', "sort"))); ?>
						</div>
					</div>
				</div>
				<div class="grid_4">
				   <div data-si-mousemove-trigger="100" class="shuffle-me shuff__1">
						<a href="#" class="info">
							<div class="shuffle_title">Deuxième catégorie<span>ouvrir</span></div>
						</a>
						<div class="images">
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '2','', "sort"))); ?>
						</div>
					</div>
					 <div data-si-mousemove-trigger="100" class="shuffle-me shuff__1">
						<a href="#" class="info">
							<div class="shuffle_title">Troisième catégorie<span>ouvrir</span>
							</div>
						</a>
						<div class="images">
							<?php eval($plxShow->callHook("vignetteArtList", array('
								<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" />
								', 3, '1','', "sort"))); ?>
						</div>
					</div>
				</div>
				<div class="grid_12">
				  <h3>Bienvenue</h3>
				  <img src="<?php $plxShow->template(); ?>/images/page1_img7.jpg" alt="" class="img_inner fleft">
				  <div class="extra_wrapper">
					<p class="text1">Follow the link to find information about this <a href="http://blog.templatemonster.com/free-website-templates/" class="color1"  rel="nofollow">freebie</a>. </p>
					<p class="text1 offset__1">Want more <a href="http://www.templatemonster.com/category/event-planner-wordpress-themes/" rel="nofollow" class="color1">goodies</a> of this kind? Visit TemplateMonster.com</p>
					Curabitur vel lorem sit amet nulla ullamcorper fermentum. In vitae varius augue, eu consectetur ligula. Etiam dui eros, laoreet site amet est vel, commodo venenatis eros. Fusce adipiscing quam id risus sagittis, non consequat lacus interdum. Proin ut tinciduntl nulla, eu sodales arcu. Quisque viverra nulla nunc, eu ultrices libero ultricies eget. Phasellus accumsan justo vitae feugiat  placer. Praesent vel ultrices velit. Suspendisse risus justo, lacinia vitae eleifend sed, cursus sit amet massa. <br> <a href="#" class="link1">More</a>
				  </div>
        </div>
      </div>
    </div>
  </div>  
  <div class="container gallery">
    <div class="row">
      <div class="grid_8">
        <h4>Recent Events</h4>
        <div class="row">
			<?php eval($plxShow->callHook("vignetteArtList", array('
			 <div class="grid_4">
				<div class="view">  
					<img src="img.php?src=#art_vignette&w=770&h=504&crop-to-fit" alt="#art_title"/>
					<div class="mask">
						<a href="#art_vignette" class="info fa fa-search" title="Full Image"></a>  
					</div>
				</div> 
			</div>', 4, '','', "sort"))); ?>
        </div>
      </div>
      <div class="grid_4">
        <h4>Témoignages</h4> 
        <blockquote class="bq1">
          <img src="<?php $plxShow->template(); ?>/images/page1_img12.jpg" alt="">
          <div class="extra_wrapper">
            <p>“Curabitur vel lorem sit amet nulla erero fermentum. In vitae varius auguectetu ligula. Etiam dui eros, laoreet site am est vel commodo venenatisipiscing... ”</p>
            <div class="color2">- Eva Smith, Client</div>
          </div>
        </blockquote>
        <blockquote class="bq1">
          <img src="<?php $plxShow->template(); ?>/images/page1_img13.jpg" alt="">
          <div class="extra_wrapper">
            <p>“Hurabitur vel lorem sit amet nulla erero fermentum. In vitae varius auguectetu ligula. Etiam dui eros, laoreet site am est vel commodo venenatisipgolo... ”</p>
            <div class="color2">- Mike Brown, Client</div>
          </div>
        </blockquote>
      </div>
    </div>
  </div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
