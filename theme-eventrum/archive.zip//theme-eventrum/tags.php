<?php include(dirname(__FILE__).'/header.php'); ?>

<!--=====================
          Content
======================-->
<section id="content">
  <div class="container" role="article" id="post-<?php echo $plxShow->artId(); ?>">
    <div class="row">
      <div class="grid_9">
        <h4><?php $plxShow->lang('TAGS'); ?></h4>
        <div class="row">
          <div class="grid_8">
				<h1><?php $plxShow->tagName(); ?></h1>	

			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

			<article class="article" role="article" id="post-<?php echo $plxShow->artId(); ?>">

				<header>
					<h1>
						<?php $plxShow->artTitle('link'); ?>
					</h1>
					<small>
						<?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?> -
						<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></time> -
						<?php $plxShow->artNbCom(); ?>
					</small>
				</header>

				<section>
					<?php $plxShow->artChapo(); ?>
				</section>

				<footer>
					<small>
						<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?> - 
						<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
					</small>
				</footer>

			</article>

			<?php endwhile; ?>

			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>

			<span>
				<?php $plxShow->tagFeed() ?>
			</span>

            <div class="clear"></div>
          </div>
        </div>
        <h4 class="head__1">Notre équipe</h4>
        <div class="row">
          <div class="grid_3">
            <div class="block2">
              <div class="maxheight">
                <img src="<?php $plxShow->template(); ?>/images/page2_img1.jpg" alt="" class="img_inner">
                <div class="color2">- Irma Grey</div>
                <em class="italic">Fusce adipiscing quam id risus sagitti...</em>
              </div>
            </div>
          </div>
          <div class="grid_3">
            <div class="block2">
              <div class="maxheight">
                <img src="<?php $plxShow->template(); ?>/images/page2_img2.jpg" alt="" class="img_inner">
                <div class="color2">- Tim Haddon</div>
                <em class="italic">Tusce adipiscing quam id risus sagitto...</em>
              </div>
            </div>
          </div>
          <div class="grid_3">
            <div class="block2">
              <div class="maxheight">
                <img src="<?php $plxShow->template(); ?>/images/page2_img3.jpg" alt="" class="img_inner">
                <div class="color2">- Ann Petters</div>
                <em class="italic">Fusce adipiscing quam id risus sagitti...</em>
              </div>
            </div>
          </div>
        </div>
      </div>
		<?php include(dirname(__FILE__).'/sidebar.php'); ?>
    </div>
  </div>
</section>




<?php include(dirname(__FILE__).'/footer.php'); ?>
