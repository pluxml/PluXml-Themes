<?php include('header.php'); # On insere le header ?>
<div id="content">
	<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
	<div class="post">
		<h1 class="post-title"><?php $plxShow->artTitle('link'); ?></h1>
		<?php $plxShow->artChapo(); ?>
		<div class="post-info"><?php $plxShow->artDate(); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?> | <?php $plxShow->artNbCom(); ?>
		</div>
	</div>
	<?php endwhile; # Fin de la boucle sur les articles ?>
	<div id="pages">
		<?php $plxShow->pagination(); ?>
	</div>
</div>

<?php include('sidebar.php'); # On insere la sidebar ?>
<?php include('footer.php'); # On insere le footer ?>