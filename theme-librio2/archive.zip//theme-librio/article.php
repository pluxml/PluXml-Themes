<?php include('header.php'); # On insere le header ?>
<div id="content">
	<div class="post">
		<h1 class="post-title"><?php $plxShow->artTitle(); ?></h1>
		<?php $plxShow->artContent(); ?>
		<div class="post-info"><?php $plxShow->artDate(); ?> | Par <?php $plxShow->artAuthor(); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?>
		</div>
	</div>
	<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
	<h1 class="comments-title"><?php $plxShow->artNbCom(); ?></h1>
	<div id="comments">
		<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
		<div class="comment" id="comment-<?php $plxShow->comId(); ?>">
			<div class="comment-avatar">
				<img alt="" src="<?php echo "http://www.gravatar.com/avatar/".md5($plxShow->plxMotor->plxRecord_arts->f('mail'))."?d=".urlencode($plxShow->plxMotor->racine.'themes/'.$plxShow->plxMotor->style.'/gravatar.jpg')."&amp;s=50"; ?>" height="50" width="50" />
			</div>
			<div class="comment-content">
				<div class="comment-info"><span><?php $plxShow->comAuthor('link'); ?></span><?php $plxShow->comDate(); ?></div>
				<?php $plxShow->comContent() ?>
			</div>
		</div>
		<?php endwhile; # Fin de la boucle sur les commentaires ?>
		<?php # On affiche le fil Atom de cet article ?>
		<div class="t-center"><?php $plxShow->comFeed('atom',$plxShow->artId()); ?></div>
	</div>
	<?php endif; # Fin du if sur la prescence des commentaires ?>
	<?php # Si on autorise les commentaires ?>
	<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
	<h1 class="comments-title">Laisser un message</h1>
		<form action="<?php $plxShow->artUrl(); ?>#commentform" method="post" id="commentform">
			Votre commentaire
			<p><textarea name="content" id="comment"><?php $plxShow->comGet('content',''); ?></textarea></p>		
			<p><input type="text" name="name" id="author" class="text" value="<?php $plxShow->comGet('name',''); ?>" />
			<label for="author">Nom </label></p>
			<p><input type="text" name="mail" id="email" class="text" value="<?php $plxShow->comGet('mail',''); ?>" />
			<label for="email">Mail</label></p>
			<p><input type="text" name="site" id="url" class="text" value="<?php $plxShow->comGet('site','http://'); ?>" />
			<label for="url">Site (facultatif)</label></p>
			<?php # Affichage du capcha anti-spam
			if($plxShow->plxMotor->aConf['capcha']): ?>
				<label for="captcha"><strong>V&eacute;rification anti-spam</strong>&nbsp;:</label>
				<p><?php $plxShow->capchaQ(); ?><br />
				<input name="rep" type="text" id="captcha" class="text" size="10" /></p>
				<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
			<?php endif; # Fin du if sur le capcha anti-spam ?>
			<p><input name="submit" type="submit" id="submit" value="Envoyer" /></p>
		</form>
	<?php endif; # Fin du if sur l'autorisation des commentaires ?>
</div>
<?php include('sidebar.php');?>
<?php include('footer.php');?>