<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div class="block">
		<h3>Derniers articles</h3>
		<ul>
			<?php $plxShow->lastArtList(); ?>
		</ul>
	</div>
	<div class="block">
		<h3>Cat&eacute;gories</h3>
		<ul>
			<?php $plxShow->catList('','#cat_name (#art_nb)'); ?>
		</ul>
	</div>
</div>