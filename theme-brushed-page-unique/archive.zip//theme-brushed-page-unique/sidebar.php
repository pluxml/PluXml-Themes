<?php if(!defined('PLX_ROOT')) exit; ?>

      <div class="grid_3"  role="complementary">

		<h4><?php $plxShow->lang('CATEGORIES'); ?></h4>
        <ul class="list1">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
        </ul>

		<h4><?php $plxShow->lang('LATEST_ARTICLES'); ?></h4>
        <ul class="list">
			<?php eval($plxShow->callHook("vignetteArtList", '
          <li>
            <div class="count"><img src="img.php?src=#art_vignette&w=42&h=42&crop-to-fit" /></div>
            <div class="extra_wrapper">
            <p class="text1 offset__1"><a href="#art_url">#art_title</a></p>
            #art_chapo
			</div>
          </li>')); ?>	
        </ul>
		 <h4><?php $plxShow->lang('TAGS'); ?></h4>
		<ul class="tag-list">
			<?php $plxShow->tagList('<li class="tag #tag_size"><a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a></li>', 20); ?>
		</ul>

      </div>
