<?php if (!defined('PLX_ROOT')) exit; ?>

<!--==============================
              footer
=================================-->
<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="grid_12"> 
        <div class="copyright">
			<a href="#" class="f_logo"><img src="<?php $plxShow->template(); ?>/images/f_logo.png" alt=""></a> &copy; <span id="copyright-year"></span> | <a href="#">PluXml.org</a>
          <div class="sub_copyright">
            Gabarit par TemplateMonster
			- <a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
          </div>
        </div>
      </div>
    </div>

  </div>  
</footer>
<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</div>
</body>

</html>

