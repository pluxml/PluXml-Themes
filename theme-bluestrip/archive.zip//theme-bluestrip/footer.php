<div id="footer">
	G&eacute;n&eacute;r&eacute; par 
	<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
	<?php $plxShow->version(); ?> 
	en <?php $plxShow->chrono(); ?> | 
	<a href="core/admin/">Administration</a> | 
	<a href="#top">Haut de page</a>
	<br />
	<a href="http://www.free-css-templates.com/">Designed by Free CSS Templates</a>, Thanks to <a href="http://www.legalhelpers.com/bankruptcy-information.html">Bankruptcy Information</a>
</div>

</div>

</body>
</html>