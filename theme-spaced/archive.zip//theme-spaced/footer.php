<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | 
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
	</p>
	
	<p>Design: <a href="http://www.spyka.net" title="spyka Webmaster">spyka webmaster</a> available from <a href="http://www.justfreetemplates.com" title="free css templates">Just Free Templates</a>. </p>
</div>
</div>
</body>
</html>