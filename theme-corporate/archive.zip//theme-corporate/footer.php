<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> | design by <a href="http://www.clicali.tel" title="Clicali" target="blank">Clicali</a><br /><a href="core/admin/">Administration</a> | <a href="#top" title="">Haut de page</a></p>
</div>
	</div>
</body>
</html>
