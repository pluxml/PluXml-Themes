jQuery(document).ready(function () {
    jQuery('.sb-search').click(function () {
        jQuery('.masonic-search-toggle').slideToggle('slow');
    });
});
jQuery(document).ready(function () {
    jQuery('.sb-search-res').click(function () {
        jQuery('.masonic-search-toggle').slideToggle('slow');
    });
});