/*
 * FitVids Setting
 */
jQuery(document).ready(function () {
   jQuery(".responsive-video").fitVids();
});