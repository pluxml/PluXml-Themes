<?php

$LANG = array(

'L_MESSAGE'				=>	'Inserisci il codice',	,
'L_MESSAGE_MAL_VOYANT'	=> 	'Cochez la case si vous avez des difficultés à visionner l\'image &rarr;'

);
?>
