<?php

$LANG = array(

'L_MESSAGE'				=>	'Geef de code van de afbeelding',
'L_MESSAGE_MAL_VOYANT'	=> 	'Cochez la case si vous avez des difficultés à visionner l\'image &rarr;'

);

?>
