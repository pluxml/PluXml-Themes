<?php

		$LANG = array(
			'L_RETOUR'				=> 'Retour &agrave; l\'accueil de',
		);

?>
