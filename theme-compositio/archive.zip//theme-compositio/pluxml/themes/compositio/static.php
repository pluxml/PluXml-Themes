<?php include(dirname(__FILE__).'/header.php'); ?>

	<div style="margin-bottom: 30px;">

		<div class="p-head">
			<h1><?php $plxShow->staticTitle(); ?></h1>
		</div>

		<div class="p-con">
			<?php $plxShow->staticContent(); ?>

		</div>
	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>
