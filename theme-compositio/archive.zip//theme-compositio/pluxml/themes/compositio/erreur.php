<?php include(dirname(__FILE__).'/header.php'); ?>

<!-- Container -->
<div class="CON">

<!-- Start SC -->
<div class="SC">

<h2 class="title"><?php $plxShow->lang('ERROR') ?> :</h2>
<div class="error-content"><?php $plxShow->erreurMessage(); ?></div>

</div>
<!-- End SC -->

</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>
