<?php include(dirname(__FILE__).'/header.php'); ?>

<div id="content-wrapper">

	<div id="content">
	
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
	
		<h3 class="post-title"><?php $plxShow->artTitle('link'); ?></h3><br />
		<span class="date"><?php $plxShow->lang('WRITTEN_BY') ?> <?php $plxShow->artAuthor() ?> le <?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></span>
		
		<p><?php $plxShow->artChapo(); ?></p>

		<div class="commentbox"><?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat(); ?> - <?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags(); ?> - <?php $plxShow->artNbCom(); ?></div>
		
		<?php endwhile; ?>

		<p id="pagination"><?php $plxShow->pagination(); ?></p>
		
	</div>

</div>

<?php include(dirname(__FILE__).'/sidebar.php'); ?>
<?php include(dirname(__FILE__).'/footer.php'); ?>