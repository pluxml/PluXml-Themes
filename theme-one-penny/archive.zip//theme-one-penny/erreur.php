<?php include(dirname(__FILE__).'/header.php'); ?>

<div id="content-wrapper">

	<div id="content">
	
		<h3 class="post-title"><?php $plxShow->lang('ERROR') ?></h3><br />
		<p><?php $plxShow->erreurMessage(); ?></p>
		
	</div>

</div>

<?php include(dirname(__FILE__).'/sidebar.php'); ?>
<?php include(dirname(__FILE__).'/footer.php'); ?>