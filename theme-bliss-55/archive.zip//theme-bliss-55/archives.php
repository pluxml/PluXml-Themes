<?php include(dirname(__FILE__).'/header.php'); ?>

<section class="content">
  <div class="container">
    <div class="row">
      <div class="grid_7">
        <h2>
			<?php echo plxDate::formatDate($plxShow->plxMotor->cible, $plxShow->lang('ARCHIVES').' #month #num_year(4)') ?>
		</h2>
		
		<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

			<div class="blog">
			  <div class="blog_title"><?php $plxShow->artTitle('link'); ?></div>
				<img src="<?php $plxShow->artThumbnail('#img_url'); ?>" width="671" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" title="<?php $plxShow->artThumbnail('#img_title'); ?>">
				<?php $plxShow->artChapo(); ?>
			  <table>
			  <tbody>
				<tr>
				  <td><time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>">
					<span class="fa fa-calendar"></span>
					<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>   
				  </time> </td>
				  <td><a href="."><div class="fa fa-user"></div> <?php $plxShow->artAuthor() ?></a></td>
				  <td><a href=" <?php $plxShow->artUrl() ?>"><span class="fa fa-link"></span></a></td>
				</tr>
				<tr>
				  <td><div class="fa fa-bookmark"></div> <?php $plxShow->artCat() ?>  </td>
				  <td colspan="2"><div class="fa fa-tag"></div> <?php $plxShow->artTags() ?></td>
				</tr>
				<tr>
				  <td><div class="fa fa-comments"></div> <?php $plxShow->artNbCom(); ?></td>
				  <!--td colspan="2"><div class="fa fa-eye"></div>182
				  <div class="fa fa-thumbs-up"></div>0
				  <div class="fa fa-thumbs-down"></div>0</td-->
				</tr>
			  </tbody>
			</table>
			  <a href="<?php $plxShow->artUrl() ?>" class="btn">Lire l'article</a>
			</div>
			
		<?php endwhile; ?>

		<nav class="pagination text-center" style="margin-top:30px;">
			<?php $plxShow->pagination(); ?>
		</nav>
		<span>
				<?php $plxShow->artFeed('rss',$plxShow->catId()); ?>
		</span>

	</div>
	<?php include(dirname(__FILE__).'/sidebar.php'); ?>
</div>
</div>
</section>



<?php include(dirname(__FILE__).'/footer.php'); ?>

