<?php include(dirname(__FILE__).'/header.php'); ?>

<section class="content">
  <div class="container">
    <div class="row">
		<?php 
		$i=1;
		$max=3;  //devrait Ãªtre un multiple de 3
		while($plxShow->plxMotor->plxRecord_arts->loop()): 	?>
			<?php 
		    if ($i <= $max) { 
				if (0 == $i % 2) { ?>
					<div class="grid_4">
						<div class="banner">
							<div class="gall_block">
								<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=368&h=303&crop-to-fit" class="attachment-bigthumb size-bigthumb" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" title="<?php $plxShow->artThumbnail('#img_title'); ?>" />																
								<div class="bann_capt ">
									<div class="maxheight">
										<img src="<?php $plxShow->template(); ?>/images/icon<?php echo $i;?>.png">
										<div class="bann_title"><?php $plxShow->artTitle('link'); ?></div>
										<a href="<?php $plxShow->artUrl(); ?>">En savoir plus</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php 
				}else{ ?>
					<div class="grid_4">
						<div class="banner">
							<div class="gall_block">
								<div class="bann_capt  bn__1">
									<div class="maxheight">
										<img src="<?php $plxShow->template(); ?>/images/icon<?php echo $i;?>.png">
										<div class="bann_title"><?php $plxShow->artTitle('link'); ?></div>
										<a href="<?php $plxShow->artUrl(); ?>">En savoir plus</a>
									</div>
								</div>
								<img src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=368&h=303&crop-to-fit" class="attachment-bigthumb size-bigthumb" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" title="<?php $plxShow->artThumbnail('#img_title'); ?>" />																
							</div>
						</div>
					</div>
				<?php 
				} 
			}  
			$i=$i+1;
		endwhile; ?>
	  
      <div class="grid_4">
        <div class="block1">
          <div class="count">1.</div>
			<?php $plxShow->lastArtList('<a class="#art_status" href="#art_url" title="#art_title">#art_chapo</a><br><a href="#art_url" class="btn">En savoir plus</a>',1,'1'); ?>
        </div>
      </div>
      <div class="grid_4">
        <div class="block1">
          <div class="count">2.</div>
			<?php $plxShow->lastArtList('<a class="#art_status" href="#art_url" title="#art_title">#art_chapo</a><br><a href="#art_url" class="btn">En savoir plus</a>',1,'1'); ?>
        </div>
      </div>
      <div class="grid_4">
        <div class="block1">
          <div class="count">3.</div>
			<?php $plxShow->lastArtList('<a class="#art_status" href="#art_url" title="#art_title">#art_chapo</a><br><a href="#art_url" class="btn">En savoir plus</a>',1,'1'); ?>
        </div>        
      </div>
      <div class="grid_12">
        <div class="box">
          <div class="row">
            <div class="grid_5 preffix_1">
              <h2>Texte de gauche</h2>
              <p>Post about this <strong class="color1"><a href="." rel="nofollow">freebie</a></strong> will tell all you need to know about it. Need a good choice of <strong class="color1"><a href="." rel="nofollow">themes</a></strong>? Visit TemplateMonster’s website.</p>
              Aliquam nibh e,estas id dictum a, commodo. Praesent faucibus malesuada faucibusonec laeet metus id laoreet malesuadarem ipsum dolor sit <br>
              <!--a href="#" class="btn">more</a-->
            </div>
            <div class="grid_5">
              <h2>Texte de droite</h2>
              Dervamus at magna non nunc tristique rhoncus. Aliquam nibh ante, egestas id dictum a, commodo. Praesent faucibus malesuada ucibus. Donec laeet metus id laoreet malesuadarem ipsum dosit ametctetur adipiscing elit. Nullam consectetur orci sed nulla facilisis consequat. Curabitur vel lorem sit amet nulla ullamcorper fermentum. <br>
              <!--a href="#" class="btn">more</a-->
            </div>
          </div>
        </div>
      </div>
      <div class="grid_12">
        <h2>Galerie photo</h2>
      </div>
      <div class="gallery">
		<?php $plxShow->lastArtList('
		<div class="grid_4">
			<a href="#img_url" class="gall_item"><img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=370&h=229&crop-to-fit" alt=""></a><a href="#art_url" class="link1">+</a><div class="clear"></div></div>',3); ?>
      <div class="grid_4">
        <h2>Témoignages</h2>
        <blockquote class="bq1">
          <img src="<?php $plxShow->template(); ?>/images/page1_img7.jpg" alt="" class="img_inner fleft noresize">
          <div class="extra_wrapper">
            <div class="bq_title color1">Mark Wood</div>
            Sivamus at magna non nuncer tristique rhoncus. Aliquame nibh ante, egestas id dictumertolom  commodo. Praesent faucib mal.
            <a href="#"><span class="fa fa-chevron-right"></span>more testimonials</a>
          </div>
        </blockquote>
      </div>
      <div class="grid_4">
        <h2><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
        <?php $plxShow->lastArtList('
		<div class="block2">
          <time datetime="#art_date">#num_day<br>#month</time>
          <div class="extra_wrapper">
            <div class="text1"><a href="#art_url">#art_title</a></div>
				#art_chapo
          </div>
        </div>',2); ?>
      </div>
      <div class="grid_4">
        <h2>Heures d'ouverture</h2>
        <ul class="shed">
          <li><span>Déjeuner:</span> 8AM - 11AM</li>
          <li><span>Dîner:</span> 12AM - 12PM</li>
          <li><span>Musique live:</span> 8AM - 11AM</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<?php include(dirname(__FILE__).'/footer.php'); ?>
