<?php if (!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
<head>
<meta charset="<?php $plxShow->charset('min'); ?>">
<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">
<title><?php $plxShow->pageTitle(); ?></title>
<?php $plxShow->meta('description') ?>
<?php $plxShow->meta('keywords') ?>
<?php $plxShow->meta('author') ?>
<link rel="icon" href="<?php $plxShow->template(); ?>/img/favicon.png" />
<link rel="icon" href="<?php $plxShow->template(); ?>/images/favicon.ico">
<link rel="shortcut icon" href="<?php $plxShow->template(); ?>/images/favicon.ico" />
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/stuck.css">
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/style.css">
<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/touchTouch.css">
<script src="<?php $plxShow->template(); ?>/js/jquery.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery-migrate-1.1.1.js"></script>
<script src="<?php $plxShow->template(); ?>/js/script.js"></script> 
<script src="<?php $plxShow->template(); ?>/js/superfish.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.equalheights.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.mobilemenu.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.easing.1.3.js"></script>
<script src="<?php $plxShow->template(); ?>/js/tmStickUp.js"></script>
<script src="<?php $plxShow->template(); ?>/js/jquery.ui.totop.js"></script>
<script src="<?php $plxShow->template(); ?>/js/touchTouch.jquery.js"></script>


<script>
 $(document).ready(function(){

  $().UItoTop({ easingType: 'easeOutQuart' });
  $('#stuck_container').tmStickUp({});
  $('.gallery .gall_item').touchTouch();

  }); 
</script>
<!--[if lt IE 9]>
 <div style=' clear: both; text-align:center; position: relative;'>
   <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
     <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
   </a>
</div>
<script src="<?php $plxShow->template(); ?>/js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="<?php $plxShow->template(); ?>/css/ie.css">


<![endif]-->





</head>

<body class="page1" id="top">
<!--==============================
              header
=================================-->
<header>
<!--==============================
            Stuck menu
=================================-->
  <section id="stuck_container">
    <div class="container">
      <div class="row">
        <div class="grid_12">
        <h1>
          <a href="index.html">
            <img src="<?php $plxShow->template(); ?>/images/logo.png" alt="Logo alt">
          </a>
        </h1>  
          <div class="navigation">
            <nav>
              <ul class="sf-menu">
				<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
				<?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
             </ul>
            </nav>        
            <div class="clear"></div>
          </div>
        </div>
      </div>
    </div>
  </section> 
</header>        

