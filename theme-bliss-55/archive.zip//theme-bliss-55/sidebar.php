<?php if(!defined('PLX_ROOT')) exit; ?>
	<aside class="aside col sml-12 med-4" role="complementary">

      <div class="grid_4 preffix_1">
        <h2><?php $plxShow->lang('CATEGORIES'); ?></h2>
        <ul class="list">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
        </ul>
 
	 
        <h2><?php $plxShow->lang('LATEST_ARTICLES'); ?></h2>
		<?php $plxShow->lastArtList('
		<div class="block3">
          <img src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=122&h=122&crop-to-fit" alt="" class="img_inner noresize fleft">
          <div class="extra_wrapper">
            <div class="text1 color1">
              <time datetime="#art_date">#num_day #month</time>
              <a href="#art_url">#art_title</a>
            </div>#art_chapo <a href="#art_url" class="color1">[...]</a>
          </div>
        </div>',3); ?>
 

        <h2><?php $plxShow->lang('TAGS'); ?></h2>
        <ul class="list">
			<?php $plxShow->tagList('<li class="tag #tag_size"><a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a></li>'); ?>
		</ul>
 
        <h2><?php $plxShow->lang('LATEST_COMMENTS'); ?></h2>
        <ul class="list">
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
		</ul>
 
        <h2><?php $plxShow->lang('ARCHIVES'); ?></h2>
        <ul class="list">
			<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
		</ul>
 
        <h2>RSS</h2>
        <ul class="list">
			<li><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
			<li><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
		</ul>
      </div>

	</aside>
