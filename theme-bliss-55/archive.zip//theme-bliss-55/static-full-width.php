<?php include(dirname(__FILE__).'/header.php'); ?>

<section class="content">
  <div class="container">
    <div class="row">
        <h2>
			<?php $plxShow->staticTitle(); ?>
		</h2>
		
		<section>
			<?php $plxShow->staticContent(); ?>
		</section>
	</div>
</div>
</section>




		
<?php include(dirname(__FILE__).'/footer.php'); ?>
