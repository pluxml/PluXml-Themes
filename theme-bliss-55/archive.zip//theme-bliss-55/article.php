<?php include(dirname(__FILE__).'/header.php'); ?>

<style>
/* FORM
------------------------------ */

form .col {
	margin-bottom: 1rem;
}
form.inline-form button,
form.inline-form input,
form.inline-form label,
form.inline-form select,
form.inline-form textarea {
	display: inline-block;
	width: auto;
}
form .col.label-centered {
	margin-bottom: 0;
}
form .label-centered label {
	padding-top: .3rem;
}
fieldset {
	border: none;
	padding: 0;
}
legend {
	margin-bottom: 1rem;
	padding: 0;
}
label {
	display: block;
	padding-bottom: .3rem;
}
button,
input,
optgroup,
select,
textarea {
	color: inherit;
	font: inherit;
	margin: 0;
}
button,
input,
select,
textarea {
	border: 1px solid #bbb;
	outline: none;
	padding: .35rem .4rem;
	width: 100%;
}
textarea {
	height: auto;
	overflow: auto;
}
select {
	padding-left: .2rem;
	padding-right: 0;
}
optgroup {
	font-weight: bold;
}
input:focus,
select:focus,
textarea:focus {
	border: 1px solid #258fd6;
}
button,
input[type="button"],
input[type="reset"],
input[type="submit"] {
	background-color: #777;
	border-color: transparent;
	color: #fff;
	cursor: pointer;
	padding-left: .7rem;
	padding-right: .7rem;
	width: auto;
}
button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover {
	background-color: #616161;
}
button[disabled],
input[disabled],
select[disabled],
textarea[disabled],
button[disabled]:hover,
input[disabled]:hover,
select[disabled]:hover,
textarea[disabled]:hover {
	background-color: #ddd;
	color: #777;
	cursor: not-allowed;
}
button::-moz-focus-inner,
input::-moz-focus-inner {
	border: 0;
	padding: 0;
}
input[type="checkbox"],
input[type="radio"] {
	height: auto;
	padding: 0;
	width: auto;
}
input[type="file"] {
	border: none;
	height: auto;
	padding: 0;
}
button.blue,
input[type="button"].blue,
input[type="reset"].blue,
input[type="submit"].blue {
	background-color: #258fd6;
	color: #eee;
}
button.blue:hover,
input[type="button"].blue:hover,
input[type="reset"].blue:hover,
input[type="submit"].blue:hover {
	background-color: #1f77b1;
}
button.green,
input[type="button"].green,
input[type="reset"].green,
input[type="submit"].green {
	background-color: #239c56;
	color: #eee;
}
button.green:hover,
input[type="button"].green:hover,
input[type="reset"].green:hover,
input[type="submit"].green:hover {
	background-color: #1c7943;
}
button.orange,
input[type="button"].orange,
input[type="reset"].orange,
input[type="submit"].orange {
	background-color: #da7418;
	color: #eee;
}
button.orange:hover,
input[type="button"].orange:hover,
input[type="reset"].orange:hover,
input[type="submit"].orange:hover {
	background-color: #b46014;
}
button.red,
input[type="button"].red,
input[type="reset"].red,
input[type="submit"].red {
	background-color: #e43d29;
	color: #eee;
}
button.red:hover,
input[type="button"].red:hover,
input[type="reset"].red:hover,
input[type="submit"].red:hover {
	background-color: #bc2818;
}

/* IMAGE
------------------------------ */

img {
	border: 0;
	height: auto;
	max-width: 100%;
}


</style>

<section class="content">
  <div class="container">
    <div class="row">
      <div class="grid_7">
        <div class="blog">
          <div class="blog_title"><?php $plxShow->artTitle(); ?></div>
				<img src="<?php $plxShow->artThumbnail('#img_url'); ?>" width="671" alt="<?php $plxShow->artThumbnail('#img_alt'); ?>" title="<?php $plxShow->artThumbnail('#img_title'); ?>">
		<?php $plxShow->artContent(); ?>
			  <table>
			  <tbody>
				<tr>
				  <td><time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>">
					<span class="fa fa-calendar"></span>
					<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>   
				  </time> </td>
				  <td><a href="."><div class="fa fa-user"></div> <?php $plxShow->artAuthor() ?></a></td>
				  <td><a href=" <?php $plxShow->artUrl() ?>"><span class="fa fa-link"></span></a></td>
				</tr>
				<tr>
				  <td><div class="fa fa-bookmark"></div> <?php $plxShow->artCat() ?>  </td>
				  <td colspan="2"><div class="fa fa-tag"></div> <?php $plxShow->artTags() ?></td>
				</tr>
				<tr>
				  <td><div class="fa fa-comments"></div> <?php $plxShow->artNbCom(); ?></td>
				  <!--td colspan="2"><div class="fa fa-eye"></div>182
				  <div class="fa fa-thumbs-up"></div>0
				  <div class="fa fa-thumbs-down"></div>0</td-->
				</tr>
			  </tbody>
			</table>
			
			

			<?php include(dirname(__FILE__).'/commentaires.php'); ?>
			
        </div>
      </div>
		<?php include(dirname(__FILE__).'/sidebar.php'); ?>
    </div>
  </div>
</section>



<?php include(dirname(__FILE__).'/footer.php'); ?>
