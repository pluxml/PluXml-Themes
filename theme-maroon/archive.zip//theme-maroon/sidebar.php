<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div id="categories">
		<h2>Cat&eacute;gories</h2>
		<ul>
			<?php $plxShow->catList('Accueil'); ?>
		</ul>
		<h2>Derniers articles</h2>
		<ul>
			<?php $plxShow->lastArtList('<li><a href="#art_url" title="#art_title">#art_title</a></li>'); ?>
		</ul>
		<h2>Derniers commentaires</h2>
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author a dit :</a><br/>#com_content(70)</li>'); ?>
		</ul>
	</div>
	<div id="syndication">
		<h2>Syndication</h2>
		<ul>
			<li><?php $plxShow->artFeed('atom'); ?></li>
			<li><?php $plxShow->comFeed('atom'); ?></li>
		</ul>
	</div>
</div>
<div class="clearer"></div>