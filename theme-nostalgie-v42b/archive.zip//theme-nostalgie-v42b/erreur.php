<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="section">

		<div id="content">
        <div id="breadcrumbs">		
					<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> <?php $plxShow->pageBlog('<a class="#page_status" href="#page_url" title="#page_name">#page_name</a>'); ?>					
            </div> 

				<h2><?php $plxShow->lang('ERROR') ?> :</h2>
				<div class="error-content"><?php $plxShow->erreurMessage(); ?></div>
<!--<p class="center"><a href="http://blog.unesourisetmoi.info/" title="Accueil du site">Retour page d'accueil</a></p>-->
		</div>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>