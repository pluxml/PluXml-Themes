<?php include(dirname(__FILE__).'/header.php'); ?>

	<div id="section">

		<div id="content">
        <div id="breadcrumbs">		
					<?php $plxShow->mainTitle('link'); ?> <span class="sep">&#9658;</span> page <span class="sep">&#9658;</span> <?php $plxShow->staticTitle(); ?>					
            </div> 

                        <div class="article">
				<h2><?php $plxShow->staticTitle(); ?></h2>
				<div class="static-content"><?php $plxShow->staticContent(); ?></div>
                        </div>
		</div>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</div>

<?php include(dirname(__FILE__).'/footer.php'); ?>