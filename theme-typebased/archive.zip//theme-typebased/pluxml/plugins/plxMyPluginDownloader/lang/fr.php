<?php

$LANG = array(

'L_CURL_NOT_AVAILABLE'		=> 'Extension cURL non disponible',
'L_ERR_REMOTE_FILE'			=> 'Impossible d\'accéder au fichier demandé',
'L_ERR_DOWNLOAD'			=> 'Erreur pendant le téléchargement du fichier',
'L_URL'						=> 'Url du fichier plugin',
'L_EXTENSION'				=> '(.zip uniquement)',
'L_DOWNLOAD'				=> 'Télécharger',
'L_ERR_CURL'				=> 'Erreur: Extension cURL non disponible.',
'L_ERR_PLX_PLUGINS'			=> 'Erreur: Dossier '.PLX_PLUGIN.' introuvable',
'L_ERR_WRITE_ACCESS'		=> 'Erreur: Dossier '.PLX_PLUGIN.' protégé en écriture',

);
?>