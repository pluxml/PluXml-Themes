<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="footer">
	<p>
		G&eacute;n&eacute;r&eacute; par <a href="http://www.pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">PluXml</a>
		en <?php $plxShow->chrono(); ?><br />
		<a href="#top">Haut de page</a>
	</p>
</div>
</body>
</html>