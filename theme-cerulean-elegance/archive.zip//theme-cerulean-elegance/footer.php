<?php if(!defined('PLX_ROOT')) exit; ?>
	</div>
	</div>
	<div id="footer">
		<div class="left">
			G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a>  <?php $plxShow->version(); ?>
		</div>
		<div class="right">
			<a href="http://templates.arcsin.se/">Th&egrave;me</a> par <a href="http://arcsin.se/">Arcsin</a> | <a href="#top">Haut de page</a> | <a href="core/admin/">Administration</a>
		</div>
		<div class="clearer">&nbsp;</div>
	</div>
</div>
</div>
</body>
</html>