<?php include('header.php'); # On insere le header ?>
		<div id="main">
			<div class="left" id="content_outer">
				<div id="content">
					<h1><?php $plxShow->staticTitle(); ?></h1>
					<?php $plxShow->staticContent(); ?>
				</div>
			</div>
<?php include('sidebar.php'); # On insere la sidebar ?>
<?php include('footer.php'); # On insere le footer ?>