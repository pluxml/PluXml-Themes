<?php include('header.php'); # On insere le header ?>
		<div id="main">
			<div class="left" id="content_outer">
				<div id="content">
				<div class="post">
					<div class="post_title"><h1><?php $plxShow->artTitle(); ?></h1></div>
					<div class="post_date">Post&eacute; le <?php $plxShow->artDate(); ?> &agrave; <?php $plxShow->artHour(); ?> par <?php $plxShow->artAuthor(); ?></div>
					<div class="post_body">
						<?php $plxShow->artContent(); ?>
					</div>
					<div class="post_meta">
						<?php $plxShow->artNbCom(); ?> | Cat&eacute;gorie : <?php $plxShow->artCat(); ?>
					</div>
				</div>
				<?php # Si on a des commentaires ?>
				<?php if($plxShow->plxMotor->plxGlob_coms->count): ?>
				<h3 class="left" id="comments">Commentaires</h3>
				<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
				<p class="right"><a href="#reply">Laisser un message &#187;</a></p>
				<?php endif; ?>
				<div class="clearer">&nbsp;</div>
				<div class="comment_list">
					<?php while($plxShow->plxMotor->plxRecord_coms->loop()): # On boucle sur les commentaires ?>
					<div class="comment" id="<?php $plxShow->comId(); ?>">
						<div class="comment_gravatar left"><img alt="" src="<?php echo "http://www.gravatar.com/avatar/".md5($plxShow->plxMotor->plxRecord_arts->f('mail'))."?d=".urlencode($plxShow->plxMotor->racine.'themes/'.$plxShow->plxMotor->style.'/gravatar.jpg')."&amp;s=32"; ?>" height="32" width="32" /></div>
						<div class="comment_author left">
							<?php $plxShow->comAuthor('link'); ?>
							<div class="comment_date"><a href="#<?php $plxShow->comId(); ?>"><?php $plxShow->comDate(); ?></a></div>
						</div>
						<div class="clearer">&nbsp;</div>
						<div class="comment_body">								
							<?php $plxShow->comContent() ?>
						</div>
					</div>
					<?php endwhile; # Fin de la boucle sur les commentaires ?>
				</div>
				<?php endif; # Fin du if sur la prescence des commentaires ?>
				<?php # Si on autorise les commentaires ?>
				<?php if($plxShow->plxMotor->plxRecord_arts->f('allow_com') AND $plxShow->plxMotor->aConf['allow_com']): ?>
				<form action="<?php $plxShow->artUrl(); ?>#reply" method="post" id="reply">
					<fieldset>
						<div class="legend"><h3>Laisser un message</h3></div>
						<?php if($plxShow->comMessage): ?>
						<div class="form_row">
							<div class="message_error"><?php echo $plxShow->plxMotor->message_com;; ?></div>
							<div class="clearer">&nbsp;</div>
						</div>
						<?php endif; ?>
						<div class="form_row">
							<div class="form_property form_required">Nom</div>
							<div class="form_value"><input type="text" size="32" name="name" value="<?php $plxShow->comGet('name',''); ?>" /></div>
							<div class="clearer">&nbsp;</div>
						</div>
						<div class="form_row">
							<div class="form_property">E-mail</div>
							<div class="form_value"><input type="text" size="32" name="mail" value="<?php $plxShow->comGet('mail',''); ?>" /></div>
							<div class="clearer">&nbsp;</div>
						</div>
						<div class="form_row">
							<div class="form_property">Site (facultatif)</div>
							<div class="form_value"><input type="text" size="32" name="site" value="<?php $plxShow->comGet('site','http://'); ?>" /></div>
							<div class="clearer">&nbsp;</div>
						</div>
						<div class="form_row">
							<div class="form_property form_required">Commentaire</div>
							<div class="form_value"><textarea rows="10" cols="46" name="content"><?php $plxShow->comGet('content',''); ?></textarea></div>
							<div class="clearer">&nbsp;</div>
						</div>
						<?php # Affichage du capcha anti-spam
						if($plxShow->plxMotor->aConf['capcha']): ?>
						<div class="form_row">
							<div class="form_property form_required">V&eacute;rification anti-spam</div>
							<div class="form_value"><?php $plxShow->capchaQ(); ?>&nbsp;:&nbsp;<input name="rep" type="text" size="10" /></div>
							<input name="rep2" type="hidden" value="<?php $plxShow->capchaR(); ?>" />
							<div class="clearer">&nbsp;</div>
						</div>
						<?php endif; # Fin du if sur le capcha anti-spam ?>
						<div class="form_row form_row_submit">
							<div class="form_value"><input type="submit" class="button" value="Envoyer &#187;" />&nbsp;<input type="reset" class="button" value="Effacer" /></div>
							<div class="clearer">&nbsp;</div>
						</div>
					</fieldset>
				</form>
				<?php endif; # Fin du if sur l'autorisation des commentaires ?>
				</div>
			</div>
<?php include('sidebar.php');?>
<?php include('footer.php');?>