<?php include(dirname(__FILE__).'/header.php'); ?>
      <div id="main" class="site-main clr container">
            <div id="primary" class="content-area clr">
<div id="content" class="site-content" role="main">
	<div class="boxed clr">
	<header class="page-header clr">
	<h1 class="page-header-title"><?php $plxShow->staticTitle(); ?></h1>
	</header>
	<article class="entry clr">

	<?php $plxShow->staticContent(); ?>

		
	</article>
	</div>
				
</div>               
               
            </div>
        </div>

<?php include(dirname(__FILE__).'/footer.php'); ?>






