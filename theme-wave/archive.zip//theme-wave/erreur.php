<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="corps">
<?php include(dirname(__FILE__).'/menu.php'); # On insere le menu ?>

	<section id="content">
		<article>
			<h2 class="title">Une erreur a &eacute;t&eacute; d&eacute;tect&eacute;e :</h2>
			<h3><?php $plxShow->erreurMessage(); ?></h3>
			<p><a href="./" title="Accueil du site">Retour page d'accueil</a></p>
		</article>
	</section>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
	<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
</div>
