<?php if(!defined('PLX_ROOT')) exit; ?>

<section id="sidebar">

	<div class="promo">
		<a href="http://www.netvibes.com" title="Netvibes"><img src="<?php $plxShow->template(); ?>/images/technorati.png" alt="Facebook" /></a>
		<a href="http://www.twitter.com" title="Twitter"><img src="<?php $plxShow->template(); ?>/images/twitter.png" alt="Twitter" /></a>
		<a href="./feed.php?rss" title="RSS"><img src="<?php $plxShow->template(); ?>/images/rss.png" alt="RSS" /></a>
	</div>
	
	<div class="search">
		<form method="get" action="index.php">
			<input type="text" value="Rechercher..." name="s"  onfocus="if (this.value == 'Rechercher...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Rechercher...';}" />
			<input type="submit" id="searchsubmit" value="Go " />
		</form>
	</div>
		
	<div class="side categories">
		<h3>Cat&#233;gories</h3>
		<ul>
			<?php $plxShow->catList('','<li id="#cat_id"><a href="#cat_url" class="#cat_status" title="#cat_name">#cat_name</a></li>'); ?>
		</ul>
	</div>
	
	<div class="side articles">
		<h3>Derniers articles</h3>
		<ul>
			<?php $plxShow->lastArtList('<li><a href="#art_url" class="#art_status" title="#art_title">#art_title</a></li>'); ?>
		</ul>
	</div>
	
	<div class="side commentaires">
		<h3>Derniers commentaires</h3>
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author a dit :</a> #com_content(34)</li>'); ?>
		</ul>	
	</div>
		
	<div class="side blogroll">
		<h3>Blogroll</h3>
		<ul>
			<li><a href="index.php" title="Accueil">Accueil</a></li>
			<li><a href="index.php" title="Link 1">Link 1</a></li>
			<li><a href="index.php" title="Link 2">Link 2</a></li>
		</ul>
	</div>
</section>