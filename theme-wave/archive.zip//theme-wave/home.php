<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="corps">
	<?php include(dirname(__FILE__).'/menu.php'); # On insere le menu ?>

	<section id="content">
	<?php while($plxShow->plxMotor->plxRecord_arts->loop()): # On boucle sur les articles ?>
		<article>
			<h2><?php $plxShow->artTitle('link'); ?></h2>
			<span>Cat&#233;gories : <?php $plxShow->artCat(); ?> <strong>Le <?php $plxShow->artDate('#num_day/#num_month/#num_year(2)'); ?></strong></span>
			<?php $plxShow->artChapo(); ?>
			
		</article>
		<?php endwhile; # Fin de la boucle sur les articles ?>
		<div class="historique">
			<?php $plxShow->pagination(); ?>
			<hr class="both" />
		</div>
		
	</section>
	
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>	
</div>
