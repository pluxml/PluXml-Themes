<?php include(dirname(__FILE__).'/header.php'); # On insere le header ?>
<div id="corps">
<?php include(dirname(__FILE__).'/menu.php'); # On insere le menu ?>

	<section id="content">
		
		<article>
			<h2 class="title"><?php $plxShow->staticTitle(); ?></h2>
			<?php $plxShow->staticContent(); ?>
		</article>
	</section>
	<?php include(dirname(__FILE__).'/sidebar.php'); # On insere la sidebar ?>
	<?php include(dirname(__FILE__).'/footer.php'); # On insere le footer ?>
</div>
