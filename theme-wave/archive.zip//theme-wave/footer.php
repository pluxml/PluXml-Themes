<?php if(!defined('PLX_ROOT')) exit; ?>

<footer>
	<p>&copy; <?php $plxShow->mainTitle('link'); ?> - G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?></p>
	<p><a href="core/admin/">Administration</a> | <a href="#head" title="">Haut de page</a></p>
</footer>
</body>
</html>
