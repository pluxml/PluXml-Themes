<?php if(!defined('PLX_ROOT')) exit; ?>
<!DOCTYPE html>
<html>
<head>
<title><?php $plxShow->pageTitle(); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php $plxShow->charset(); ?>" />
<link rel="icon" href="<?php $plxShow->template(); ?>/images/favicon.ico" />
<meta name="generator" content="Notepad++" />
<meta name="author" content="dhoko" />
<!--[if IE]><script type="text/javascript" src="<?php $plxShow->template(); ?>/html5-ie.js"></script><![endif]-->
<link rel="stylesheet" type="text/css" href="<?php $plxShow->template(); ?>/style.css" media="screen" />
<link rel="alternate" type="application/atom+xml" title="Atom articles" href="./feed.php?atom" />
<link rel="alternate" type="application/rss+xml" title="Rss articles" href="./feed.php?rss" />
<link rel="alternate" type="application/atom+xml" title="Atom commentaires" href="./feed.php?atom/commentaires" />
<link rel="alternate" type="application/rss+xml" title="Rss commentaires" href="./feed.php?rss/commentaires" />
</head>
<body>

<header>
	<section id="head">
		<div class="logo"></div>
		<h1><?php $plxShow->mainTitle('link'); ?></h1>
		<p><?php $plxShow->subTitle(); ?></p>
	</section>
</header>
