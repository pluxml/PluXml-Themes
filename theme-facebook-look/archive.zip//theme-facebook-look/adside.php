<div id="adside">

	<div class="adstext"><a href="#">Annonces</a></div>
    
    <div class="adstext"><p class="title">Example Ads 1</p><div class="textwidget">Free Wordpress Themes is available at <a href="http://themes.diameter.web.id">Free WP Themes</a>. Search and download it now!</div></div>
    
    <div class="adstext"><p class="title">Example Ads 2</p><div class="textwidget">Facebook is the most favorite social network on the earth. "Giving people the power to share and make the world more open and connected."</div></div>
    

    
    <!-- Banner Advertisement Slot -->

    <div class="ads125">
    <a href="#"><img src="<?php $plxShow->template(); ?>/images/ads_125x125.gif" /></a></div>
    
    <div class="ads125">
    <a href="#"><img src="<?php $plxShow->template(); ?>/images/ads_125x125.gif" /></a></div>
        
</div>