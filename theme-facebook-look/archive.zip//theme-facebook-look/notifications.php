<div class="title">
<!-- Insérer le titre ici -->

Bienvenue!
</div>

<!-- Insérez votre message ici. Vous pouvez employer du code HTML standart, comme <b>, <br>, <a>, etc. -->
                    
Pour éditer <b>ce message</b> veuillez sélectionner<br />
le fichier <b>notifications.php</b> dans les <a href="./core/admin/parametres_affichage.php">Options d'affichages</a>.