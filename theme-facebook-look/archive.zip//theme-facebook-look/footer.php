<?php if(!defined('PLX_ROOT')) exit; ?>
	<div class="clear"></div>
    
    <div id="footer">

		<div class="alignleft">
			<p><?php $plxShow->mainTitle('link'); ?>  &copy; 2009</p>    
		</div>

<!-- Please keep this link, to support Wordpress and this theme. Thank you. -->

		<div class="alignright">
   			<p>G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> <?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> &nbsp;&bull;&nbsp; Facebook Look 2 by <a href="http://themes.diameter.web.id/">Free WP Themes</a> &nbsp;&bull;&nbsp; Supported by <a href="http://diameter.web.id/">Diameter News</a> &nbsp;&bull;&nbsp; <a href="#">Haut de page</a></p>
		</div>
    
	</div>

</div>
        
</body>
</html>