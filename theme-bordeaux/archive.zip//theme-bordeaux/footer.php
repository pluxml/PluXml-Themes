<?php if (!defined('PLX_ROOT')) exit; ?>

<footer role="contentinfo">

	<div class="content">

		<p>
			&copy; 2013 <?php $plxShow->mainTitle('link'); ?> - <?php $plxShow->subTitle(); ?>
		</p>
		<p>
			<?php $plxShow->lang('POWERED_BY') ?> <a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
			<?php $plxShow->lang('IN') ?> <?php $plxShow->chrono(); ?>&nbsp;
			<a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/') ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>&nbsp;
			<a href="<?php echo $plxShow->urlRewrite('#top') ?>" title="<?php $plxShow->lang('GOTO_TOP') ?>"><?php $plxShow->lang('TOP') ?></a>&nbsp;
			<?php $plxShow->httpEncoding() ?>
			<br /><!-- don't remove thanks -->
			css by : <a href="http://www.unesourisetmoi.info" title="fonds d'écran">fonds d'écran</a>
		</p>

	</div>

</footer>
<div class="clearer">&nbsp;</div>
<p align="center"><!-- à personnaliser selon utilisation -->
pour votre sécurité ce site a été testé, notamment par :  <a href="http://safeweb.norton.com/ title="norton safe web" rel="nofollow">Norton™ Safe Web</a> - 
<a href="http://www.siteadvisor.com/" title="MCAfee SiteAdvisor" rel="nofollow">MCAfee SiteAdvisor</a> - 
<a href="http://www.mywot.com/" title="WOT Reputation" rel="nofollow">WOT Reputation</a> -  <a href="#?rel=author">Google</a>
</p>
</body>

</html>
