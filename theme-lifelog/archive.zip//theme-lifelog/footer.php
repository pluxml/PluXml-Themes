<?php if (!defined('PLX_ROOT')) exit; ?>

                <footer id="footer">

                    <div class="wrap">

                        <div class="credit-icon">&#169;</div>
                        <p class="credit">
                            <?php $plxShow->mainTitle(); ?>&nbsp;-&nbsp;
					<?php $plxShow->subTitle(); ?>&nbsp;-&nbsp;
					<?php $plxShow->lang('POWERED_BY') ?>&nbsp;<a href="http://www.pluxml.org" title="<?php $plxShow->lang('PLUXML_DESCRIPTION') ?>">PluXml</a>
					<br>
					&nbsp;-&nbsp;Design par&nbsp;<a class="site-link" href="http://demo.genbu.me/lifelog" rel="home" target="_blank" >LifeLog</a>
					&nbsp;-&nbsp;<a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
                            </p>
                        <!-- .credit -->

                    </div>
                    <!-- .wrap -->

                </footer>
                <!-- #footer -->

            </div>
            <!-- .container-wrap -->
        </div>
        <!-- #container -->

        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/scripts.js?ver=4.4.2'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/fitvids.min.js?ver=0.1.1'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/theme.min.js?ver=1.0.0'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/wp-embed.min.js?ver=4.5.3'></script>
    </body>

    </html>