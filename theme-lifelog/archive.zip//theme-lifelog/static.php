<?php include(dirname(__FILE__).'/header.php'); ?>

    <div id="main">

        <div class="main-inner">

            <div class="main-wrap">

                    <div class="content-entry-wrap">

                        <article class="entry page">
 
                            <div class="entry-wrap">

                                <div class="comment-link-wrap">
                                    <span class="comments-link"></span> </div>
                                <!-- .comment-link-wrap -->

                                <header class="entry-header">
                                    <h1 class="entry-title" itemprop="headline">						
										<?php $plxShow->staticTitle(); ?>
									</h1>
                                </header>
                                <!-- .entry-header -->

                                <div class="entry-content" itemprop="text">
									<?php $plxShow->staticContent(); ?>
                                </div>
                                <!-- .entry-content -->


                            </div>
                            <!-- .entry-wrap -->

                        </article>
                        <!-- .entry -->

                    </div>
                    <!-- .content-entry-wrap-->

            </div>
            <!-- .main-wrap -->

        </div>
        <!-- .main-inner -->

    </div>
    <?php include(dirname(__FILE__).'/footer.php'); ?>