<?php include(dirname(__FILE__).'/header.php'); ?>
    <div id="main">
        <div class="main-inner">
            <div class="main-wrap">
                <header class="loop-meta">
                    <div class="glyphicon" style="vertical-align: top;
						-webkit-font-smoothing: antialiased;
						position: absolute;
						left: -33px;
						left: -3.3rem;
						top: 20px;
						top: 2rem;
						font-size: 40px;
						font-size: 3.4rem;
						background: #FF0;
						padding: 1.8rem 1.4rem;
						color: #000;
						width: 65px;
						width: 6.5rem;
						height: 65px;
						height: 6.5rem;
						-webkit-border-radius: 50%;
						-moz-border-radius: 50%;
						border-radius: 50%">
                        &#xe060;
                    </div>
                    <h1 class="loop-title">
						<?php $plxShow->catName(); ?>
					</h1>
                </header>

                <div id="content" class="content">
					<div class="content-entry-wrap">
                    <article class="entry post format-gallery" itemscope="itemscope" itemtype="http://schema.org/BlogPosting" itemprop="blogPost">
                        <div class="entry-wrap">
                            <div class="entry-content" itemprop="articleBody">
                                <div class="gallery gallery-columns-3 gallery-size-thumbnail">
									<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
										<figure class="gallery-item">
											<div class="gallery-icon landscape">
												<a href="<?php $plxShow->artUrl(); ?>">
													<img width="150" height="150" src="<?php $plxShow->template(); ?>/img.php?src=<?php $plxShow->artThumbnail('#img_url'); ?>&w=150&h=150&crop-to-fit" class="attachment-thumbnail size-thumbnail" alt="<?php $plxShow->artThumbnail('#img_aly'); ?>" >
												</a>
											</div>
											<figcaption class="wp-caption-text gallery-caption">
												<?php $plxShow->artTitle(); ?>
											</figcaption>
										</figure>
									<?php endwhile; ?>
								</div>
							</div>
						</div>    
					</article>
				</div>
					<nav class="pagination loop-pagination" style="display: block; margin-top: 0;margin-bottom: 0;">
						<?php 
						
							$plxGlob_arts = clone $plxShow->plxMotor->plxGlob_arts;
							$aFiles = $plxGlob_arts->query($plxShow->plxMotor->motif,'art','',0,false,'before');

							if($aFiles AND $plxShow->plxMotor->bypage AND sizeof($aFiles)>$plxShow->plxMotor->bypage) {

								# on supprime le n� de page courante dans l'url
								$arg_url = $plxShow->plxMotor->get;
								if(preg_match('/(\/?page[0-9]+)$/',$arg_url,$capture)) {
									$arg_url = str_replace($capture[1], '', $arg_url);
								}
								# Calcul des pages
								$prev_page = $plxShow->plxMotor->page - 1;
								$next_page = $plxShow->plxMotor->page + 1;
								$last_page = ceil(sizeof($aFiles)/$plxShow->plxMotor->bypage);
								# Generation des URLs
								$f_url = $plxShow->plxMotor->urlRewrite('?'.$arg_url); # Premiere page
								$arg = (!empty($arg_url) AND $prev_page>1) ? $arg_url.'/' : $arg_url;
								$p_url = $plxShow->plxMotor->urlRewrite('?'.$arg.($prev_page<=1?'':'page'.$prev_page)); # Page precedente
								$arg = !empty($arg_url) ? $arg_url.'/' : $arg_url;
								$n_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$next_page); # Page suivante
								$l_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$last_page); # Derniere page

								# Hook Plugins
								if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowPagination'))) return;

								# On effectue l'affichage
								if($plxShow->plxMotor->page > 2) # Si la page active > 2 on affiche un lien 1ere page
									echo '<span class="p_first"><a href="'.$f_url.'" title="'.L_PAGINATION_FIRST_TITLE.'">'.L_PAGINATION_FIRST.'</a></span>&nbsp;';
								if($plxShow->plxMotor->page > 1) # Si la page active > 1 on affiche un lien page precedente
									echo '<span class="p_prev"><a  class="prev page-numbers" href="'.$p_url.'" title="'.L_PAGINATION_PREVIOUS_TITLE.'"><span class="screen-reader-text">Previous</span></a></span>&nbsp;';
								# Affichage de la page courante
								printf('<span class="page-numbers current">'.L_PAGINATION.'</span>',$plxShow->plxMotor->page,$last_page);
								if($plxShow->plxMotor->page < $last_page) # Si la page active < derniere page on affiche un lien page suivante
									echo '&nbsp;<a class="next page-numbers" href="'.$n_url.'" title="'.L_PAGINATION_NEXT_TITLE.'"><span class="screen-reader-text">Next</span></a>';
								if(($plxShow->plxMotor->page + 1) < $last_page) # Si la page active++ < derniere page on affiche un lien derniere page
									echo '&nbsp;<span class="p_last"><a href="'.$l_url.'" title="'.L_PAGINATION_LAST_TITLE.'">'.L_PAGINATION_LAST.'</a></span>';
							}
							 ?>
						</nav>	
                </div>
            </div>
        </div>
    </div>

	
	
	
	
    <?php include(dirname(__FILE__).'/footer.php'); ?>