<?php 
global $plxShow;
include(dirname(__FILE__).'/header.php'); ?>
	<div id="main">
		<div class="main-inner">
			<div class="main-wrap">
				<header class="loop-meta" >
					<div class="glyphicon"
					style="vertical-align: top;
					-webkit-font-smoothing: antialiased;
					position: absolute;
					left: -33px;
					left: -3.3rem;
					top: 20px;
					top: 2rem;
					font-size: 40px;
					font-size: 3.4rem;
					background: #FF0;
					padding: 1.8rem 1.4rem;
					color: #000;
					width: 65px;
					width: 6.5rem;
					height: 65px;
					height: 6.5rem;
					-webkit-border-radius: 50%;
					-moz-border-radius: 50%;
					border-radius: 50%"> 
						&#xe060;
					</div>
					<h1 class="loop-title">
						<?php $plxShow->staticTitle(); ?>
					</h1>
				</header>
				
				<div class="content-entry-wrap">
					<article class="entry post " >
						<div class="entry-wrap">
							<div class="entry-content">
								<div class="gallery gallery-columns-3 gallery-size-thumbnail">
									<?php $plxShow->lastArtList('
									<figure class="gallery-item">
										<div class="gallery-icon landscape">
											<a href="#art_url">
												<img width="150" height="150" src="'.$plxMotor->urlRewrite($plxMotor->aConf['racine_themes'].$plxMotor->style).'/img.php?src=#img_url&w=150&h=150&crop-to-fit" class="attachment-thumbnail size-thumbnail" alt="#img_alt">
											</a>
										</div>
										<figcaption class="wp-caption-text gallery-caption">
											#art_title	
										</figcaption>
									</figure>',99); ?>
								</div>
							</div>
						</div>
					</article>
				</div>
			</div>
		</div>
	</div>
	
<?php include(dirname(__FILE__).'/footer.php'); ?>
