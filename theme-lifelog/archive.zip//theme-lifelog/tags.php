<?php include(dirname(__FILE__).'/header.php'); 



?>

    <div id="main">
        <div class="main-inner">
            <div class="main-wrap">
                <header class="loop-meta">
                    <div class="glyphicon" style="vertical-align: top;
						-webkit-font-smoothing: antialiased;
						position: absolute;
						left: -33px;
						left: -3.3rem;
						top: 20px;
						top: 2rem;
						font-size: 40px;
						font-size: 3.4rem;
						background: #FF0;
						padding: 1.8rem 1.4rem;
						color: #000;
						width: 65px;
						width: 6.5rem;
						height: 65px;
						height: 6.5rem;
						-webkit-border-radius: 50%;
						-moz-border-radius: 50%;
						border-radius: 50%">
                        &#xe118;
                    </div>
                    <h1 class="loop-title">
				<?php $plxShow->lang('TAGS'); ?> : <?php $plxShow->tagName(); ?>
			</h1>
                </header>

				
				
				
				
				
                <div id="content" class="content">
                    <div class="content-entry-wrap">
                        <?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>
                            <article class="entry post ">
                                <div class="entry-wrap">
                                    <div class="entry-published-wrap">
                                        <time class="entry-published updated" datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>" title="<?php $plxShow->artDate('#num_day #month #num_year(4)'); ?>">
                                            <span class="day-large" style="font-size: 3rem; margin-top:1rem;"><?php $plxShow->artDate('#day'); ?></span>
                                            <span class="time-box">
										<?php $plxShow->artDate('#num_day #short_month #num_year(4)'); ?>
									</span>
                                        </time>
                                    </div>
                                    <div class="comment-link-wrap">
                                        <?php $plxShow->artNbCom('<div class="comments-link">#nb</div>','<div class="comments-link">#nb</div>','<div class="comments-link">#nb</div>'); ?>
                                    </div>

                                    <header class="entry-header">
                                        <div class="entry-byline">
                                            <span class="entry-author">
										<span><?php $plxShow->artAuthor() ?></span>
                                            </span>
                                        </div>
                                        <h1 class="entry-title">
										<?php $plxShow->artTitle('link'); ?>
								</h1>
                                    </header>
                                    <div class="entry-content">
                                        <p>
                                            <img class="aligncenter size-full wp-image-54" src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt="fly" width="825" height="510" srcset="<?php $plxShow->artThumbnail('#img_url'); ?>" sizes="(max-width: 825px) 100vw, 825px" />
                                        </p>

                                        <?php $plxShow->artChapo(''); ?>

                                            <span class="more-link-wrap"> 
									<a href="<?php $plxShow->artUrl(); ?>" class="more-link" style="text-decoration:none;">
										<span class="more-text">Lire la suite</span>
                                            </a>
                                            </span>
                                    </div>
                                    <footer class="entry-footer">
                                        <div class="entry-meta">
                                            <span class="entry-terms category">
										<span class="term-name"><?php $plxShow->lang('CATEGORIES'); ?>: </span>
                                            <?php $plxShow->artCat() ?>
                                                </span>
                                                <span class="entry-terms post_tag">
									<span class="term-name"><?php $plxShow->lang('TAGS') ?>: </span>
                                                <?php $plxShow->artTags() ?>
                                                    </span>
                                        </div>
                                    </footer>
                                </div>
                            </article>
                            <?php endwhile; ?>

                    </div>

					<?php// $plxShow->pagination(); ?>
					

					<nav class="pagination loop-pagination" style="display: block; margin-top: 0;margin-bottom: 0;">
						<?php 
						
							$plxGlob_arts = clone $plxShow->plxMotor->plxGlob_arts;
							$aFiles = $plxGlob_arts->query($plxShow->plxMotor->motif,'art','',0,false,'before');

							if($aFiles AND $plxShow->plxMotor->bypage AND sizeof($aFiles)>$plxShow->plxMotor->bypage) {

								# on supprime le n° de page courante dans l'url
								$arg_url = $plxShow->plxMotor->get;
								if(preg_match('/(\/?page[0-9]+)$/',$arg_url,$capture)) {
									$arg_url = str_replace($capture[1], '', $arg_url);
								}
								# Calcul des pages
								$prev_page = $plxShow->plxMotor->page - 1;
								$next_page = $plxShow->plxMotor->page + 1;
								$last_page = ceil(sizeof($aFiles)/$plxShow->plxMotor->bypage);
								# Generation des URLs
								$f_url = $plxShow->plxMotor->urlRewrite('?'.$arg_url); # Premiere page
								$arg = (!empty($arg_url) AND $prev_page>1) ? $arg_url.'/' : $arg_url;
								$p_url = $plxShow->plxMotor->urlRewrite('?'.$arg.($prev_page<=1?'':'page'.$prev_page)); # Page precedente
								$arg = !empty($arg_url) ? $arg_url.'/' : $arg_url;
								$n_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$next_page); # Page suivante
								$l_url = $plxShow->plxMotor->urlRewrite('?'.$arg.'page'.$last_page); # Derniere page

								# Hook Plugins
								if(eval($plxShow->plxMotor->plxPlugins->callHook('plxShowPagination'))) return;

								# On effectue l'affichage
								if($plxShow->plxMotor->page > 2) # Si la page active > 2 on affiche un lien 1ere page
									echo '<span class="p_first"><a href="'.$f_url.'" title="'.L_PAGINATION_FIRST_TITLE.'">'.L_PAGINATION_FIRST.'</a></span>&nbsp;';
								if($plxShow->plxMotor->page > 1) # Si la page active > 1 on affiche un lien page precedente
									echo '<span class="p_prev"><a  class="prev page-numbers" href="'.$p_url.'" title="'.L_PAGINATION_PREVIOUS_TITLE.'"><span class="screen-reader-text">Previous</span></a></span>&nbsp;';
								# Affichage de la page courante
								printf('<span class="page-numbers current">'.L_PAGINATION.'</span>',$plxShow->plxMotor->page,$last_page);
								if($plxShow->plxMotor->page < $last_page) # Si la page active < derniere page on affiche un lien page suivante
									echo '&nbsp;<a class="next page-numbers" href="'.$n_url.'" title="'.L_PAGINATION_NEXT_TITLE.'"><span class="screen-reader-text">Next</span></a>';
								if(($plxShow->plxMotor->page + 1) < $last_page) # Si la page active++ < derniere page on affiche un lien derniere page
									echo '&nbsp;<span class="p_last"><a href="'.$l_url.'" title="'.L_PAGINATION_LAST_TITLE.'">'.L_PAGINATION_LAST.'</a></span>';
							}
							 ?>
						</nav>	
						
					
                </div>

            </div>
        </div>
    </div>
	
    <?php include(dirname(__FILE__).'/footer.php'); ?>

