<?php if (!defined('PLX_ROOT')) exit; ?>

<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang() ?>">
    <head>
	<meta charset="<?php $plxShow->charset('min'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
		<title><?php $plxShow->pageTitle(); ?></title>
		<?php $plxShow->meta('description') ?>
		<?php $plxShow->meta('keywords') ?>
		<?php $plxShow->meta('author') ?>
		<link rel="icon" href="<?php $plxShow->template(); ?>/images/favicon.png" />
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet">
        <link rel='stylesheet' id='theme-open-sans-font-css' href='//fonts.googleapis.com/css?family=Open+Sans%3A400%2C300%2C300italic%2C400italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic&#038;ver=1.0.0' type='text/css' media='all' />
        <link rel='stylesheet' id='dashicons-css' href='<?php $plxShow->template(); ?>/css/dashicons.min.css?ver=4.5.3' type='text/css' media='all' />
        <link rel='stylesheet' id='theme-reset-css' href='<?php $plxShow->template(); ?>/css/reset.min.css?ver=1.0.0' type='text/css' media='all' />
        <link rel='stylesheet' id='theme-menus-css' href='<?php $plxShow->template(); ?>/css/menus.min.css?ver=1.0.0' type='text/css' media='all' />
        <link rel='stylesheet' id='style-css' href='<?php $plxShow->template(); ?>/css/style.min.css?ver=1.0.0' type='text/css' media='all' />
        <link rel='stylesheet' id='media-queries-css' href='<?php $plxShow->template(); ?>/css/media-queries.min.css?ver=1.0.0' type='text/css' media='all' />
        <link rel='stylesheet' id='contact-form-7-css' href='<?php $plxShow->template(); ?>/css/styles.css?ver=4.4.2' type='text/css' media='all' />
         <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery.js?ver=1.12.4'></script>
        <script type='text/javascript' src='<?php $plxShow->template(); ?>/js/jquery-migrate.min.js?ver=1.4.1'></script>
    </head>
	
	
    <body class="ltr en en-us  home blog no-js">
        <script src="<?php $plxShow->template(); ?>/js/js-status.js" type="text/javascript"></script>
        <div id="container">
            <div class="container-wrap">
                <header id="header">
                    <div class="header-image">
                        <div class="header-image-wrap">
                            <img class="site-logo" src="<?php $plxShow->template(); ?>/images/thief-peek.png" height="160" width="160">
                        </div>
                    </div>
                    <div id="branding">
                        <h1 id="site-title"><a href="." rel="home" style="text-decoration:none;"><?php $plxShow->mainTitle(); ?></a></h1>
                        <h2 id="site-description"><?php $plxShow->subTitle(); ?></h2>
                    </div>
                </header>
                <nav id="menu-primary" class="menu">
                    <div class="menu-container menu-dropdown menu-search">
                        <div id="menu-toggle-primary" class="menu-toggle">
                            <a class="menu-toggle-open" href="#menu-primary"><span class="screen-reader-text">Navigation</span></a>
                            <a class="menu-toggle-close" href="#menu-toggle-primary"><span class="screen-reader-text">Navigation</span></a>
                        </div>
                        <div class="wrap">
                            <ul id="menu-primary-items" class="menu-items">
                                <?php $plxShow->staticList($plxShow->getLang('HOME'),'<li class="#static_status" id="#static_id"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
                                <?php $plxShow->pageBlog('<li id="#page_id"><a class="#page_status" href="#page_url" title="#page_name">#page_name</a></li>'); ?>
								<li id="menu-item-81" class="menu-item menu-item-has-children"><a href="#"><?php $plxShow->lang('CATEGORIES'); ?></a>
									<ul class="sub-menu">
										<?php $plxShow->catList('','<li id="#cat_id" class="menu-item "><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a></li>'); ?>
									</ul>
								</li>
							</ul>
						</div>
						<?php	
						$placeholder = '';
						# récupération d'une instance de plxMotor
						$plxMotor = plxMotor::getInstance();
						$plxPlugin = $plxMotor->plxPlugins->getInstance('plxMySearch');
						$searchword = '';
						if(!empty($_POST['searchfield'])) {
							$searchword = plxUtils::strCheck(plxUtils::unSlash($_POST['searchfield']));
						}
						if($plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang)!='') {
							$placeholder=' placeholder="'.$plxPlugin->getParam('placeholder_'.$plxPlugin->default_lang).'"';
						}
						?>
						<div class="searchform">
							<form action="<?php echo $plxMotor->urlRewrite('?'.$plxPlugin->getParam('url')) ?>" method="post"  class="search-form" >
								<?php if($title) : ?>
									<p class="searchtitle">
										<?php
											if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)=='')
												$plxPlugin->lang('L_FORM_SEARCHFIELD');
											else
												$plxPlugin->lang('L_FORM_SEARCHFIELD_2');
										?>&nbsp;:
									</p>
								<?php endif; ?>
								<div class="searchfields">
									<?php
									if($plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang)!='') {
										if($chk = explode(';', $plxPlugin->getParam('checkboxes_'.$plxPlugin->default_lang))) {
											echo '<ul>';
											foreach($chk as $k => $v) {
												$c = plxUtils::title2url(trim($v));
												$sel = "";
												if(isset($_POST['searchcheckboxes'])) {
													foreach($_POST['searchcheckboxes'] as $s) {
														if($s==$c) {
															$sel = ' checked="checked"';
														}
													}
												}
												echo '<li><input'.$sel.' class="searchcheckboxes" type="checkbox" name="searchcheckboxes[]" id="id_searchcheckboxes[]" value="'.$c.'" />&nbsp;'.plxUtils::strCheck($v).'</li>';
											}
											echo '</ul>';
										}
									}
									?>
									<a href="#search-menu" class="search-toggle"><span class="screen-reader-text">Expand Search Form</span></a>
									<input id="search-menu" type="search" class="search-field" name="searchfield" value="<?php echo $searchword ?>" />
									<button type="submit"  class="search-submit button" value="<?php echo $plxPlugin->getParam('frmLibButton_'.$plxPlugin->default_lang) ?>"><span class="screen-reader-text">Search</span></button>
								</div>
							</form>
						</div>
					</div>
				</nav>
