<?php include(dirname(__FILE__).'/header.php'); ?>
    <div id="main">
        <div class="main-inner">
            <div class="main-wrap">
				<div class="content-entry-wrap">
						<article class="entry post ">
							<div class="entry-wrap">
								<div class="entry-published-wrap">
									<time class="entry-published updated" datetime="2015-09-06T15:41:35+00:00" title="Sunday, September 6, 2015, 3:41 pm">
										<span class="day-large" style="font-size: 3rem; margin-top:1rem;"><?php $plxShow->artDate('#day'); ?></span>
										<span class="time-box">
											<?php $plxShow->artDate('#num_day #short_month #num_year(4)'); ?>
										</span>
									</time>
								</div>
								<div class="comment-link-wrap">
									<a href="#comments" style="text-decoration:none;">
										<?php $plxShow->artNbCom('<div class="comments-link">#nb</div>','<div class="comments-link">#nb</div>','<div class="comments-link">#nb</div>'); ?>
									</a>
								</div>
								<header class="entry-header">
									<div class="entry-byline">
										<span class="entry-author">
											<span><?php $plxShow->artAuthor() ?></span>
										</span>
									</div>
									<h1 class="entry-title">
											<?php $plxShow->artTitle('link'); ?>
									</h1>
								</header>
								<div class="entry-content">
									<p>
										<img class="aligncenter size-full wp-image-54" src="<?php $plxShow->artThumbnail('#img_url'); ?>" alt="fly" width="825" height="510" srcset="<?php $plxShow->artThumbnail('#img_url'); ?>" sizes="(max-width: 825px) 100vw, 825px" />
									</p>
									<?php $plxShow->artContent(); ?>
								</div>
								<footer class="entry-footer">
									<div class="entry-meta">
										<span class="entry-terms category">
											<span class="term-name"><?php $plxShow->lang('CATEGORIES'); ?>: </span>
												<?php $plxShow->artCat() ?>
											</span> 
										<span class="entry-terms post_tag">
										<span class="term-name"><?php $plxShow->lang('TAGS') ?>: </span> 
											<?php $plxShow->artTags() ?>
										</span>
									</div>
								</footer>
							</div>
						</article>
					</div>
				
				<?php include(dirname(__FILE__).'/commentaires.php'); ?>

				
			</div>

		</div>
	</div>

    <?php include(dirname(__FILE__).'/footer.php'); ?>