<div id="footer">
	<p>Design : <a href="http://www.spyka.net" title="spyka Webmaster">spyka webmaster</a> | G&eacute;n&eacute;r&eacute; par 
		<a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> | 
		<a href="core/admin/">Administration</a> | 
		<a href="#top">Haut de page</a>
	</p>
</div>

</body>
</html>