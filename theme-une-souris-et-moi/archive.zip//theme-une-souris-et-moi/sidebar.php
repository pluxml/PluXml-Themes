<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="sidebar">
	<div class="item">
		<h2><?php $plxShow->lang('CATEGORIES') ?></h2>
		<ul>
			<?php $plxShow->catList('','<li id="#cat_id" class="#cat_status"><a href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>
	</div>
                <div class="item">
	<h2>Rechercher ...</h2>

    <form method="post" id="searchform" action="<?php $plxShow->urlRewrite('?static6/rechercher') ?>">
<p class="searchform">
	<input type="hidden" name="search" value="search"  />
	<input type="text" class="searchfield" name="searchfield" value="Rechercher..." onblur="if(this.value=='') this.value='Rechercher...';" onfocus="if(this.value=='Rechercher...') this.value='';" /> 
	<input type="submit" class="searchbutton" value="Go" />
</p>
</form>
    </div>

	<div class="item">
		<h2><?php $plxShow->lang('LAST_ARTICLES') ?></h2>
		<ul>
			<?php $plxShow->lastArtList('<li class="#art_status"><a href="#art_url" title="#art_title">#art_title</a></li>'); ?>
		</ul>
	</div>
	<div class="item">
		<h2><?php $plxShow->lang('LAST_COMMENTS') ?></h2>
		<ul>
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author a dit : #com_content(34)</a></li>'); ?>
		</ul>
	</div>

        <div class="item">
	<h2>Liens</h2>
	<ul>
	<li><a href="http://www.unesourisetmoi.info/" title="Fonds d'&eacute;cran">Fonds d'&eacute;cran</a></li>
	<li><a href="http://blog.unesourisetmoi.info/" title="Blog du r&eacute;f&eacute;rencement">Blog du r&eacute;f&eacute;rencement</a></li>
	<li><a href="http://unesourisetmoi.free.fr/pluxml2/" title="Th&egrave;me 'unesourisetmoi' diaporama">Th&egrave;me 'unesourisetmoi' diaporama</a></li>
    </ul>
    </div>
    <div class="item">
        <h2><?php $plxShow->lang('ARCHIVES') ?></h2>
        <ul>
            <?php $plxShow->archList('<li id="#archives_id" class="#archives_status"><a href="#archives_url" title="#archives_name">#archives_name (#archives_nbart)</a></li>'); ?>
        </ul>
    </div>

        <div id="rss">
	<h2>Syndication</h2>
	<ul>
	<li><a href="./feed.php?rss" title="Fil RSS des articles">Fil des articles</a></li>
	<li><a href="./feed.php?rss/commentaires" title="Fil RSS des commentaires">Fil des commentaires</a></li>
	</ul>
</div>
</div>
<div class="clearer"></div>