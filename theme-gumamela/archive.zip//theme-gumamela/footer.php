
</div>
<div id="footer">
	<p>G&eacute;n&eacute;r&eacute; par <a href="http://pluxml.org" title="Blog ou Cms sans base de donn&eacute;es">Pluxml</a> 
	<?php $plxShow->version(); ?> en <?php $plxShow->chrono(); ?> | <a href="core/admin/">Administration</a> |  <a href="#top">Haut de page</a>
	<br />Copyright &copy; 2007 Gumamela. Design de <a href="http://www.freecsstemplates.org/">Free CSS Templates</a> </p>
</div>
</body>
</html>