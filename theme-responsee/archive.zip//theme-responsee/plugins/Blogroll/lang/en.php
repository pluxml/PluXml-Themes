<?php
	$LANG = array(
		'L_TITLE'	=>	'Blogroll',
		'L_CONFIG_DESCRIPTION'		=>	'Blogroll configuration page',
		'L_CONFIG_ROOT_PATH'		=>	'Blogroll file location (xml file)',
		'L_CONFIG_SAVE'				=>	'Save',
		'L_CONFIG_PUB_TITLE'		=>	'Display as (Public part)',
		'L_ADMIN_DESCRIPTION'		=>	'Blogroll administration page',		
		'L_ADMIN_APPLY_BUTTON'		=>	'Update list',
		'L_ADMIN_SELECTION'			=>	'Dor selection',
		'L_ADMIN_DELETE'			=>	'Delete',
		'L_ADMIN_LIST_ID'			=>	'Id',
		'L_ADMIN_LIST_NAME'			=>	'Title',
		'L_ADMIN_LIST_URL'			=>	'URL',
		'L_ADMIN_LIST_DESC'			=>	'Description',
		'L_ADMIN_LIST_LANG'			=>	'Language',
		'L_ADMIN_LIST_LINK'			=>	'Link',
		'L_ADMIN_LIST_NEW'			=>	'New',
		'L_ADMIN_LIST_ORDER'		=>	'Order',
		'L_ADMIN_LIST_GROUP'		=>	'Group',
		'L_ADMIN_GROUP_TITLE'		=>	'Groups management',
		'L_ADMIN_LINK_TITLE'		=>	'Links management',
		'L_ADMIN_GROUP_ADD'			=>	'Add group',
		'L_ADMIN_GROUP_DEL'			=>	'Delete group'
	);
?>
