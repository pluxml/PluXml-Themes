<?php include(dirname(__FILE__).'/header.php'); ?>

		<div id="outer-space"><!-- Begin outer-space -->
		
			<div id="hfeed">
				
				<p id="page-info"><span><?php $plxShow->lang('ERROR_SHORT') ?></span></p>
				
				<div class="hentry">
				
					<div class="entry-meta">
						<h2 class="entry-title"><?php $plxShow->lang('ERROR') ?></h2>
					</div>
					
					<div class="entry-content">
						<?php $plxShow->erreurMessage(); ?>
					</div>
					
				</div>
				
				<div class="separator"></div>
				
			</div>
			
			<hr />
			
			
			<?php include(dirname(__FILE__).'/left-sidebar.php'); ?>
				
			
			<div class="clear"></div>
			
		</div><!-- End outer-space -->
		
		<hr />
		
		<?php include(dirname(__FILE__).'/right-sidebar.php'); ?>
				
		
		<div class="clear"></div>
		
		<hr />
		
		<?php include(dirname(__FILE__).'/footer.php'); ?>
