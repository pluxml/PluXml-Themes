<?php if(!defined('PLX_ROOT')) exit; ?>

<div id="right-sidebar">
	<div class="widget">
		<h3><?php $plxShow->lang('STATIC') ?></h3>
		<ul>
			<?php $plxShow->staticList($plxShow->getLang('HOME'),'<li id="#static_id" class="#static_status"><a href="#static_url" title="#static_name">#static_name</a></li>'); ?>
		</ul>
	</div>
	
	<div class="widget">
		<h3><?php $plxShow->lang('ARCHIVES') ?></h3>
		<ul>
			 <?php $plxShow->archList('<li id="#archives_id" class="#archives_status"><a href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
		</ul>
	</div>
	
	<div class="widget">
		<h3><?php $plxShow->lang('TAGS') ?></h3>
		<ul>
			<?php $plxShow->tagList('<li class="#tag_status"><a href="#tag_url" title="#tag_name">#tag_name</a></li>', 20); ?>
		</ul>
	</div>
</div>
