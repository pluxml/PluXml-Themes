<?php include(dirname(__FILE__).'/header.php'); ?>

		<div id="outer-space"><!-- Begin outer-space -->
		
			<div id="hfeed">
				
				<p id="page-info"><span><?php $plxShow->staticTitle(); ?></span></p>
				
				
				<div class="hentry">
				
					<div class="entry-content">
						<?php $plxShow->staticContent(); ?>
					</div>
					
				</div>
				
				<div class="separator"></div>
				
				
			</div>
			
			<hr />
			
			
			<?php include(dirname(__FILE__).'/left-sidebar.php'); ?>
				
			
			<div class="clear"></div>
			
		</div><!-- End outer-space -->
		
		<hr />
		
		<?php include(dirname(__FILE__).'/right-sidebar.php'); ?>
				
		
		<div class="clear"></div>
		
		<hr />
		
		<?php include(dirname(__FILE__).'/footer.php'); ?>