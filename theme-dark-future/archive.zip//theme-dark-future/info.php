<?php
define('VIADEO', 'http://http://www.pluxml.org/' );
define('LINKEDIN', "http://www.pluxml.org/");
define('TWITTER', "http://www.pluxml.org/");
define('GP', "http://www.pluxml.org/");
define('MAILTO', "http://www.pluxml.org/");

define('FR', "http://www.pluxml.org/");
define('EN', "http://www.pluxml.org/");

define('DARTH', "http://www.pluxml.org/");
define('ARP', "http://www.pluxml.org/");
define('CRUNCH', "http://www.http://crunchbanglinux-fr.org/");
define('DEBIAN', "http://www.debian.org/index.fr.html");
define('STACK', "http://www.pluxml.org/");

define('BLOG', "http://www.pluxml.org/");
define('ME', "http://www.pluxml.org/");
define('GALLERY', "http://www.pluxml.org/");
define('PRO', "http://www.pluxml.org/");
define('GITHUB', "https://github.com/jlengrand");
define('PROG', "http://lengrandlambert.fr/progTips.html");

define('VIADEO_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/viadeo.png" );
define('LINKEDIN_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/linkedin.png");
define('TWITTER_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/twitter.png");
define('GP_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/google-plus.png");
define('MAILTO_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/mailto.png");
define('RSS_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/rss.png");

define('CERTIF_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/certificate.png");

define('FR_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/fr.png");
define('EN_H', "http://dl.dropbox.com/u/4286043/00_Website/04_pluxmlressources/00_1.3/img/en.png");

?>
