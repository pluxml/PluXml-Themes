Nom = navigator.appName;

ns = (Nom == 'Netscape') ? 1:0
ie = (Nom == 'Microsoft Internet Explorer') ? 1:0
m = (Nom == 'Mozilla') ? 1:0


if (ns) {
document.write('<link rel="stylesheet" type="text/css" href="<date_m.css">')
}



else if (ie) {
document.write('<link rel="stylesheet" type="text/css" href="date_ie.css">')
}


else if (m) {
document.write('<link rel="stylesheet" type="text/css" href="date_m.css">')
}