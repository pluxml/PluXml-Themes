</div><!--END PAGE-->
<div id="footer">
		&#169; 2009 <span class="url fn org">Mimbo Magazine</span> &nbsp;&nbsp;|&nbsp;&nbsp;
		Th&egrave;me cr&eacute;&eacute; par <a href="http://www.darrenhoyt.com/">http://www.darrenhoyt.com/</a> et interpr&eacute;t&eacute; pour <a href="http://pluxml.org" title="Cms � la sauce xml">pluxml</a> par <a href="http://www.madvic.net/">madvic</a><br/>
		
		Powered by <a href="http://pluxml.org" title="Cms � la sauce xml">Pluxml</a> 
		<?php $plxShow->version(); ?> 
		en <?php $plxShow->chrono(); ?> &nbsp;&nbsp;| &nbsp;&nbsp;
		<a href="core/admin/">Administration</a> &nbsp;&nbsp;| &nbsp;&nbsp;
		<a href="#top">Haut de page</a>
</div>

</body>
</html>